#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Cover other elements to path element function
import sys,os,re
def ConvertCommon(line):
    newLine = []
    stroke = re.findall(r" stroke=\"(.+?)\"", line)
    if len(stroke) != 0:
        newLine.append("stroke=\"%s\"" % stroke[0])
    strokeWidth = re.findall(r" stroke-width=\"(.+?)\"", line)
    if len(strokeWidth) != 0:
        newLine.append("stroke-width=\"%s\"" % strokeWidth[0])
    transform = re.findall(r" transform=\"(.+?)\"", line)
    if len(transform) != 0:
        newLine.append("transform=\"%s\"" % transform[0])
    color = re.findall(r" fill=\"(.+?)\"", line)
    if len(color) != 0:
        newLine.append("fill=\"%s\"" % color[0])
    opacity = re.findall(r" opacity=\"(.+?)\"", line)
    if len(opacity) != 0:
        newLine.append("opacity=\"%s\"" % opacity[0])
    return newLine

def ConvertCircle(line):
    circleX = 0.0
    circleY = 0.0
    radiue = 0.0
    newLine = ["path"]
    cx = re.findall(r" cx=\"(.+?)\"", line)
    if len(cx) != 0:
        circleX = float(cx[0])
    cy = re.findall(r" cy=\"(.+?)\"", line)
    if len(cy) != 0:
        circleY = float(cy[0])
    r = re.findall(r" r=\"(.+?)\"", line)
    if len(r) != 0:
        radiue = float(r[0])
    newLine.append("d=\"M%f %f a%f %f 0 1 0 %f 0 a%f %f 0 1 0 %f 0Z\"" % \
        (circleX - radiue, circleY, radiue, radiue, 2 * radiue, radiue, radiue, -2 * radiue))
    return newLine + ConvertCommon(line)

def ConvertRect(line):
    rectX = 0.0
    rectY = 0.0
    rectW = 0.0
    rectH = 0.0
    rectC = 0
    rX = 0.0
    rY = 0.0
    newLine = ["path"]
    x = re.findall(r" x=\"(.+?)\"", line)
    if len(x) != 0:
        rectX = float(x[0])
    y = re.findall(r" y=\"(.+?)\"", line)
    if len(y) != 0:
        rectY = float(y[0])
    w = re.findall(r" width=\"(.+?)\"", line)
    if len(w) != 0:
        rectW = float(w[0])
    h = re.findall(r" height=\"(.+?)\"", line)
    if len(h) != 0:
        rectH = float(h[0])
    rx = re.findall(r" rx=\"(.+?)\"", line)
    ry = re.findall(r" ry=\"(.+?)\"", line)
    if len(rx) == 0 and len(ry) == 0:
            newLine.append("d=\"M%f %f h%f v%f h%fZ\"" %  (rectX, rectY, rectW, rectH, -rectW))
    else:
        if len(rx) == 0:
            rY = float(ry[0])
            rX = rY
        elif len(ry) == 0:
            rX = float(rx[0])
            rY = rX
        else:
            rX = float(rx[0])
            rY = float(ry[0])
        newLine.append("d=\"M%f %f a%f %f 0 0 1 %f %f h%f a%f %f 0 0 1 %f %f v%f a%f %f 0 0 1 %f %f h%f a%f %f 0 0 1 %f %fZ\" " % \
                (rectX, rectY + rY, rX, rY, rX, -rY, \
                rectW - rX - rY, rX, rY, rX, rY, \
                rectH - rX -rY, rX, rY, -rX, rY,  \
                rX + rY -rectW, rX, rY, -rX, -rY))
    return newLine + ConvertCommon(line)

def ConvertEllipse(line):
    cX = 0.0
    cY = 0.0
    rX = 0.0
    rY = 0.0
    newLine = ["path"]
    cx = re.findall(r" cx=\"(.+?)\"", line)
    if len(cx) != 0:
        cX = float(cx[0])
    cy = re.findall(r" cy=\"(.+?)\"", line)
    if len(cy) != 0:
        cY = float(cy[0])
    rx = re.findall(r" rx=\"(.+?)\"", line)
    if len(rx) != 0:
        rX = float(rx[0])
    ry = re.findall(r" ry=\"(.+?)\"", line)
    if len(ry) != 0:
        rY = float(ry[0])
    newLine.append("d=\"M%f %f a%f %f 0 1 0 %f 0 a%f %f 0 1 0 %f 0Z\"" % \
        (cX - rX, cY, rX, rY, 2 * rX, rX, rY, -2 * rX))
    return newLine + ConvertCommon(line)

def ConvertLine(line):
    starX = 0.0
    starY = 0.0
    endX = 0.0
    endY = 0.0
    newLine = ["path"]
    x1 = re.findall(r" x1=\"(.+?)\"", line)
    if len(x1) != 0:
        starX = float(x1[0])
    y1 = re.findall(r" y1=\"(.+?)\"", line)
    if len(y1) != 0:
        starY = float(y1[0])
    x2 = re.findall(r" x2=\"(.+?)\"", line)
    if len(x2) != 0:
        endX = float(x2[0])
    y2 = re.findall(r" y2=\"(.+?)\"", line)
    if len(y2) != 0:
        endY = float(y2[0])
    newLine.append("d=\"M%f %f L%f %fZ\"" % (starX, starY, endX, endY))
    return newLine + ConvertCommon(line)

def ConvertPolygon(line):
    dPara = []
    newLine = ["path"]
    point = re.findall(r" point=\"(.+?)\"", line)
    if len(point) == 0:
        return line
    pointSplit = point[0].split(' ')
    starPoint = pointSplit[0].split(',')
    dPara.append("M%s %s", starPoint[0], starPoint[1])
    for p in pointSplit[1:]:
        point = p.split(',')
        dPara.append("L%s %s", point[0], point[1])
    newLine.append("d=\"" + ' '.join(dPara) + "Z\"")
    return newLine + ConvertCommon(line)

def ConvertPolyline(line):
    dPara = []
    newLine = ["path"]
    point = re.findall(r" point=\"(.+?)\"", line)
    if len(point) == 0:
        return line
    pointSplit = point[0].split(' ')
    starPoint = pointSplit[0].split(',')
    dPara.append("M%s %s", starPoint[0], starPoint[1])
    for p in pointSplit[1:]:
        point = p.split(',')
        dPara.append("L%s %s", point[0], point[1])
    newLine.append("d=\"" + ' '.join(dPara) + "\"")
    return newLine + ConvertCommon(line)

def ConvertShapesToPath(file, outFile):
    print('convert_shapes.py当前处理文件', file)
    with open(file, 'r') as f:
        readData = f.read()
    pathData = []
    fb = open(outFile, 'w')
    isClipPath = 0
    for line in re.findall(r"<(.+?)>", readData):
        lineData = line.split(" ")
        if isClipPath == 0 and lineData[0] == "rect" :
            newLine = ' '.join(ConvertRect(line))
        elif isClipPath == 0 and lineData[0] == "circle" :
            newLine = ' '.join(ConvertCircle(line))
        elif isClipPath == 0 and lineData[0] == "ellipse":
            newLine = ' '.join(ConvertEllipse(line))
        elif isClipPath == 0 and lineData[0] == "line":
            newLine = ' '.join(ConvertLine(line))
        elif isClipPath == 0 and lineData[0] == "polygon":
            newLine = ' '.join(ConvertPolygon(line))
        elif isClipPath == 0 and lineData[0] == "polyline":
            newLine = ' '.join(ConvertPolyline(line))
        elif isClipPath == 0 and lineData[0] == "clipPath":
            isClipPath += 1
            newLine = line
        elif isClipPath != 0 and lineData[0] == "/clipPath":
            isClipPath -= 1
            newLine = line
        else:
            newLine = line
        pathData.append('<' + newLine + '>')
    fb.write('\n'.join(pathData))
    fb.close()
    f.close()
    return outFile