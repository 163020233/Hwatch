#ifndef ${HEADER_FILE_MACRO}
#define ${HEADER_FILE_MACRO}

/* @brief Contains all drawing commands for svg path
 * @param:
 *  0 : close path
 *  2 : move to
 *  4 : line to
 *  6 : horizontal line to
 *  8 : vertical line to
 *  10 : quadratic Bézier curve
 *  12 : curve to
 *  14 : smooth quadratic Bézier curveto
 *  16 : smooth curveto
 *  18 : elliptical arc(SCCW)
 *  20 : elliptical arc(SCW)
 *  22 : elliptical arc(LCCW)
 *  24 : elliptical arc(LCW)
*/
static uint16_t ${HEADER_NAME}[] = {
    ${HEADER}};

static uint8_t ${CMDS_NAME}[] = {
    ${CMDS}};

/* @brief a path line start point index.*/
static uint16_t ${CMD_INDEX_NAME}[] = {
    ${CMD_INDEX}};

/* @brief Number of cmd records in a path line.*/
static uint32_t ${CMD_NUM_NAME}[] = {
    ${CMD_NUM}};

/* @brief Contains all drawing data for the svg path.*/
static float ${DATAS_NAME}[] = {
    ${DATAS}};

/* @brief a path line start data index.*/
static uint16_t ${DATA_INDEX_NAME}[] = {
    ${DATA_INDEX}};

/* @brief Number of data records in a path line.*/
static uint32_t ${DATA_NUM_NAME}[] = {
    ${DATA_NUM}};

/* @brief a path line color.*/
static uint8_t ${DATA_OPACITY_NAME}[] = {
    ${DATA_OPACITY}};

static uint8_t ${DATA_PAINTSTYLE_NAME}[] = {
    ${DATA_PAINTSTYLE}};

static uint32_t ${DATA_FILLTYPE_NAME}[] = {
    ${DATA_FILLTYPE}};

static uint32_t ${DATA_FILL_NAME}[] = {
    ${DATA_FILL}};

static uint8_t ${DATA_FILLRULE_NAME}[] = {
    ${DATA_FILLRULE}};

static uint32_t ${DATA_STROKE_NAME}[] = {
    ${DATA_STROKE}};

static uint32_t ${DATA_STROKEWIDTH_NAME}[] = {
    ${DATA_STROKEWIDTH}};

static uint8_t ${DATA_STROKELINECAP_NAME}[] = {
    ${DATA_STROKELINECAP}};

static uint8_t ${DATA_STROKELINEJOIN_NAME}[] = {
    ${DATA_STROKELINEJOIN}};

static float ${DATA_STROKEMITERLIMIT_NAME}[] = {
    ${DATA_STROKEMITERLIMIT}};

/* GRADIENT INFO */
/* @brief gradient data
 * Group of 4,
 * For linear gradient 0:startX 1:startY 2:endX 3:endY 4:index
 * For radial gradient 0:centerX 1:centerY 2:radius 4:invalid 4:index
 */
static int16_t ${DATA_GRADIENT_NAME}[][5] = {
    ${DATA_GRADIENT}};

static uint32_t ${DATA_STOPCOLOR_NAME}[] = {
    ${DATA_STOPCOLOR}};

static float ${DATA_STOPOFFSET_NAME}[] = {
    ${DATA_STOPOFFSE}};

static uint16_t ${DATA_STOPCOUNT_NAME}[] = {
    ${DATA_STOPCOUNT}};

/* Clip path info */
static int16_t ${DATA_CLIPPATH_NAME}[][4] = {
    ${DATA_CLIPPATH}};

static int8_t ${DATA_CLIPPATH_TYPE_NAME}[] = {
    ${DATA_CLIPPATH_TYPE}};
#endif // ${HEADER_FILE_MACRO}