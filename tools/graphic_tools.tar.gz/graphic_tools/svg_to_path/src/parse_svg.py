#!/usr/bin/python
# -*- coding: UTF-8 -*-
import re
g_gList = []
g_pathList = []
g_gradientList = []
g_clipPathList = []

class CoreAttributes:
    def __init__(self):
        self.id_ = "none"
        self.lang_ = "none"
        self.tabindex_ = "none"

    def Parse(self, string):
        for name in re.findall(r" id=\"(.+?)\"", string):
            if len(name) != 0:
                self.id_ = name
        for lang in re.findall(r" lang=\"(.+?)\"", string):
            if len(lang) != 0:
                self.lang_ = lang
        for tabindex in re.findall(r" tabindex=\"(.+?)\"", string):
            if len(tabindex) != 0:
                self.tabindex_ = tabindex

class PresentationAttributes:
    def __init__(self):
        self.clipPath_ = "none"
        self.clipRule_ = "nonzero"
        self.fill_ = "none"
        # 颜色类型
        self.fillType_ = "FILL_TYPE_COL"
        self.fillRule_ = "nonzero"
        self.fillOpacity_ = 1.0
        self.opacity_ = 1.0
        self.stroke_ = "none"
        self.strokeType_ = "FILL_TYPE_COL"
        self.strokeWidth_ = 1
        self.strokeOpacity_ = 1.0
        self.strokeDashaary_ = "none"
        self.strokeDashoffset_ = 0
        self.strokeLinecap_ = "butt"
        self.strokeLinejoin_ = "miter"
        self.strokeMiterlimit_ = 4
        self.transform_ = "none"

    def ParseFillAttr(self, string):
        for gObj in reversed(g_gList):
            if gObj.PresentationAttr_.fill_ != "none":
                self.fill_ = g_gList[-1].PresentationAttr_.fill_
                self.fillType_ = g_gList[-1].PresentationAttr_.fillType_
        for fillAttr in re.findall(r" fill=\"(.+?)\"", string):
            if fillAttr[0] == "#":
                self.fillType_ = "FILL_TYPE_COL"
                self.fill_ = fillAttr[1:]
            elif fillAttr[0:3] == "url":
                self.fill_ = FindUrlGradient(fillAttr)
                if self.fill_ != "none":
                    if self.fill_.tag_ == "LinearGradient":
                        self.fillType_ = "FILL_TYPE_LINEAR_GRADIENT"
                    elif self.fill_.tag_ == "RadialGradient":
                        self.fillType_ = "FILL_TYPE_RADIAL_GRADIENT"
            else:
                self.fillType_ = "FILL_TYPE_COL"
                self.fill_ = ConvertStandardColor(fillAttr)

        self.fillOpacity_ = g_gList[-1].PresentationAttr_.fillOpacity_
        for fillOpacityAttr in re.findall(r" fill-opacity=\"(.+?)\"", string):
            self.fillOpacity_ = float(fillOpacityAttr)

        self.fillRule_ = g_gList[-1].PresentationAttr_.fillRule_
        for fillRuleAttr in re.findall(r" fill-rule=\"(.+?)\"", string):
            self.fillRule_ = fillRuleAttr

    def ParseStrokeAttr(self, string):
        for gObj in reversed(g_gList):
            if gObj.PresentationAttr_.stroke_ != "none":
                self.stroke_ = g_gList[-1].PresentationAttr_.stroke_
                self.strokeType_ = g_gList[-1].PresentationAttr_.strokeType_
        for strokeAttr in re.findall(r" stroke=\"(.+?)\"", string):
            if strokeAttr[0] == "#":
                self.strokeType_ = "FILL_TYPE_COL"
                self.stroke_ = strokeAttr[1:]
            elif strokeAttr[0:3] == "url":
                self.stroke_ = FindUrlGradient(strokeAttr)
                if self.stroke_.tag_ == "LinearGradient":
                    self.strokeType_ = "FILL_TYPE_LINEAR_GRADIENT"
                elif self.stroke_.tag_ == "RadialGradient":
                    self.strokeType_ = "FILL_TYPE_RADIAL_GRADIENT"
            else:
                self.stroke_ = ConvertStandardColor(strokeAttr)
                self.strokeType_ = "FILL_TYPE_COL"

        self.strokeWidth_ = g_gList[-1].PresentationAttr_.strokeWidth_
        for strokeWidthAttr in re.findall(r" stroke-width=\"(.+?)\"", string):
            self.strokeWidth_ = float(strokeWidthAttr)

        self.strokeOpacity_ = g_gList[-1].PresentationAttr_.strokeOpacity_
        for strokeOpacityAttr in re.findall(r" stroke-opacity=\"(.+?)\"", string):
            self.strokeOpacity_ = float(strokeOpacityAttr)

        self.strokeLinecap_ = g_gList[-1].PresentationAttr_.strokeLinecap_
        for strokeLinecapAttr in re.findall(r" stroke-linecap=\"(.+?)\"", string):
            self.strokeLinecap_ = strokeLinecapAttr

        self.strokeLinejoin_ = g_gList[-1].PresentationAttr_.strokeLinejoin_
        for strokeLinejoinAttr in re.findall(r" stroke-linejoin=\"(.+?)\"", string):
            self.strokeLinejoin_ = strokeLinejoinAttr

        self.strokeMiterlimit_ = g_gList[-1].PresentationAttr_.strokeMiterlimit_
        for strokeMiterlimitAttr in re.findall(r" stroke-miterlimit=\"(.+?)\"", string):
            self.strokeMiterlimit_ = strokeMiterlimitAttr

    def ParseClipPathAttr(self, string):
        self.clipPath_ = g_gList[-1].PresentationAttr_.clipPath_
        for clipPath in re.findall(r" clip-path=\"(.+?)\"", string):
            self.clipPath_ = FindUrlClipPath(clipPath)
        self.clipRule_ = g_gList[-1].PresentationAttr_.clipRule_
        for clipRule in re.findall(r" clip-rule=\"(.+?)\"", string):
            self.clipRule_ = clipRule

    def ParseOpacityAttr(self, string):
        self.opacity_ = g_gList[-1].PresentationAttr_.opacity_
        for opacity in re.findall(r" opacity=\"(.+?)\"", string):
            self.opacity_ = g_gList[-1].PresentationAttr_.opacity_ * float(opacity)

    def Parse(self, string):
        self.ParseFillAttr(string)
        self.ParseStrokeAttr(string)
        self.ParseClipPathAttr(string)
        self.ParseOpacityAttr(string)

class StopElements:
    def __init__(self):
        self.offset_ = 0.0
        self.stopColor_ = 0xffffff
        self.stopOpacity_ = 1.0

    def Parse(self, string):
        for color in re.findall(r" stop-color=\"(.+?)\"", string):
            self.stopColor_ = int(color[1:], 16)
        for offset in re.findall(r" offset=\"(.+?)\"", string):
            self.offset_ = float(offset)
        for opacity in re.findall(r" stop-opacity=\"(.+?)\"", string):
            self.stopOpacity_ = float(opacity)

class GradientElements:
    def __init__(self, tag):
        self.coreAttr_ = CoreAttributes()
        self.index_ = 0
        self.tag_ = tag
        self.stopList_ = []

    def AddStopToList(self, stopObj):
        self.stopList_.append(stopObj)

    def GetStopListCount(self):
        return len(self.stopList_)

class LinearGradientElements(GradientElements):
    def __init__(self):
        super(LinearGradientElements, self).__init__("LinearGradient")
        self.starX_ = 0.0
        self.starY_ = 0.0
        self.endX_ = 0.0
        self.endY_ = 0.0

    def Parse(self, indexList, string):
        while indexList[0] < len(string) and "/linearGradient" not in string[indexList[0]]:
            attributeList = string[indexList[0]].split(" ")
            if attributeList[0] == "linearGradient":
                self.coreAttr_.Parse(string[indexList[0]])
                for x1 in re.findall(r" x1=\"(.+?)\"", string[indexList[0]]):
                    if len(x1) != 0:
                        self.starX_ = float(x1)
                for y1 in re.findall(r" y1=\"(.+?)\"", string[indexList[0]]):
                    if len(y1) != 0:
                        self.starY_ = float(y1)
                for x2 in re.findall(r" x2=\"(.+?)\"", string[indexList[0]]):
                    if len(x2) != 0:
                        self.endX_ = float(x2)
                for y2 in re.findall(r" y2=\"(.+?)\"", string[indexList[0]]):
                    if len(y2) != 0:
                        self.endY_ = float(y2)
            elif attributeList[0] == "stop":
                stopObj = StopElements()
                stopObj.Parse(string[indexList[0]])
                self.AddStopToList(stopObj)
            indexList[0] += 1

class RadialGradientElements(GradientElements):
    def __init__(self):
        super(RadialGradientElements, self).__init__("RadialGradient")
        self.centerX_ = 0.0
        self.centerY_ = 0.0
        self.radius_ = 0.0

    def Parse(self, indexList, string):
        while indexList[0] < len(string) and "/radialGradient" not in string[indexList[0]]:
            attributeList = string[indexList[0]].split(" ")
            if attributeList[0] == "radialGradient":
                self.coreAttr_.Parse(string[indexList[0]])
                for cx in re.findall(r" cx=\"(.+?)\"", string[indexList[0]]):
                    if len(cx) != 0:
                        self.centerX_ = float(cx)
                for cy in re.findall(r" cy=\"(.+?)\"", string[indexList[0]]):
                    if len(cy) != 0:
                        self.centerY_ = float(cy)
                for r in re.findall(r" r=\"(.+?)\"", string[indexList[0]]):
                    if len(r) != 0:
                        self.radius_ = float(r)
            elif attributeList[0] == "stop":
                stopObj = StopElements()
                stopObj.Parse(string[indexList[0]])
                self.AddStopToList(stopObj)
            indexList[0] += 1

class ClipPathElements:
    '[svg] <clipPath> data'
    def __init__(self):
        self.index_ = 0
        self.coreAttr_ = CoreAttributes()
        self.x_ = 0.0
        self.y_ = 0.0
        self.width_ = 0.0
        self.height_ = 0.0

    def ParseRectTransformAttr(self, string):
        for translate in re.findall(r"translate\((.+?)\)", string):
            translateL = translate.split(' ')
            self.x_ += float(translateL[0])
            if len(translateL) == 2:
                self.y_ += float(translateL[1])

    def ParseRectElement(self, lineData):
        for x in re.findall(r" x=\"(.+?)\"", lineData):
            self.x_ = float(x)
        for y in re.findall(r" y=\"(.+?)\"", lineData):
            self.y_ = float(y)
        for width in re.findall(r" width=\"(.+?)\"", lineData):
            self.width_ = float(width)
        for height in re.findall(r" height=\"(.+?)\"", lineData):
            self.height_ = float(height)
        for transform in re.findall(r" transform=\"(.+?)\"", lineData):
            self.ParseRectTransformAttr(transform)

    def Parse(self, indexList, string):
        while indexList[0] < len(string) and "/clipPath" not in string[indexList[0]]:
            attributeList = string[indexList[0]].split(" ")
            if attributeList[0] == "clipPath":
                self.coreAttr_.Parse(string[indexList[0]])
            elif attributeList[0] == "rect":
                self.ParseRectElement(string[indexList[0]])
            indexList[0] += 1

class GElements:
    '[svg] <g> data'
    def __init__(self):
        self.coreAttr_ = CoreAttributes()
        self.PresentationAttr_ = PresentationAttributes()

    def Parse(self, string):
        self.PresentationAttr_.Parse(string)

class PathElements:
    '[svg] <Path> data'
    SVG_PATH_D_NAME = ('z', 'Z', 'm', 'M', 'l', 'L', \
        'h', 'H', 'v', 'V', 'q', 'Q', 'c', 'C', 't', 'T', 's', 'S', 'a', 'A')
    number_sym = '0123456789.+-'

    def __init__(self):
        self.cmdList_ = []
        self.cmdRelativeFlag_ = []
        self.dataList_ = []
        self.coreAttr_ = CoreAttributes()
        self.PresentationAttr_ = PresentationAttributes()

    def RelativeToAbsolute(self):
        curIndex = 0
        curPaintX = 0.0
        curPaintY = 0.0
        for index, cmd in enumerate(self.cmdList_):
            if cmd == '2' or cmd == '4' or cmd == '14':
                if self.cmdRelativeFlag_[index] != 0:
                    curPaintX += float(self.dataList_[curIndex])
                    self.dataList_[curIndex] = str("%.6f" % curPaintX)
                    curIndex += 1
                    curPaintY += float(self.dataList_[curIndex])
                    self.dataList_[curIndex] = str("%.6f" % curPaintY)
                    curIndex += 1
                else:
                    curPaintX = float(self.dataList_[curIndex])
                    curIndex += 1
                    curPaintY = float(self.dataList_[curIndex])
                    curIndex += 1
            elif cmd == '0':
                curPaintX = 0
                curPaintY = 0
            elif cmd == '6':
                if self.cmdRelativeFlag_[index] != 0:
                    curPaintX += float(self.dataList_[curIndex])
                    self.dataList_[curIndex] = str("%.6f" % curPaintX)
                    curIndex += 1
                else:
                    curPaintX = float(self.dataList_[curIndex])
                    curIndex += 1
            elif cmd == '8':
                if self.cmdRelativeFlag_[index] != 0:
                    curPaintY += float(self.dataList_[curIndex])
                    self.dataList_[curIndex] = str("%.6f" % curPaintY)
                    curIndex += 1
                else:
                    curPaintY = float(self.dataList_[curIndex])
                    curIndex += 1
            elif cmd == '10' or cmd == '16':
                if self.cmdRelativeFlag_[index] == 0:
                    curIndex += 2
                    curPaintX = float(self.dataList_[curIndex])
                    curIndex += 1
                    curPaintY = float(self.dataList_[curIndex])
                    curIndex += 1
                else:
                    self.dataList_[curIndex] = str("%.6f" % (curPaintX + float(self.dataList_[curIndex])))
                    curIndex += 1
                    self.dataList_[curIndex] = str("%.6f" % (curPaintY + float(self.dataList_[curIndex])))
                    curIndex += 1
                    curPaintX += float(self.dataList_[curIndex])
                    self.dataList_[curIndex] = str("%.6f" % curPaintX)
                    curIndex += 1
                    curPaintY += float(self.dataList_[curIndex])
                    self.dataList_[curIndex] = str("%.6f" % curPaintY)
                    curIndex += 1
            elif cmd == '12':
                if self.cmdRelativeFlag_[index] == 0:
                    curIndex += 4
                    curPaintX = float(self.dataList_[curIndex])
                    curIndex += 1
                    curPaintY = float(self.dataList_[curIndex])
                    curIndex += 1
                else:
                    self.dataList_[curIndex] = str("%.6f" % (curPaintX + float(self.dataList_[curIndex])))
                    curIndex += 1
                    self.dataList_[curIndex] = str("%.6f" % (curPaintY + float(self.dataList_[curIndex])))
                    curIndex += 1
                    self.dataList_[curIndex] = str("%.6f" % (curPaintX + float(self.dataList_[curIndex])))
                    curIndex += 1
                    self.dataList_[curIndex] = str("%.6f" % (curPaintY + float(self.dataList_[curIndex])))
                    curIndex += 1
                    curPaintX += float(self.dataList_[curIndex])
                    self.dataList_[curIndex] = str("%.6f" % curPaintX)
                    curIndex += 1
                    curPaintY += float(self.dataList_[curIndex])
                    self.dataList_[curIndex] = str("%.6f" % curPaintY)
                    curIndex += 1
            elif cmd == '18':
                curIndex += 3
                arcFlag = int(self.dataList_[curIndex], 10)
                del self.dataList_[curIndex]
                sweepFlag = int(self.dataList_[curIndex], 10)
                del self.dataList_[curIndex]
                if arcFlag == 0 and sweepFlag == 1:
                    self.cmdList_[index] = '18'
                elif arcFlag == 0 and sweepFlag == 0:
                    self.cmdList_[index] = '20'
                elif arcFlag == 1 and sweepFlag == 1:
                    self.cmdList_[index] = '22'
                elif arcFlag == 1 and sweepFlag == 0:
                    self.cmdList_[index] = '24'

                if self.cmdRelativeFlag_[index] == 0:
                    curPaintX = float(self.dataList_[curIndex])
                    curIndex += 1
                    curPaintY = float(self.dataList_[curIndex])
                    curIndex += 1
                else:
                    curPaintX += float(self.dataList_[curIndex])
                    self.dataList_[curIndex] = str("%.6f" % curPaintX)
                    curIndex += 1
                    curPaintY += float(self.dataList_[curIndex])
                    self.dataList_[curIndex] = str("%.6f" % curPaintY)
                    curIndex += 1

    def ParseDAttrCmd(self, index, data):
        cmdIndex = self.SVG_PATH_D_NAME.index(data)
        if cmdIndex == 0 or cmdIndex == 1:
            self.cmdRelativeFlag_.append(0)
            return 0
        else:
            if cmdIndex % 2 == 0:
                self.cmdRelativeFlag_.append(1)
                return cmdIndex
            else:
                self.cmdRelativeFlag_.append(0)
                return cmdIndex - 1

    def ParseDAttr(self, string):
        for dAttr in re.findall(r" d=\"(.+?)\"", string):
            cmdIndex = 0
            consecutiveFlag = 0
            startIndex = 0
            endIndex = 0
            for index, data in enumerate(dAttr):
                endIndex = index
                if data in self.SVG_PATH_D_NAME:
                    if consecutiveFlag == 1:
                        self.dataList_.append(dAttr[startIndex:endIndex])
                        consecutiveFlag = 0
                    self.cmdList_.append(str(self.ParseDAttrCmd(index, data)))
                elif data == ' ' or data == ',':
                    if consecutiveFlag == 1:
                        self.dataList_.append(dAttr[startIndex:endIndex])
                        consecutiveFlag = 0
                elif data in self.number_sym:
                    if consecutiveFlag == 0:
                        startIndex = index
                        consecutiveFlag = 1
            if consecutiveFlag == 1:
                self.dataList_.append(dAttr[startIndex:endIndex + 1])
                consecutiveFlag = 0
            self.RelativeToAbsolute()

    def Parse(self, string):
        self.ParseDAttr(string)
        self.PresentationAttr_.Parse(string)

###### interface funcition ######
def FindUrlClipPath(url):
    global g_clipPathList
    if len(g_clipPathList) == 0:
        print("不存在ClipPath元素")
        return "none"
    for obj in g_clipPathList:
        if url[5:-1] == obj.coreAttr_.id_:
            return obj
    print("url引用不存在")
    return "none"

def FindUrlGradient(url):
    global g_gradientList
    if len(g_gradientList) == 0:
        print("不存在Gradient元素")
        return "none"
    for obj in g_gradientList:
        if url[5:-1] == obj.coreAttr_.id_:
            return obj
    print("url引用不存在")
    return "none"

def ConvertStandardColor(colorName):
    if colorName == 'white':
        return 'FFFFFF'
    elif colorName == 'black':
        return '000000'
    elif colorName == 'red':
        return 'FF0000'
    elif colorName == 'maroon':
        return '800000'
    elif colorName == 'yellow':
        return 'FFFF00'
    elif colorName == 'olive':
        return '808000'
    elif colorName == 'lime':
        return '00ff00'
    elif colorName == 'green':
        return '008000'
    elif colorName == 'cyan':
        return '00FFFF'
    elif colorName == 'teal':
        return '008080'
    elif colorName == 'blue':
        return '0000ff'
    elif colorName == 'navy':
        return '000080'
    elif colorName == 'magenta':
        return 'FF00FF'
    elif colorName == 'purple':
        return '080080'
    elif colorName == 'orange':
        return 'FFA500'
    else:
        return 'none'

def ParseDefsElement(index, fileLineData):
    global g_clipPathList
    global g_gradientList
    indexList = [index]
    while indexList[0] < len(fileLineData) and fileLineData[indexList[0]] != "/defs":
        lineList = fileLineData[indexList[0]].split(' ')
        if lineList[0] == "clipPath":
            clipPathObj = ClipPathElements()
            clipPathObj.Parse(indexList, fileLineData)
            clipPathObj.index_ = len(g_clipPathList)
            g_clipPathList.append(clipPathObj)
        elif lineList[0] == "radialGradient":
            radialGradientObj = RadialGradientElements()
            radialGradientObj.Parse(indexList, fileLineData)
            radialGradientObj.index_ = len(g_gradientList)
            g_gradientList.append(radialGradientObj)
        elif lineList[0] == "linearGradient":
            linearGradientObj = LinearGradientElements()
            linearGradientObj.Parse(indexList, fileLineData)
            linearGradientObj.index_ = len(g_gradientList)
            g_gradientList.append(linearGradientObj)
        indexList[0] += 1
    return indexList[0]

def ParsePathElement(lineData):
    global g_pathList
    pathObj = PathElements()
    pathObj.Parse(lineData)
    g_pathList.append(pathObj)

def PushGElement(lineData):
    global g_gList
    gObj = GElements()
    gObj.Parse(lineData)
    g_gList.append(gObj)

def PopGElement():
    obj = g_gList.pop()
    del obj

def ParseSvgToData(file):
    print('parse_svg.py当前处理文件', file)
    with open(file, 'r') as f:
        allLineData = re.findall(r"<(.+?)>", f.read())

    # 添加最底层的默认属性容器。防止访问g_gList为空。
    g_gList.append(GElements())

    # 遍历svg全文，将defs元素下的元素，缓存
    for index, line in enumerate(allLineData):
        lineList = line.split(' ')
        if lineList[0] == "defs":
            dealIndex = ParseDefsElement(index, allLineData)

    notParse = 0
    for line in allLineData:
        lineList = line.split(' ')
        if notParse != 0:
            if lineList[0] == "/defs":
                notParse -= 1
            continue

        if lineList[0] == "defs":
            notParse += 1
        elif lineList[0] == "g" or lineList[0] == "svg":
            PushGElement(line)
        elif lineList[0] == "/g"or lineList[0] == "/svg":
            PopGElement()
        elif lineList[0] == "path":
            ParsePathElement(line)
    f.close()
