import ctypes
import platform

# 定义参数类型
class ext_cmd_count(ctypes.Structure):
    _fields_ = [("enable", ctypes.c_bool),
                ("move_count", ctypes.c_uint16),
                ("line_count", ctypes.c_uint16),
                ("quad_count", ctypes.c_uint16),
                ("cubic_count", ctypes.c_uint16),
                ("arc_count", ctypes.c_uint16)]

class ext_vau_path(ctypes.Structure):
    _fields_ = [("cmd_count", ext_cmd_count),
                ("cmds", ctypes.POINTER(ctypes.c_ubyte)),
                ("cmd_num", ctypes.c_uint32),
                ("datas", ctypes.POINTER(ctypes.c_float)),
                ("data_num", ctypes.c_uint32)]

class ext_vau_dash(ctypes.Structure):
    _fields_ = [
        ('enable', ctypes.c_bool),
        ('array', ctypes.POINTER(ctypes.c_float)),
        ('count', ctypes.c_uint),
        ('offset', ctypes.c_float),
        ('reset', ctypes.c_bool),
    ]

class ext_vau_stops(ctypes.Structure):
    _fields_ = [("colors", ctypes.POINTER(ctypes.c_uint32)),
                ("offsets", ctypes.POINTER(ctypes.c_float)),
                ("num", ctypes.c_uint8)]

class ext_vau_point(ctypes.Structure):
    _fields_ = [("x", ctypes.c_int),
                ("y", ctypes.c_int)]

class ext_vau_linear_gradient_attr(ctypes.Structure):
    _fields_ = [("start_point", ext_vau_point),
                ("end_point", ext_vau_point)]

class ext_vau_radial_gradient_attr(ctypes.Structure):
    _fields_ = [("radius", ctypes.c_uint16),
                ("center", ext_vau_point)]


class rgb_opa(ctypes.Structure):
    _fields_ = [("rgb", ctypes.c_uint32, 24),
                ("opa", ctypes.c_uint32, 8)]

class ext_vau_solid_attr(ctypes.Union):
    _fields_ = [("rgb_opa", rgb_opa),
                ("color", ctypes.c_uint32)]

class ext_vau_sweep_gradient_attr(ctypes.Structure):
    _fields_ = [("center", ext_vau_point),
                ("start_angle", ctypes.c_uint32)]

class attr_union(ctypes.Union):
    _fields_ = [("linear", ext_vau_linear_gradient_attr),
                ("radial", ext_vau_radial_gradient_attr),
                ("sweep", ext_vau_sweep_gradient_attr)]

class ext_vau_gradient_attr(ctypes.Structure):
    _fields_ = [("tile_mode", ctypes.c_int),
                ("stops", ext_vau_stops),
                ("attr", attr_union)]

class paint_attr_union(ctypes.Union):
    _fields_ = [("solid", ext_vau_solid_attr),
                ("gradient", ext_vau_gradient_attr)]

class ext_vau_paint_attr(ctypes.Structure):
    _fields_ = [("paint_type", ctypes.c_int),
                ("paint_attr_union", paint_attr_union)]

class ext_vau_stroke_attr(ctypes.Structure):
    _fields_ = [
        ('width', ctypes.c_float),
        ('dash', ext_vau_dash),
        ('cap', ctypes.c_int),
        ('join', ctypes.c_int),
        ('miter_limit', ctypes.c_float),
        ('paint_attr', ext_vau_paint_attr),
    ]

class ext_vau_fill_attr(ctypes.Structure):
    _fields_ = [('type', ctypes.c_int),
                ('paint_attr', ext_vau_paint_attr)]

global lib
# 加载动态库
if platform.system().lower() == "windows":
    lib = ctypes.CDLL(r".\gpu_rm.dll")
elif platform.system().lower() == "linux":
    lib = ctypes.cdll.LoadLibrary(r"./gpu_rm.so")

# 调用第一个接口
lib.vau_draw_create_arc_fit_path.argtypes = [ctypes.POINTER(ext_vau_path), ctypes.POINTER(ext_vau_path)]
lib.vau_create_stroke_dash_path.argtypes = [ctypes.POINTER(ext_vau_path), ctypes.POINTER(ext_vau_stroke_attr),
                                            ctypes.POINTER(ext_vau_path)]
lib.vau_create_stroke_to_fill_path.argtypes = [ctypes.POINTER(ext_vau_path), ctypes.POINTER(ext_vau_stroke_attr),
                                               ctypes.POINTER(ext_vau_path), ctypes.POINTER(ext_vau_fill_attr),
                                               ctypes.c_int]

# 定义接口返回值类型
lib.vau_draw_create_arc_fit_path.restype = ctypes.c_int
lib.vau_create_stroke_dash_path.restype = ctypes.c_int
lib.vau_create_stroke_to_fill_path.restype = ctypes.c_int

def VauDrawHasArc(pathObj, orgCmds):
    for cmd in orgCmds:
        # print("cmd = ", cmd)
        if 18 <= cmd <= 25:
            return True
    return False

def UseRmFunction(pathObj):
    # 将Python列表转换为C数组
    cmdList = pathObj.cmdList_
    orgCmds = (ctypes.c_ubyte * len(cmdList))()
    for i, cmd in enumerate(cmdList):
        orgCmds[i] = ctypes.c_ubyte(int(cmd))

    dataList = pathObj.dataList_
    orgDatas = (ctypes.c_float * len(dataList))()
    for i, data in enumerate(dataList):
        orgDatas[i] = ctypes.c_float(float(data))

    # 构造输入参数
    org = ext_vau_path()
    org.cmds = orgCmds
    org.datas = orgDatas
    org.cmd_num = ctypes.c_uint32(len(cmdList))
    org.data_num = ctypes.c_uint32(len(dataList))

    fit = ext_vau_path()

    # 调用arc函数
    has_arc = VauDrawHasArc(pathObj, orgCmds)
    if has_arc:
        result = lib.vau_draw_create_arc_fit_path(ctypes.byref(org), ctypes.byref(fit))
    else:
        fit = org

    # 调用dash函数
    path = fit
    stroke = ext_vau_stroke_attr()
    stroke.dash.enable = False
    dash_path = ext_vau_path()

    if stroke.dash.enable:
        result2 = lib.vau_create_stroke_dash_path(ctypes.byref(path), ctypes.byref(stroke), ctypes.byref(dash_path))
    else:
        dash_path = path

    # 调用stroke_to_fill函数
    stroke_path = dash_path

    outstrokeLinecap = pathObj.PresentationAttr_.strokeLinecap_
    if outstrokeLinecap == "butt":
        outstrokeLinecap = 0
    elif outstrokeLinecap == "round":
        outstrokeLinecap = 1
    elif outstrokeLinecap == "square":
        outstrokeLinecap = 2

    outstrokeLinejoin = pathObj.PresentationAttr_.strokeLinejoin_
    if outstrokeLinejoin == "miter":
        outstrokeLinejoin = 0
    elif outstrokeLinejoin == "round":
        outstrokeLinejoin = 1
    elif outstrokeLinejoin == "bevel":
        outstrokeLinejoin = 2

    stroke_attr = ext_vau_stroke_attr()
    stroke_attr.width = round(pathObj.PresentationAttr_.strokeWidth_ + 0.1)
    stroke_attr.cap = ctypes.c_int(outstrokeLinecap)
    stroke_attr.join = ctypes.c_int(outstrokeLinejoin)
    stroke_attr.miter_limit =  ctypes.c_float(float(pathObj.PresentationAttr_.strokeMiterlimit_))

    strokeType_ = pathObj.PresentationAttr_.strokeType_
    stroke = pathObj.PresentationAttr_.stroke_
    strokeOpa = round(pathObj.PresentationAttr_.strokeOpacity_ * 255)

    if stroke != "none":
        if strokeType_ == "FILL_TYPE_LINEAR_GRADIENT":
            stroke_attr.paint_attr.paint_type = 2
            outStroke = (strokeOpa << 24)
        elif strokeType_ == "FILL_TYPE_RADIAL_GRADIENT":
            stroke_attr.paint_attr.paint_type = 3
            outStroke = (strokeOpa << 24)
        elif strokeType_ == "FILL_TYPE_COL":
            stroke_attr.paint_attr.paint_type = 0
            outStroke = (strokeOpa << 24) + int(stroke, 16)
            stroke_attr.paint_attr.paint_attr_union.solid.color = ctypes.c_uint32(outStroke)

    fill_path = ext_vau_path()
    fill_attr = ext_vau_fill_attr()
    fill_attr.type = 1
    fill_attr.paint_attr = stroke_attr.paint_attr

    render_quality = 2  # 对应EXT_VAU_RENDER_QUALITY_BETTER
    if render_quality == 2:
        mode = 0 # 对应EXT_BEZIER_MODE_LINE_AVG
    else:
        mode = 1 # 对应EXT_BEZIER_MODE_BEZIER_4

    if stroke != "none":
        result3 = lib.vau_create_stroke_to_fill_path(ctypes.byref(stroke_path), ctypes.byref(stroke_attr),
                                                     ctypes.byref(fill_path), ctypes.byref(fill_attr),
                                                     ctypes.c_int(mode))

        cmds = ctypes.cast(fill_path.cmds, ctypes.POINTER(ctypes.c_ubyte * fill_path.cmd_num)).contents
        datas = ctypes.cast(fill_path.datas, ctypes.POINTER(ctypes.c_float * fill_path.data_num)).contents

        # 将c数组转换为Python列表
        cmd_list = [str(cmds[i]) for i in range(fill_path.cmd_num)]
        data_list = [str(datas[i]) for i in range(fill_path.data_num)]

    else:
        cmd_list = [str(dash_path.cmds[i]) for i in range(dash_path.cmd_num)]
        data_list = [str(dash_path.datas[i]) for i in range(dash_path.data_num)]

    return cmd_list, data_list