#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys,os,re
from convert_shapes import ConvertShapesToPath
from string import Template
import parse_svg
from rm_stroke import UseRmFunction
import argparse
import struct
import copy

# H heat need data
g_headerArray = []

g_cmdsArray = []
g_cmdIndexArray = []
g_cmdNumArray = []
g_datasArray = []
g_dataIndexArray = []
g_dataNumArray = []
g_opacityArray = []
g_paintStyleArray = []

g_paintTypeArray = []
g_fillArray = []
g_fillRuleArray = []
g_strokeColorArray = []
g_strokeWidthArray = []
g_strokeLinecapArray = []
g_strokeLinejoinArray = []
g_strokeMiterlimitArray = []

g_gradient = []
g_stopColor = []
g_stopOffset = []
g_stopCount = []

g_clipPathType = []
g_clipPath = []
# out path
outDirPath = os.getcwd() + "/out"

# create .h file and write parse data to .h file function
def ConvertSmallHump(dataStr):
    humpStr = list(ConvertBigHump(dataStr))
    humpStr[0] = humpStr[0].lower()
    return ''.join(humpStr)

def ConvertBigHump(dataStr):
    stringList = re.split("[_ -]", str(dataStr))
    othersCapital = [word.capitalize() for word in stringList]
    humpStr = ''.join(othersCapital)
    return humpStr

def ConvertAllLower(dataStr):
    stringList = re.split("[_ -]", str(dataStr))
    othersCapital = [word.upper() for word in stringList]
    lowerStr = '_'.join(othersCapital)
    return lowerStr

def ReadDataToH():
    cmdIndex = 0
    dataIndex = 0

    g_headerArray.append(str(len(parse_svg.g_pathList)))
    g_headerArray.append(str(len(parse_svg.g_gradientList)))
    stopNum = 0
    for gradientObj in parse_svg.g_gradientList:
        stopNum += gradientObj.GetStopListCount()
    g_headerArray.append(str(stopNum))
    g_headerArray.append(str(len(parse_svg.g_clipPathList)))
    cmdNum = 0
    dataNum = 0
    for pathObj in parse_svg.g_pathList:
        cmdNum += len(pathObj.cmdList_)
        dataNum += len(pathObj.dataList_)
    g_headerArray.append(str(cmdNum))
    g_headerArray.append(str(dataNum))
    g_headerArray.append(str(0))

    for clipPatObj in parse_svg.g_clipPathList:
        g_clipPath.append(str(round(clipPatObj.x_)))
        g_clipPath.append(str(round(clipPatObj.y_)))
        g_clipPath.append(str(round(clipPatObj.width_)))
        g_clipPath.append(str(round(clipPatObj.height_)))

    for gradientObj in parse_svg.g_gradientList:
        if gradientObj.tag_ == "RadialGradient":
            g_gradient.append(str(round(gradientObj.centerX_)))
            g_gradient.append(str(round(gradientObj.centerY_)))
            g_gradient.append(str(round(gradientObj.radius_)))
            g_gradient.append(str(0))
        elif gradientObj.tag_ == "LinearGradient":
            g_gradient.append(str(round(gradientObj.starX_)))
            g_gradient.append(str(round(gradientObj.starY_)))
            g_gradient.append(str(round(gradientObj.endX_)))
            g_gradient.append(str(round(gradientObj.endY_)))
        g_gradient.append(str(len(g_stopColor)))
        g_stopCount.append(str(gradientObj.GetStopListCount()))
        for stopObj in gradientObj.stopList_:
            g_stopOffset.append(str(stopObj.offset_))
            opacity = round(stopObj.stopOpacity_* 255)
            g_stopColor.append(str("0x%X" % opacity) + str("%X" % stopObj.stopColor_))

    print("path长度：", len(parse_svg.g_pathList))
    for pathObj in parse_svg.g_pathList:
        g_cmdIndexArray.append(str(cmdIndex))
        g_cmdsArray.extend(pathObj.cmdList_)
        g_cmdNumArray.append(str(len(pathObj.cmdList_)))
        cmdIndex += len(pathObj.cmdList_)
        g_dataIndexArray.append(str(dataIndex))
        g_datasArray.extend(pathObj.dataList_)
        g_dataNumArray.append(str(len(pathObj.dataList_)))
        dataIndex += len(pathObj.dataList_)
        g_opacityArray.append(str(round(pathObj.PresentationAttr_.opacity_ * 255)))

        tempFill = pathObj.PresentationAttr_.fill_
        tempFillOpacity = round(pathObj.PresentationAttr_.fillOpacity_ * 255)
        tempStroke = pathObj.PresentationAttr_.stroke_
        tempStrokeOpacity = round(pathObj.PresentationAttr_.strokeOpacity_ * 255)
        if tempFill != "none" and tempStroke != "none":
            g_paintStyleArray.append("3")
        else:
            if tempFill != "none":
                g_paintStyleArray.append("2")
            if tempStroke != "none":
                g_paintStyleArray.append("1")

        if pathObj.PresentationAttr_.fill_ != 'none':
            if pathObj.PresentationAttr_.fillType_ == "FILL_TYPE_LINEAR_GRADIENT":
                g_paintTypeArray.append("1")
                temp = (tempFillOpacity << 24) + tempFill.index_
                g_fillArray.append(str("0x%X" % temp))
            elif pathObj.PresentationAttr_.fillType_ == "FILL_TYPE_RADIAL_GRADIENT":
                g_paintTypeArray.append("2")
                temp = (tempFillOpacity << 24) + tempFill.index_
                g_fillArray.append(str("0x%X" % temp))
            else:
                g_paintTypeArray.append("0")
                if tempFill == "none":
                    g_fillArray.append(str("0x%X" % tempFillOpacity) + '000000')
                else:
                    g_fillArray.append(str("0x%X" % tempFillOpacity) + tempFill)

            if pathObj.PresentationAttr_.fillRule_ == 'evenodd':
                g_fillRuleArray.append('1')
            else:
                g_fillRuleArray.append('0')

        if pathObj.PresentationAttr_.stroke_ != 'none':
            if pathObj.PresentationAttr_.strokeType_ == "FILL_TYPE_LINEAR_GRADIENT":
                g_paintTypeArray.append("1")
                temp = (tempStrokeOpacity << 24) + tempStroke.index_
                g_strokeColorArray.append(str("0x%X" % temp))
            elif pathObj.PresentationAttr_.strokeType_ == "FILL_TYPE_RADIAL_GRADIENT":
                g_paintTypeArray.append("2")
                temp = (tempStrokeOpacity << 24) + tempStroke.index_
                g_strokeColorArray.append(str("0x%X" % temp))
            else:
                g_paintTypeArray.append("0")
                if tempStroke == "none":
                    g_strokeColorArray.append(str("0x%X" % tempStrokeOpacity) + '000000')
                else:
                    g_strokeColorArray.append(str("0x%X" % tempStrokeOpacity) + tempStroke)

        g_strokeWidthArray.append(str(pathObj.PresentationAttr_.strokeWidth_))

        if pathObj.PresentationAttr_.strokeLinecap_ == "butt":
            g_strokeLinecapArray.append('0')
        elif pathObj.PresentationAttr_.strokeLinecap_ == "round":
            g_strokeLinecapArray.append('1')
        elif pathObj.PresentationAttr_.strokeLinecap_ == "square":
            g_strokeLinecapArray.append('2')

        if pathObj.PresentationAttr_.strokeLinejoin_ == "miter":
            g_strokeLinejoinArray.append('0')
        elif pathObj.PresentationAttr_.strokeLinejoin_ == "round":
            g_strokeLinejoinArray.append('1')
        elif pathObj.PresentationAttr_.strokeLinejoin_ == "bevel":
            g_strokeLinejoinArray.append('2')

        g_strokeMiterlimitArray.append(str(pathObj.PresentationAttr_.strokeMiterlimit_))

        if pathObj.PresentationAttr_.clipPath_ != "none":
            g_clipPathType.append(str(pathObj.PresentationAttr_.clipPath_.index_))
        else:
            g_clipPathType.append("-1")

def OutPutPathFile(file):
    ReadDataToH()
    filePath = os.path.dirname(file)
    fileNameNoSuffix = os.path.split(file)[-1].split('.')[0]
    newFileName = fileNameNoSuffix + '.h'
    fileNameSmallHump = fileNameNoSuffix[0].lower() + fileNameNoSuffix[1:]
    lines = []
    # 生成类头文件
    hTemplateFile = open(r'pathHtemplate.tpl', 'r')
    newCreateHFile = open(outDirPath +"/" + newFileName, 'w')
    hTempleateData = Template(hTemplateFile.read())
    lines.append(hTempleateData.substitute(
        HEADER_FILE_MACRO = ConvertAllLower(fileNameNoSuffix) + "_H",
        HEADER_NAME="g_" + fileNameSmallHump + "Header",
        HEADER=', '.join(g_headerArray),
        CMDS_NAME = "g_" + fileNameSmallHump + "Cmds",
        CMDS = ', '.join(g_cmdsArray),
        CMD_INDEX_NAME = "g_" + fileNameSmallHump + "CmdIndex",
        CMD_INDEX = ', '.join(g_cmdIndexArray),
        CMD_NUM_NAME = "g_" + fileNameSmallHump + "CmdNum",
        CMD_NUM = ', '.join(g_cmdNumArray),
        DATAS_NAME = "g_" + fileNameSmallHump + "Datas",
        DATAS = ', '.join(g_datasArray),
        DATA_INDEX_NAME = "g_" + fileNameSmallHump + "DataIndex",
        DATA_INDEX = ', '.join(g_dataIndexArray),
        DATA_NUM_NAME = "g_" + fileNameSmallHump + "DataNum",
        DATA_NUM = ', '.join(g_dataNumArray),
        DATA_OPACITY_NAME = "g_" + fileNameSmallHump + "opacity",
        DATA_OPACITY = ', '.join(g_opacityArray),
        DATA_PAINTSTYLE_NAME = "g_" + fileNameSmallHump + "PaintStyle",
        DATA_PAINTSTYLE = ', '.join(g_paintStyleArray),
        DATA_FILLTYPE_NAME = "g_" + fileNameSmallHump + "FillType",
        DATA_FILLTYPE = ', '.join(g_paintTypeArray),
        DATA_FILL_NAME = "g_" + fileNameSmallHump + "Fill",
        DATA_FILL = ', '.join(g_fillArray),
        DATA_FILLRULE_NAME = "g_" + fileNameSmallHump + "FillRule",
        DATA_FILLRULE = ', '.join(g_fillRuleArray),
        DATA_STROKE_NAME = "g_" + fileNameSmallHump + "Stroke",
        DATA_STROKE = ', '.join(g_strokeColorArray),
        DATA_STROKEWIDTH_NAME = "g_" + fileNameSmallHump + "StrokeWidth",
        DATA_STROKEWIDTH = ', '.join(g_strokeWidthArray),

        DATA_STROKELINECAP_NAME="g_" + fileNameSmallHump + "StrokeLinecap",
        DATA_STROKELINECAP=', '.join(g_strokeLinecapArray),
        DATA_STROKELINEJOIN_NAME="g_" + fileNameSmallHump + "StrokeLinejoin",
        DATA_STROKELINEJOIN=', '.join(g_strokeLinejoinArray),
        DATA_STROKEMITERLIMIT_NAME="g_" + fileNameSmallHump + "StrokeMiterlimit",
        DATA_STROKEMITERLIMIT=', '.join(g_strokeMiterlimitArray),

        DATA_GRADIENT_NAME = "g_" + fileNameSmallHump + "Gradient",
        DATA_GRADIENT = ', '.join(g_gradient),
        DATA_STOPCOLOR_NAME = "g_" + fileNameSmallHump + "StopColor",
        DATA_STOPCOLOR = ', '.join(g_stopColor),
        DATA_STOPOFFSET_NAME = "g_" + fileNameSmallHump + "StopOffset",
        DATA_STOPOFFSE = ', '.join(g_stopOffset),
        DATA_STOPCOUNT_NAME = "g_" + fileNameSmallHump + "StopCount",
        DATA_STOPCOUNT = ', '.join(g_stopCount),
        DATA_CLIPPATH_NAME = "g_" + fileNameSmallHump + "clipPath",
        DATA_CLIPPATH = ', '.join(g_clipPath),
        DATA_CLIPPATH_TYPE_NAME = "g_" + fileNameSmallHump + "clipPathType",
        DATA_CLIPPATH_TYPE = ', '.join(g_clipPathType)
        ))
    newCreateHFile.writelines(lines)
    newCreateHFile.close()
    hTemplateFile.close()

'''
struct header {
    uint16_t pathNum;           // sizeof(pathInfo) * pathNum;
    uint16_t gradientNum;       // sizeof(gradientInfo) * gradientNum;
    uint16_t stopNum;           // sizeof(stopInfo) * stopNum;
    uint16_t clipPathNum;       // sizeof(clipPathInfo) * clipPathNum;
    uint32_t cmdNum;            // sizeof(uint8_t) * cmdNum
    uint32_t dataNum;           // sizeof(float) * dataNum
    uint32_t animaNum;          // sizeof(animaInfo) * animaNum
}
'''
def hasStroke(pathObj, newPathObj):

    finalCmds, finalDatas = UseRmFunction(pathObj)

    # 创建一个新的path对象，将stroke功能剥离
    newPathObj.cmdList_ = finalCmds
    newPathObj.dataList_ = finalDatas

    newPathObj.PresentationAttr_.fillType_ = pathObj.PresentationAttr_.strokeType_

    newPathObj.PresentationAttr_.fillOpacity_ = pathObj.PresentationAttr_.strokeOpacity_
    newPathObj.PresentationAttr_.fill_ = pathObj.PresentationAttr_.stroke_
    fillType_ = newPathObj.PresentationAttr_.fillType_

    if (fillType_ == "FILL_TYPE_LINEAR_GRADIENT" or fillType_ == "FILL_TYPE_RADIAL_GRADIENT"):
        newPathObj.PresentationAttr_.fill_.index_ = pathObj.PresentationAttr_.stroke_.index_

    newPathObj.PresentationAttr_.stroke_ = 'none'
    pathObj.PresentationAttr_.stroke_ = 'none'

    newPathObj.PresentationAttr_.fillRule_ = 2  # stroke转fill，需要将此置为nonzero

    newPathObj.PresentationAttr_.clipPath_ = pathObj.PresentationAttr_.clipPath_
    newPathObj.PresentationAttr_.clipRule_ = pathObj.PresentationAttr_.clipRule_
    newPathObj.PresentationAttr_.opacity_ = pathObj.PresentationAttr_.opacity_

    return newPathObj

def WriteToHeader(fb):
    cmdNum = 0
    dataNum = 0

    new_list = []
    for i in range(len(parse_svg.g_pathList)):
        pathObj = parse_svg.g_pathList[i]
        if pathObj.PresentationAttr_.fill_ != 'none' and pathObj.PresentationAttr_.stroke_ == 'none':

            finalCmds, finalDatas = UseRmFunction(pathObj)
            pathObj.cmdList_ = finalCmds
            pathObj.dataList_ = finalDatas
            cmdNum += len(pathObj.cmdList_)
            dataNum += len(pathObj.dataList_)
            new_list.append(pathObj)

        elif pathObj.PresentationAttr_.fill_ != 'none' and pathObj.PresentationAttr_.stroke_ != 'none':

            new_obj = copy.deepcopy(pathObj)
            new_obj.PresentationAttr_.stroke_ = 'none'
            finalCmds, finalDatas = UseRmFunction(new_obj)
            new_obj.cmdList_ = finalCmds
            new_obj.dataList_ = finalDatas
            cmdNum += len(new_obj.cmdList_)
            dataNum += len(new_obj.dataList_)
            new_list.append(new_obj)

            newPathObj = parse_svg.PathElements()
            newPathObj = hasStroke(pathObj, newPathObj)
            cmdNum += len(newPathObj.cmdList_)
            dataNum += len(newPathObj.dataList_)
            new_list.append(newPathObj)

        elif pathObj.PresentationAttr_.fill_ == 'none' and pathObj.PresentationAttr_.stroke_ != 'none':

            newPathObj = parse_svg.PathElements()
            newPathObj = hasStroke(pathObj, newPathObj)
            new_list.append(newPathObj)
            cmdNum += len(newPathObj.cmdList_)
            dataNum += len(newPathObj.dataList_)

    parse_svg.g_pathList = new_list
    headBin = struct.pack('=H', len(parse_svg.g_pathList))
    stopNum = 0
    headBin += struct.pack('=H', len(parse_svg.g_gradientList))
    for gradientObj in parse_svg.g_gradientList:
        stopNum += gradientObj.GetStopListCount()
    headBin += struct.pack('=H', stopNum)
    headBin += struct.pack('=H', len(parse_svg.g_clipPathList))
    headBin += struct.pack('=I', cmdNum)
    headBin += struct.pack('=I', dataNum)
    headBin += struct.pack('=I', 0)
    fb.write(headBin)

'''
struct paintInfo {
    uint8_t opacity;             // paint 透明度
    uint8_t paintStyle;          // paint 填充风格, stroke填充(1)/fill填充(2)/fill + stroke填充(3) VAU中对应为paint_mode
    uint8_t paintType;           // paint 填充类型，纯色（2）/渐变色（0）/
    uint8_t fillRule;            // paint fill规则
    uint32_t fillColor;          // paint fill填充颜色
    uint32_t strokeColor;        // paint stroke填充颜色
    uint16_t strokeWidth;        // paint stroke宽度
    uint8_t strokeLinecap;       // paint stroke线帽
    uint8_t strokeLinejoin;      // paint stroke连接类型
    float strokeMiterlimit;      // paint stroke最大的miter长度
    int16_t gradientIndex;       // paint gradient 在整个gradient数组的位置
}
'''
'''
struct pathInfo {
    uint32_t cmdIndex;          // path cmd在整个cmd数组中起始的位置
    uint32_t dataIndex;         // path data在整个data数组中起始的位置
    uint32_t cmdNum;            // path cmd的数量
    uint32_t dataNum;           // path data的数量
    paintInfo paint;            // path paint参数
    int16_t clipPathIndex;      // path clip path在整个clip path数组中的位置
}
'''
def WriteToPathInfo(fb):
    cmdIndex = 0
    dataIndex = 0
    i = 0
    for pathObj in parse_svg.g_pathList:
        outCmdIndex = cmdIndex
        cmdIndex += len(pathObj.cmdList_)
        outCmdNum = len(pathObj.cmdList_)
        outDataIndex = dataIndex
        dataIndex += len(pathObj.dataList_)
        outDataNum = len(pathObj.dataList_)

        if pathObj.PresentationAttr_.clipPath_ != "none":
            outClipPathIndex = pathObj.PresentationAttr_.clipPath_.index_
        else:
            outClipPathIndex = -1

        outOpa = round(pathObj.PresentationAttr_.opacity_ * 255)
        fillType = pathObj.PresentationAttr_.fillType_
        strokeType_ = pathObj.PresentationAttr_.strokeType_
        fill = pathObj.PresentationAttr_.fill_

        outfillRule = 0
        if pathObj.PresentationAttr_.fillRule_ == 'evenodd':
            outfillRule = 1
        stroke = pathObj.PresentationAttr_.stroke_
        fillOpa = round(pathObj.PresentationAttr_.fillOpacity_ * 255)
        strokeOpa = round(pathObj.PresentationAttr_.strokeOpacity_ * 255)

        outPaintStyle = 2
        if fill == "none" and stroke != "none":
            outPaintStyle = 1
        elif stroke == "none" and fill != "none":
            outPaintStyle = 2

        elif stroke != "none" and fill != "none":
            outPaintStyle = 3

        outStrokeWidth = round(pathObj.PresentationAttr_.strokeWidth_ + 0.1)

        outstrokeLinecap = pathObj.PresentationAttr_.strokeLinecap_
        if outstrokeLinecap == "butt":
            outstrokeLinecap = 0
        elif outstrokeLinecap == "round":
            outstrokeLinecap = 1
        elif outstrokeLinecap == "square":
            outstrokeLinecap = 2

        outstrokeLinejoin = pathObj.PresentationAttr_.strokeLinejoin_
        if outstrokeLinejoin == "miter":
            outstrokeLinejoin = 0
        elif outstrokeLinejoin == "round":
            outstrokeLinejoin = 1
        elif outstrokeLinejoin == "bevel":
            outstrokeLinejoin = 2

        outstrokeMiterlimit = float(pathObj.PresentationAttr_.strokeMiterlimit_)

        outGradienIndex = -1
        outFill = (fillOpa << 24)
        outStroke = (strokeOpa << 24)

        if fillType == "FILL_TYPE_LINEAR_GRADIENT" or fillType == "FILL_TYPE_RADIAL_GRADIENT" or \
        strokeType_ == "FILL_TYPE_LINEAR_GRADIENT" or strokeType_ == "FILL_TYPE_RADIAL_GRADIENT":
            outPaintType = 0
            if fillType != "FILL_TYPE_LINEAR_GRADIENT" and fillType != "FILL_TYPE_RADIAL_GRADIENT" and fill != "none":
                outFill = (fillOpa << 24) + int(fill, 16)
            if strokeType_ != "FILL_TYPE_LINEAR_GRADIENT" and strokeType_ != "FILL_TYPE_RADIAL_GRADIENT" and stroke != "none":
                outStroke = (strokeOpa << 24) + int(stroke, 16)
            if (strokeType_ == "FILL_TYPE_LINEAR_GRADIENT" or strokeType_ == "FILL_TYPE_RADIAL_GRADIENT"):
                if stroke != "none":
                    outGradienIndex = stroke.index_
            else:
                if fill != "none":
                    outGradienIndex = fill.index_
        else:
            outPaintType = 2
            if fill == "none" and stroke != "none":
                outStroke = (strokeOpa << 24) + int(stroke, 16)

            elif stroke == "none" and fill != "none":
                outFill = (fillOpa << 24) + int(fill, 16)

            elif stroke != "none" and fill != "none":
                outFill = (fillOpa << 24) + int(fill, 16)
                outStroke = (strokeOpa << 24) + int(stroke, 16)

        if(userInput.v == "uikit"):
            PathInfoBin = struct.pack('@IIIIBBBBIIHhhH', \
                outCmdIndex, outDataIndex, outCmdNum, outDataNum,
                outOpa, outPaintStyle, outPaintType, outfillRule, outFill, outStroke,
                outStrokeWidth, outGradienIndex, outClipPathIndex, 0)
        elif(userInput.v == "vau"):
            PathInfoBin = struct.pack('@IIIIBBBBIIHBBhhf', \
                outCmdIndex, outDataIndex, outCmdNum, outDataNum, outOpa,
                outPaintStyle, outPaintType, outfillRule, outFill, outStroke, outStrokeWidth,
                outstrokeLinecap, outstrokeLinejoin, outClipPathIndex, outGradienIndex, outstrokeMiterlimit)
        fb.write(PathInfoBin)

        print("第", i, "组:")
        print(outCmdIndex, outDataIndex, outCmdNum, outDataNum)
        print(outOpa, outPaintStyle, outPaintType, outfillRule, outFill, outStroke)
        print(outStrokeWidth, outstrokeLinecap, outstrokeLinejoin, outstrokeMiterlimit, outGradienIndex, outClipPathIndex, "\n")
        i += 1

def WriteToCmd(fb):
    for pathObj in parse_svg.g_pathList:
        for cmd in pathObj.cmdList_:
            fb.write(struct.pack('@B', int(cmd)))

def WriteToData(fb):
    for pathObj in parse_svg.g_pathList:
        for data in pathObj.dataList_:
            fb.write(struct.pack('=f', float(data)))

'''
struct gradientInfo {
    uint8_t type;               // gradient 类型 线型渐变色/放射型渐变色
    int16_t param1;             // gradient 参数1 线型:起始坐标x 放射型:中心坐标x
    int16_t param2;             // gradient 参数2 线型:起始坐标y 放射型:中心坐标y
    int16_t param3;             // gradient 参数3 线型:终点坐标x 放射型:半径
    int16_t param4;             // gradient 参数4 线型:终点坐标y 放射型:无效参数
    uint16_t stopIndex;         // gradient stop 在整个stop数字起始的位置
    uint16_t stopNum;           // gradient stop 数量
}
'''
def WriteToGradient(fb):
    stopIndex = 0
    for gradientObj in parse_svg.g_gradientList:
        if gradientObj.tag_ == "LinearGradient":
            outType = 0
            param1 = int(gradientObj.starX_)
            param2 = int(gradientObj.starY_)
            param3 = int(gradientObj.endX_)
            param4 = int(gradientObj.endY_)
        else:
            outType = 1
            param1 = int(gradientObj.centerX_)
            param2 = int(gradientObj.centerY_)
            param3 = int(gradientObj.radius_)
            param4 = 0
        gradientBin = struct.pack('@BhhhhHH', outType, param1, param2, param3, param4,
            stopIndex, len(gradientObj.stopList_))
        stopIndex += len(gradientObj.stopList_)
        fb.write(gradientBin)

'''
struct stopInfo {
    float offset;                 // stopInfo 对应ColorStop stop
    uint32_t color;               // stopInfo 颜色
}
'''
def WriteToStop(fb):
    for gradientObj in parse_svg.g_gradientList:
        for stop in gradientObj.stopList_:
            opa = round(stop.stopOpacity_* 255)
            color = stop.stopColor_
            stopBin = struct.pack('@fI', float(stop.offset_), (opa << 24) + color)
            fb.write(stopBin)
'''
sturct clippath {
    int16_t x;
    int16_t y;
    int16_t w;
    int16_t h;
}
'''
def WriteToClipPath(fb):
    for clipPatObj in parse_svg.g_clipPathList:
        clipPathBin = struct.pack('@hhhh', int(clipPatObj.x_), int(clipPatObj.y_),
            int(clipPatObj.width_), int(clipPatObj.height_))
        fb.write(clipPathBin)

def OutPutBinFile(file):
    filePath = os.path.dirname(file)
    fileNameNoSuffix = os.path.split(file)[-1].split('.')[0]
    newFileName = fileNameNoSuffix + '.bin'
    newBinFile = open(outDirPath +"/" + newFileName, 'wb')
    WriteToHeader(newBinFile)
    WriteToPathInfo(newBinFile)
    WriteToCmd(newBinFile)
    WriteToData(newBinFile)
    WriteToGradient(newBinFile)
    WriteToStop(newBinFile)
    WriteToClipPath(newBinFile)
    newBinFile.flush()
    newBinFile.close()

# main process function
def FileProcess(file):
    if os.path.isfile(file) and file[-3:] == "svg":
        fileNameNoSuffix = os.path.split(file)[-1].split('.')[0]
        fileNameBigHump = ConvertBigHump(fileNameNoSuffix)
        outFile = outDirPath +"/" + fileNameBigHump + "Path.svg"
        ConvertShapesToPath(file, outFile)
        parse_svg.ParseSvgToData(outFile)
        OutPutBinFile(outFile)
        OutPutPathFile(outFile)

def DirProcess(dir):
    return

def GetParameters():
    parser = argparse.ArgumentParser()

    parser.add_argument('-file', '-f', type=str, default='', required=False,
                        help='The svg file need to be converted.')

    parser.add_argument('-dir', '-d', type=str, default='', required=False,
                        help='The directory needs to be converted.')

    parser.add_argument('-output', type=str, default=os.getcwd() + "/out", required=False,
                        help='output dir')

    parser.add_argument('-v', type=str, default="uikit", required=False,
                        help='output type')

    config = parser.parse_args()
    return config

if __name__ == "__main__":
    userInput = GetParameters()
    outDirPath = userInput.output
    if (userInput.v == "vau"):
        outDirPath = os.getcwd() + "/vauout"
    print('当前输出路径:' + outDirPath)
    if not os.path.exists(outDirPath):
        os.makedirs(outDirPath)
    print('用户输入的目录:' + userInput.dir)
    print('用户输入的文件:' + userInput.file)
    DirProcess(userInput.dir)
    FileProcess(userInput.file)
    print("Conversion succeeded!")
