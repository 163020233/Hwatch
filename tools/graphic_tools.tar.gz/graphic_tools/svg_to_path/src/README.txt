执行命令
python3 main.py -f [FILE] -output [output] -v [uikit/vau]
[FILE]:文件名，文件名中不能包含空格
[output]:输出路径，非必要
[uikit/vau]:适配uikit或vau测试，默认uikit