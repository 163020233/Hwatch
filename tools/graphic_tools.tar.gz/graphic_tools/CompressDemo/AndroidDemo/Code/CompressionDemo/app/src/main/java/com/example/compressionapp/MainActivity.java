package com.example.compressionapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.compress.api.DecompressRet;
import com.compress.api.PicZipApi;
import com.compress.api.PicZipEventCallback;
import com.compress.api.CompressParam;
import com.compress.nativelib.FileLogger;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private Bitmap bitMapSrc;
    private File compressedFile;
    private ImageView destPic;
    private Button btnCompress;
    private Button btnDecompress;
    private long startTime = 0;
    private long endTime = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView srcPic = findViewById(R.id.iv_src);
        destPic = findViewById(R.id.iv_dest);
        btnCompress = findViewById(R.id.btn_compress);
        btnCompress.setOnClickListener(view -> compress());
        btnDecompress = findViewById(R.id.btn_decompress);
        btnDecompress.setOnClickListener(view -> decompress());
        bitMapSrc = getImageFromAssetsFile(getApplicationContext(), "TestCompress.png");
        srcPic.setImageBitmap(bitMapSrc);
        // 设置压缩和解压的结果回调
        PicZipApi.getInstance().setCallback(new PicZipEventCallback() {
            @Override
            public void compressRets(int id, int state, int tileWidth, byte[] data) {
                int dataLen = data.length;
                endTime = System.currentTimeMillis();
                Log.i(TAG, "compressRetsFromJNI: id = " + id + " state = " + state + " tileWidth = " + tileWidth + " len = " + dataLen);
                Log.i(TAG, "compressRets: const == " + (endTime - startTime));
                compressedFile = FileLogger.writeBuffer("ComRets" + tileWidth, data, 0, data.length);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        btnCompress.setEnabled(true);
                        Toast.makeText(MainActivity.this, "compress finished", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void deCompressRets(int id, int state, DecompressRet ret) {
                int channelIdx = 0;
                endTime = System.currentTimeMillis();
                Log.i(TAG, "compressRets: const == " + (endTime - startTime));
                Bitmap.Config config = Bitmap.Config.ARGB_8888;
                if (ret.getFormat() == 8) { //
                    config = Bitmap.Config.RGB_565;
                }
                Bitmap bitmapDe = Bitmap.createBitmap(ret.getWidth(), ret.getHeight(), config);
                for (int j = 0; j < ret.getHeight(); j++) {
                    for (int i = 0; i < ret.getWidth(); i++) {
                        channelIdx = j * ret.getWidth() + i;
                        int color = 0;
                        if (ret.getFormat() == 8) { // RGB565
                            color = Color.rgb(ret.getRedChannel()[channelIdx] << 3,
                                    ret.getGreenChannel()[channelIdx] << 2,
                                    ret.getBlueChannel()[channelIdx] << 3);
                        } else {
                            color = ((ret.getAlphaChannel()[channelIdx] & 0xff) << 24) |
                                    ((ret.getRedChannel()[channelIdx] & 0xff) << 16) |
                                    ((ret.getGreenChannel()[channelIdx] & 0xff) << 8) |
                                    ((ret.getBlueChannel()[channelIdx] & 0xff));
                        }
                        bitmapDe.setPixel(i, j, color);
                    }
                }
                runOnUiThread(() -> destPic.setImageBitmap(bitmapDe));
            }
        });
    }

    private void compress() {
        btnCompress.setEnabled(false);
        Bitmap.Config config = bitMapSrc.getConfig();
        int width = bitMapSrc.getWidth();
        int height = bitMapSrc.getHeight();
        byte[] redChannel = new byte[width * height];
        byte[] greenChannel = new byte[width * height];
        byte[] blueChannel = new byte[width * height];
        byte[] alphaChannel = new byte[width * height];
        int channelIdx = 0;
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int pixelColor = bitMapSrc.getPixel(i, j);
                channelIdx = j * width + i;
                int alpha = (pixelColor >> 24) & 0xff;
                int red = (pixelColor >> 16) & 0xff;
                int green = (pixelColor >> 8) & 0xff;
                int blue = pixelColor & 0xff;
                if (config == Bitmap.Config.RGB_565) {
                    redChannel[channelIdx] = (byte)(red >> 3);
                    greenChannel[channelIdx] = (byte)(green >> 2);
                    blueChannel[channelIdx] = (byte)(blue >> 3);
                } else {
                    redChannel[channelIdx] = (byte)red;
                    greenChannel[channelIdx] = (byte)green;
                    blueChannel[channelIdx] = (byte)blue;
                }
                alphaChannel[channelIdx] = (byte)alpha;
            }
        }

        CompressParam pressParam = new CompressParam();
        pressParam.setWidth(width);
        pressParam.setHeight(height);
        pressParam.setStride(width);
        pressParam.setModeRgb(1);
        pressParam.setModeAlpha(1);
        pressParam.setCmpMode(0);
        /**
         * 设置TileWidth 4 6 8 16
         */
        pressParam.setTileWidth(8);
        pressParam.setAlphaChannel(alphaChannel);
        pressParam.setRedChannel(redChannel);
        pressParam.setGreenChannel(greenChannel);
        pressParam.setBlueChannel(blueChannel);
        if (config == Bitmap.Config.ARGB_8888) {
            pressParam.setPixelFormat(1);
        } else if (config == Bitmap.Config.RGB_565) {
            pressParam.setPixelFormat(2);
        } else {
            pressParam.setPixelFormat(0);
        }
        Log.i(TAG, "compress: " + pressParam.getPixelFormat());
        // 调用压缩接口
        startTime = System.currentTimeMillis();
        new Thread(() -> PicZipApi.getInstance().compress(pressParam)).start();
    }

    private void decompress() {
        if (compressedFile == null) {
            Toast.makeText(this, "Invalid File", Toast.LENGTH_SHORT).show();
            return;
        }
        int dataLen = (int)compressedFile.length();
        byte[] decompressData = new byte[dataLen];
        try {
            FileInputStream fis = new FileInputStream(compressedFile);
            fis.read(decompressData);
        } catch (IOException e) {
            e.printStackTrace();
            Log.i(TAG, "decompress: fileSize = " + compressedFile.length());
        }
        startTime = System.currentTimeMillis();
        new Thread(() -> PicZipApi.getInstance().decompress(3, decompressData)).start();
    }

    private Bitmap getImageFromAssetsFile(Context ctx, String fileName) {
        Bitmap bitmap = null;
        AssetManager assetManager = ctx.getAssets();
        try {
            InputStream is = assetManager.open(fileName);
            bitmap = BitmapFactory.decodeStream(is);
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bitmap;
    }
    private byte[] getBuffer(Context ctx, String fileName) {
        AssetManager assetManager = ctx.getAssets();
        byte[] rets = new byte[1024 * 300];
        int len = 0;
        try {
            InputStream is = assetManager.open(fileName);
            len = is.read(rets);
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return rets;
    }
}