package com.example.compressionapp;

import android.app.Application;

import com.compress.api.PicZipApi;
import com.compress.nativelib.FileLogger;

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        FileLogger.init(this);
        PicZipApi.getInstance().init();
    }

}
