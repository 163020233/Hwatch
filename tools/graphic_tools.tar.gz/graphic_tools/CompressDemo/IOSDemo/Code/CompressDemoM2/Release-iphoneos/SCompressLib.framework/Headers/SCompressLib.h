//
//  SCompressLib.h
//  SCompressLib
//
//

#import <Foundation/Foundation.h>

//! Project version number for SCompressLib.
FOUNDATION_EXPORT double SCompressLibVersionNumber;

//! Project version string for SCompressLib.
FOUNDATION_EXPORT const unsigned char SCompressLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SCompressLib/PublicHeader.h>

#import <SCompressLib/CPicZipApi.hpp>
