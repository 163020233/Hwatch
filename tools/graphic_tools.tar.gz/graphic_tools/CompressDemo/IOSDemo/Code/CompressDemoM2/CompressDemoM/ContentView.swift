//
//  ContentView.swift
//  SCompressDemo
//
//  Created by l30037444 on 2023/10/26.
//

import SwiftUI
import SCompressLib

var fullPath  = "global_path"

var decompressPic : CGImage?



extension UIImage {
    
    /**
     根据坐标获取图片中的像素颜色值
     */
    subscript (x: Int, y: Int) -> (r : UInt8, g : UInt8, b : UInt8, a : UInt8) {
        if x < 0 || x > Int(size.width) || y < 0 || y > Int(size.height) {
            return (0, 0, 0, 0)
        }
        let provider = self.cgImage!.dataProvider
        let providerData = provider!.data
        let data = CFDataGetBytePtr(providerData)
        let numberOfComponents = 4
        let pixelData = ((Int(size.width) * y) + x) * numberOfComponents
        let r = UInt8(data![pixelData])
        let g = UInt8(data![pixelData + 1])
        let b = UInt8(data![pixelData + 2])
        let a = UInt8(data![pixelData + 3])
        return (r, g, b, a)
    }
}

struct ContentView: View {
    @State public var isDeFinished = false
    func extractPixelData(from image: UIImage) -> (redChannel: [UInt8], greenChannel: [UInt8], blueChannel: [UInt8], alphaChannel: [UInt8])? {
        guard let cgImage = image.cgImage else { return nil }
        let width = Int(image.size.width)
        let height = Int(image.size.height)
        // 每个像素 4 字节（RGBA）
        let bytesPerPixel = 4
        let bytesPerRow = bytesPerPixel * width
        let bitsPerComponent = 8
        // 创建颜色空间
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        // 分配内存空间来存储像素数据
        var pixelData = [UInt8](repeating: 0, count: width * height * bytesPerPixel)
        guard let context = CGContext(
            data: &pixelData,
            width: width,
            height: height,
            bitsPerComponent: bitsPerComponent,
            bytesPerRow: bytesPerRow,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ) else {
            return nil
        }
        // 将图像绘制到上下文中，得到像素数据
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        // 创建存储通道值的数组，并预先分配足够的容量
        var redChannel = [UInt8](repeating: 0, count: width * height)
        var greenChannel = [UInt8](repeating: 0, count: width * height)
        var blueChannel = [UInt8](repeating: 0, count: width * height)
        var alphaChannel = [UInt8](repeating: 0, count: width * height)
        // 直接遍历并提取每个像素的 RGBA 值
        for i in 0..<(width * height) {
            let pixelIndex = i * bytesPerPixel
            redChannel[i] = pixelData[pixelIndex] // 红色通道
            greenChannel[i] = pixelData[pixelIndex + 1] // 绿色通道
            blueChannel[i] = pixelData[pixelIndex + 2] // 蓝色通道
            alphaChannel[i] = pixelData[pixelIndex + 3] // 透明度通道
        }
        return (redChannel, greenChannel, blueChannel, alphaChannel)
    }
    var body: some View {
        VStack {
            Button("Compress") {
                let image = UIImage(imageLiteralResourceName: "A021_036.png")
                let width = Int(image.size.width)
                let height = Int(image.size.height)
                print("width = \(width), height = \(height)")
                let pixelFormat = image.cgImage?.pixelFormatInfo
                print("pixelFormat = \(pixelFormat.debugDescription)")
                var sParam = SCompressParam()
                sParam.id = 15
                sParam.width = Int32(width)
                sParam.height = Int32(height)
                sParam.stride = Int32(width)
                sParam.modeRgb = 1
                sParam.modeAlpha = 1
                sParam.cmpMode = 0
                sParam.tileWidth = 4
                sParam.pixelFormat = 1
                if let result = extractPixelData(from: image) {
                    sParam.redChannel = result.redChannel
                    sParam.greenChannel = result.greenChannel
                    sParam.blueChannel = result.blueChannel
                    sParam.alphaChannel = result.alphaChannel
                }
                print("red channel len = \(sParam.redChannel.count)")
                let picApi = SPicZipApi()
                SetZipEvent(picEvent: MyZipRets(flag : $isDeFinished))
                picApi.Compress(compressParam: sParam)
            }
            Image("A021_036")
            Button("DeCompress") {
                // 读取文件
                let fileURL = URL(fileURLWithPath: fullPath)
                do {
                    let fileData = try Data(contentsOf: fileURL)
                    let picApi = SPicZipApi()
                    var compressedFile : [UInt8] = []
                    for i in 0...fileData.count - 1 {
                        compressedFile.append(fileData[i])
                    }
                    picApi.Decompress(id: 39, fileBuffer: compressedFile)
                } catch {
                    print("file read error.")
                }
                
            }
            if isDeFinished == true {
                //let temp = UIImage(imageLiteralResourceName: "A021_036.png")
                var temp = UIImage(cgImage: decompressPic!)
                Image(uiImage: temp)
            }
        }
        .padding()
    }
}

public func ReadChannelData (name : String) ->[UInt8] {
    let filePath = NSHomeDirectory() + "/Documents/" + name
    let fileHandler = FileHandle.init(forReadingAtPath: filePath)
    let fileData = fileHandler?.readDataToEndOfFile()
    let rets = [UInt8](fileData!)
    print("channel len == \(rets.count)")
    return rets
}

public func WriteCompressedFile(name : String, compressedData : [UInt8]) {
    let basedFilePath = NSHomeDirectory() + "/Documents"
    let fileManager = FileManager.default
    let format = DateFormatter()
    let now = Date()
    format.dateFormat = "HHmmss"
    let timeStamp = format.string(from: now)
    let fullPath = basedFilePath + "/CompressRets_" + name + timeStamp + ".bin"
    print("fullPath = \(fullPath)")
    let exist = fileManager.fileExists(atPath: fullPath)
    if !exist {
        let data = Data(bytes: compressedData, count: compressedData.count)
        fileManager.createFile(atPath: fullPath, contents: data)
    }
}



public func WriteCompressedFile(compressedData : [UInt8]) {
    let basedFilePath = NSHomeDirectory() + "/Documents"
    let fileManager = FileManager.default
    let format = DateFormatter()
    let now = Date()
    format.dateFormat = "HHmmss"
    let timeStamp = format.string(from: now)
    fullPath = basedFilePath + "/CompressRets_abalone" + timeStamp + ".bin"
    print("fullPath = \(fullPath)")
    let exist = fileManager.fileExists(atPath: fullPath)
    if !exist {
        let data = Data(bytes: compressedData, count: compressedData.count)
        fileManager.createFile(atPath: fullPath, contents: data)
    }
}

struct MyZipRets : PicZipEvent {
    @Binding var flag :Bool
    func DecompressRets(id: Int, state: Int, decomRets: SCompressLib.SDecompressRets) {
        let imageWidth = Int(decomRets.width)
        let imageHeight = Int(decomRets.height)
        drawRect(decomRets: decomRets)
        print("decompress id ====== \(id)")
        flag = true
    }
    
    func CompressRets(id: Int, state: Int, tileWidth: Int, retData: [UInt8]) {
        WriteCompressedFile(compressedData: retData)
    }
}

func createBitmapContext(pixelsWide: Int, _ pixelsHigh: Int) -> CGContext? {
    let bytesPerPixel = 4 // 生成包括ARGB四个通道的像素点，每个像素点需要4个字节
    let bytesPerRow = bytesPerPixel * pixelsWide
    let bitsPerComponent = 8
    let byteCount = (bytesPerRow * pixelsHigh)
    let colorSpace = CGColorSpaceCreateDeviceRGB()
    let pixels = UnsafeMutablePointer<CUnsignedChar>.allocate(capacity:byteCount)
    let bitmapInfo = CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Big.rawValue
    let context = CGContext(data: pixels, width: pixelsWide, height: pixelsHigh, bitsPerComponent: bitsPerComponent, bytesPerRow: bytesPerRow, space: colorSpace, bitmapInfo: bitmapInfo)
    return context
}

func drawRect(decomRets: SCompressLib.SDecompressRets) {
    let width  = decomRets.width
    let height = decomRets.height
    let boundingBox = CGRectMake(0, 0, CGFloat(width), CGFloat(height))
    let context = createBitmapContext(pixelsWide: Int(width), Int(height))
    let data = context!.data
    var pixelIdx = 0
    var chanIdx = 0
    for i in 0...height - 1 {
        for j in 0...width - 1 {
            chanIdx = Int(i * width + j)
            data?.storeBytes(of:decomRets.alphaChannel[chanIdx], toByteOffset: pixelIdx, as: UInt8.self)
            pixelIdx += 1
            data?.storeBytes(of:decomRets.redChannel[chanIdx], toByteOffset: pixelIdx, as: UInt8.self)
            pixelIdx += 1
            data?.storeBytes(of:decomRets.greenChannel[chanIdx], toByteOffset: pixelIdx, as: UInt8.self)
            pixelIdx += 1
            data?.storeBytes(of:decomRets.blueChannel[chanIdx], toByteOffset: pixelIdx, as: UInt8.self)
            pixelIdx += 1
        }
    }
    decompressPic = context!.makeImage()
}

#Preview {
    ContentView()
}
