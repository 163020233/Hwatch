//
//  CompressDemoMApp.swift
//  CompressDemoM
//
//

import SwiftUI

@main
struct CompressDemoMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
