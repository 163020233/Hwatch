#ifndef COMPRESSLIB_LIBRARY_H
#define COMPRESSLIB_LIBRARY_H

namespace ErrorNo {
    const unsigned int COMPRESS_SUCCESS = 0x1010;
}

struct ImageHeader {
    unsigned int colorMode : 8;
    unsigned int version : 4; // 文件头版本号，占用4bit
    unsigned int compressMode : 4; // 图片压缩类型，0:none 4:hfbc 5:hfbc_abypass，占用4bit
    unsigned int reserved : 16; // 暂时不赋值，占用16bit
    short width; // 图片的宽
    short height; // 图片的高
};

struct CompressParam {
    int id;
    int width;
    int height;
    int stride;
    int pixelFormat; // 0-- RGB888, 1-- ARGB8888, 2-- RGB565
    int tileWidth;   //TILE: 4-- 4x4, 6-- 6x4, 8-- 8x4, 16-- 16x4
    int modeAlpha;   //0-- A_BYPASS,   1-- A_MERGE,  2-- A_SEPARATE, 3-- A_CONST,   4-- A_BINARY
    int modeRgb;     //0-- RGB_BYPASS, 1-- RGB_ASTC, 2-- RGB_TABLE,  3-- RGB_CONST ,4-- RGB_BINARY
    int cmpMode;
    unsigned char* redChannel;
    unsigned char* greenChannel;
    unsigned char* blueChannel;
    unsigned char* alphaChannel;
};

struct DecompressRet {
    int width;
    int height;
    int format;
    unsigned char* redChannel;
    unsigned char* greenChannel;
    unsigned char* blueChannel;
    unsigned char* alphaChannel;
};

typedef void(*PicZipEventCallback)(int id, int state, unsigned int tileWidth, unsigned char* data, unsigned int dataLen);

typedef void(*PicUnZipEventCallback)(int id, int state, DecompressRet rets);

#ifdef __cplusplus
extern "C" {
#endif

    __declspec(dllexport) void SetCallBack(PicZipEventCallback callback);


    __declspec(dllexport) void Compress(CompressParam param);


    __declspec(dllexport) void SetUnCallBack(PicUnZipEventCallback callback);

    __declspec(dllexport) void Decompress(int id, unsigned char *fileBuffer, int buffLen);


#ifdef __cplusplus
}
#endif








#endif //COMPRESSLIB_LIBRARY_H
