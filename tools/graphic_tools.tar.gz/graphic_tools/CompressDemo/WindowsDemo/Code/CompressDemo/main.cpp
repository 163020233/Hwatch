#include <iostream>
#include <QDir>
#include <QFile>
#include <QImage>
#include <QLibrary>
#include <QImageWriter>
#include <QImageReader>
#include <QCoreApplication>
#include <QCommandLineParser>
#include "library.h"

QString globalOut1;
QString globalOut2;

using CallbackFun = void(*)(PicZipEventCallback callback);
using CompressFun = void(*)(CompressParam param);


using DecomCallbackFun = void(*)(PicUnZipEventCallback callback);
using DecompressFun = void(*)(int, unsigned char*, int);

static CallbackFun callbackFun = nullptr;
static CompressFun compressFun = nullptr;

static DecomCallbackFun decomCallbackFun = nullptr;
static DecompressFun decompressFun = nullptr;

void CompressRets(int id, int state, unsigned int tileWidth, unsigned char *data, unsigned int dataLen) {
    std::cout << "Id = " << id << " state = " << state << " dataLen = " << dataLen << std::endl;
    QString tile = QString("%1").arg(tileWidth);
    QString outFilePath = globalOut1 + "\\CompressRet"+tile+".bin";
    QFile *outFile = new QFile(outFilePath);
    if (!outFile->open(QFile::WriteOnly)) {
        qDebug("failed to generate file");
        return;
    }
    QDataStream *fileStream = new QDataStream(outFile);
    fileStream->writeRawData((const char*)data, dataLen);
    outFile->close();
    std::cout << "Compress Out File Path = " << outFilePath.toStdString() << std::endl;
}

void DecompressRetHandler(int id, int state, DecompressRet rets) {
    std::cout << "Id = " << id << " state = " << state << " height = " << rets.height << std::endl;
    QImage::Format imageFormat = QImage::Format_ARGB32;
    if (rets.format== 5) { // 5 = rgb888
        imageFormat = QImage::Format_RGB32;
    } else if (rets.format== 0) { // 0 = argb8888
        imageFormat = QImage::Format_ARGB32;
    } else if (rets.format == 8) { // 8 = rgb565
        imageFormat = QImage::Format_RGB16;
    }

    QImage *decomPic = new QImage(rets.width, rets.height, imageFormat);
    int channelIdx = 0;
    for (int j = 0; j < decomPic->height(); j++) {
        for (int i = 0; i < decomPic->width(); i++) {
            channelIdx = j * decomPic->width() + i;
            uint rgb;
            if (rets.format == 8) {
                rgb = qRgb(rets.redChannel[channelIdx] << 3, // offset 3
                           rets.greenChannel[channelIdx] << 2,  // offset 2
                           rets.blueChannel[channelIdx] << 3); // offset 3
            } else {
                rgb = qRgba(rets.redChannel[channelIdx], rets.greenChannel[channelIdx], rets.blueChannel[channelIdx],
                    rets.alphaChannel[channelIdx]);
            }
            decomPic->setPixel(i, j, rgb);
        }
    }
    QString outputPic = globalOut2 + "\\" + "Decompress.png";
    QImageWriter write(outputPic);
    write.write(*decomPic);
    std::cout << "Decompress Out File Path = " << outputPic.toStdString() << std::endl;
}

void Decompress(QString in, QString out) {
    std::cout << __FUNCTION__ << std::endl;
    QFile *inFile = new QFile(in);
    if (!inFile->open(QFile::ReadOnly)) {
        std::cout << "failed to generate file" << std::endl;
        return;
    }
    globalOut2 = out;
    quint64 inFileSize = inFile->size();
    char* fileBuffer = new char[inFileSize];
    QDataStream *fileStream = new QDataStream(inFile);
    fileStream->readRawData(fileBuffer, inFileSize);
    inFile->close();
    if (decompressFun != nullptr) {
        decompressFun(10, (unsigned char*)fileBuffer, inFileSize);
    }
}

void Compress(const QString& in, const QString& out) {
    std::cout << __FUNCTION__ << " start " << std::endl;
    QImageReader reader(in);
    QImage toCompressImage = reader.read();
    int width = toCompressImage.width();
    int height = toCompressImage.height();
    unsigned char* redChannel = new unsigned char[width * height];
    unsigned char* greenChannel = new unsigned char[width * height];
    unsigned char* blueChannel = new unsigned char[width * height];
    unsigned char* alphaChannel = new unsigned char[width * height];
    int channelIdx = 0;
    for (int j = 0; j < height; j++) {
        for (int i = 0; i < width; i++) {
            channelIdx = j * width + i;
            QRgb pointPix = toCompressImage.pixel(i, j);
            int alpha = qAlpha(pointPix);
            int red = qRed(pointPix);
            int green = qGreen(pointPix);
            int blue = qBlue(pointPix);
            if (toCompressImage.format() == QImage::Format_ARGB8565_Premultiplied) {
                redChannel[channelIdx] = (red >> 3);
                greenChannel[channelIdx] = (green >> 2);
                blueChannel[channelIdx] = (blue >> 3);
            } else {
                redChannel[channelIdx] = red;
                greenChannel[channelIdx] = green;
                blueChannel[channelIdx] = blue;
            }
            alphaChannel[channelIdx] = alpha;
        }
    }
    CompressParam param;
    param.id = 12;
    param.width = width;
    param.height = height;
    param.stride = width;
    param.modeRgb = 1;
    param.modeAlpha = 1;
    param.cmpMode = 0;
    param.tileWidth = 8; // 可以取值4 6 8 16
    param.redChannel = redChannel;
    param.greenChannel = greenChannel;
    param.blueChannel = blueChannel;
    param.alphaChannel = alphaChannel;
    auto format = toCompressImage.format();
    if (format == QImage::Format_RGB32) {
        param.pixelFormat = 0;
    } else if (format == QImage::Format_ARGB32) {
        param.pixelFormat = 1;
    } else if (format == QImage::Format_ARGB8565_Premultiplied) {
        param.pixelFormat = 2; // 2 代表565格式
    }
    std::cout << "Call library file. format = " << param.pixelFormat << std::endl;
    globalOut1 = out;
    compressFun(param);
}

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName("compresslib");
    QCoreApplication::setApplicationVersion("1.0");

    // Demo中使用动态加载库的方法，请填写本地的实际路径
    QString libPath = QString("D:/Code/MulPlatformSDK/PicZip/PicZipSDK/WindowsDemo/Code/CompressDemo/compressLib/X64/CompressLib.dll");
    QLibrary* lib = new QLibrary(libPath);
    bool success = lib->load();
    std::cout << "load lib == " << success << std::endl;

    callbackFun = (CallbackFun)lib->resolve("SetCallBack");
    compressFun = (CompressFun)lib->resolve("Compress");
    decomCallbackFun = (DecomCallbackFun)lib->resolve("SetUnCallBack");
    decompressFun = (DecompressFun)lib->resolve("Decompress");

    // 注册压缩事件回调
    callbackFun(CompressRets);
    // 注册解压事件回调
    decomCallbackFun(DecompressRetHandler);

    QCommandLineParser parser;
    parser.setApplicationDescription("Test helper");
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addPositionalArgument("source", QCoreApplication::translate("main", "Source file path."));
    parser.addPositionalArgument("destination", QCoreApplication::translate("main", "Destination directory."));

    QCommandLineOption compressOpt(QStringList() << "c" << "compress", QCoreApplication::translate("main", "Compress file."));
    QCommandLineOption decompressOpt(QStringList() << "d" << "decompress", QCoreApplication::translate("main", "Decompress file."));
    parser.addOption(compressOpt);
    parser.addOption(decompressOpt);
    parser.process(app);

    // 解析参数
    parser.parse(QCoreApplication::arguments());
    QStringList param = parser.positionalArguments();
    if (parser.isSet(compressOpt)) { // 执行压缩流程
        if (param.size() != 2) {
            std::cout << "Invalid param." << std::endl;
            return -1;
        }
        QString picName = param[0];
        QString compressPath = param[1];
        QFile* picFile = new QFile(picName);
        // 尝试是否可以打开
        if (!picFile->open(QFile::ReadOnly)) {
            std::cout << "Open file failed, Name = " << picName.toStdString() << std::endl;
            return - 1;
        }
        picFile->close();
        QDir* decom = new QDir(compressPath);
        if (!decom->exists()) {
            std::cout << "Invalid path, Path = " << compressPath.toStdString() << std::endl;
            return -1;
        }
        Compress(picName, compressPath);
    }
    if (parser.isSet(decompressOpt)) { // 执行解压流程
        if (param.size() != 2) {
            std::cout << "Invalid param." << std::endl;
            return -1;
        }
        QString decomName = param[0];
        QString decompressPath = param[1];
        QFile* decomFile = new QFile(decomName);
        // 尝试是否可以打开
        if (!decomFile->open(QFile::ReadOnly)) {
            std::cout << "Open file failed, Name = " << decomName.toStdString() << std::endl;
            return - 1;
        }
        decomFile->close();
        QDir* decom = new QDir(decompressPath);
        if (!decom->exists()) {
            std::cout << "Invalid path, Path = " << decompressPath.toStdString() << std::endl;
            return -1;
        }
        Decompress(decomName, decompressPath);
    }
    return 0;
}
