1、开发环境
	Qt + Mingw
2、接口使用流程，详情参照代码
	（1） 在App中初始化库
	（2） 设置结果的回调
	（3） 利用系统的图形库解析图片，填充参数
	（4） 调用接口
	（5） 回调中处理结果

3、Demo采用命令行形式，Qt支持设置命令行参数。
设置方法：项目->运行设置->运行->Command line arguments。
压缩参数样例：-c D:\BBIT\PicFile\SRC9\A021_036.png D:\BBIT\PicFile\dest9
压缩参数说明：
	-c      压缩命令
	参数一  待压缩图片全路径
	参数二  压缩后结果存放路径
	
解压参数样例：-d D:\BBIT\PicFile\SRC9\CompressRets.bin D:\BBIT\PicFile\dest9
解压参数说明：
	-d      解压命令
	参数一  待解压二进制文件
	参数二  解压后结果存放路径	

输入文件支持ARBG888、RGB888、RGB565三种格式，输出文件和输入文件的格式相同。输入文件的像素大小应小于1280×800。
参数说明
tileWidth：压缩单元宽度：4--4x4；6--6x4；8--8x4；16--16x4，也叫压缩倍率分别对应4倍压缩，6倍压缩，8倍压缩，16倍压缩。
modeAlpha：压缩模式：0-- 非压缩；1-- 压缩
modeRgb：压缩模式：0--非压缩；1-- 压缩
cmpMode: 0--手动压缩模式：按照固定配置参数进行压缩。当前版本仅支持cmpMode = 0 

解压参数说明
width/height : 图片宽高
pixel_format : 图片的像素格式 （Demo中以ARGB888为例）
redChannel   : 红色通道数据
greenChannel : 绿色通道数据
blueChannel  : 蓝色通道数据
alphaChannel : 透明通道数据


注意：Demo中main.cpp的159行加载动态库使用了绝对路径，运行时候需要修改成对应的本地路径。