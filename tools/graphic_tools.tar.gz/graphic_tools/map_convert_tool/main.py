#!/usr/bin/python
# coding: utf-8
# 1\ 解析命令 python main.py -d [DIR] -o [OUT_DIR]
# 2\ 循环执行svg解析写入
import sys
import os
import argparse
import map_converter

def GetParameters():
    parser = argparse.ArgumentParser()

    parser.add_argument('-file', '-f', type=str, default='', required=False,
                        help='The svg file need to be converted.')

    parser.add_argument('-dir', '-d', type=str, default='', required=False,
                        help='The directory needs to be converted.')

    parser.add_argument('-output', type=str, default=os.getcwd() + "/out", required=False,
                        help='output dir,default[./out]')

    parser.add_argument('-l', '-log', required=False, action="store_true",
                        help='Enables or disables log file output.')

    config = parser.parse_args()
    return config

if __name__ == "__main__":
    userInput = GetParameters()
    outputPath = userInput.output
    inputFile = userInput.file
    inputDir = userInput.dir
    enableLog = userInput.l
    # Create an output folder.
    print("output dir : " + outputPath)
    if not os.path.exists(outputPath):
        os.mkdir(outputPath)

    if not os.path.isdir(inputFile) and inputFile[-3:].lower() == "svg":
        print("input file : " + inputFile)
        tools = map_converter.MapConverter(inputFile, outputPath, enableLog)
        tools.StartConvert()

    files = os.listdir(inputDir)
    print("input dir : " + inputDir)
    for file in files:
        if not os.path.isdir(file) and file[-3:].lower() == "svg":
            tools = map_converter.MapConverter(inputDir + "/" + file, outputPath, enableLog)
            tools.StartConvert()