#!/usr/bin/python
# coding: utf-8
import os
import re
import struct
import ctypes
import math
from ctypes import *
from xml.dom.minidom import parse
import xml.dom.minidom
from imaga_converter import ImageCollectionClass

g_defsDataList = []
g_stringStyleDataList = []
g_pathStyleDataList = []

class LineInfo():
    def __init__(self, startPtX, startPtY, endPtX, endPtY):
        self.sx = startPtX
        self.sy = startPtY
        self.ex = endPtX
        self.ey = endPtY
        if startPtX == endPtX:
            self.isVertical = 1
        else:
            self.isVertical = 0
            self.slope = (self.ey - self.sy) / (self.ex - self.sx)
            self.d = self.sy - self.slope * self.sx
        self.len =  math.sqrt((self.ex - self.sx) * (self.ex - self.sx) + (self.ey - self.sy) * (self.ey - self.sy));

class PathDAttr:
    SVG_PATH_CMD_NAME = ['z', 'Z', 'm', 'M', 'l', 'L', \
        'h', 'H', 'v', 'V', 'q', 'Q', 'c', 'C', 't', 'T', 's', 'S', 'a', 'A']
    number_sym = '0123456789.+-'
    def __init__(self):
        self.dataCmd = []
        self.dataValue = []
        self.cmdRelativeFlag_ = []
        self.line = []

    def RelativeToAbsolute(self):
        curIndex = 0
        curPaintX = 0.0
        curPaintY = 0.0
        for index, cmd in enumerate(self.dataCmd):
            if cmd == 2 or cmd == 4 or cmd == 14:
                if self.cmdRelativeFlag_[index] != 0:
                    curPaintX += self.dataValue[curIndex]
                    self.dataValue[curIndex] = round(curPaintX, 4)
                    curIndex += 1
                    curPaintY += self.dataValue[curIndex]
                    self.dataValue[curIndex] = round(curPaintY, 4)
                    curIndex += 1
                else:
                    curPaintX = self.dataValue[curIndex]
                    curIndex += 1
                    curPaintY = self.dataValue[curIndex]
                    curIndex += 1
            elif cmd == 0:
                curPaintX = 0
                curPaintY = 0
            elif cmd == 6:
                if self.cmdRelativeFlag_[index] != 0:
                    curPaintX += self.dataValue[curIndex]
                    self.dataValue[curIndex] = round(curPaintX, 4)
                    curIndex += 1
                else:
                    curPaintX = self.dataValue[curIndex]
                    curIndex += 1
            elif cmd == 8:
                if self.cmdRelativeFlag_[index] != 0:
                    curPaintY += self.dataValue[curIndex]
                    self.dataValue[curIndex] = round(curPaintY, 4)
                    curIndex += 1
                else:
                    curPaintY = self.dataValue[curIndex]
                    curIndex += 1
            elif cmd == 10 or cmd == 16:
                if self.cmdRelativeFlag_[index] == 0:
                    curIndex += 2
                    curPaintX = self.dataValue[curIndex]
                    curIndex += 1
                    curPaintY = self.dataValue[curIndex]
                    curIndex += 1
                else:
                    self.dataValue[curIndex] = round((curPaintX + float(self.dataValue[curIndex])), 4)
                    curIndex += 1
                    self.dataValue[curIndex] = round((curPaintY + float(self.dataValue[curIndex])), 4)
                    curIndex += 1
                    curPaintX += self.dataValue[curIndex]
                    self.dataValue[curIndex] = round(curPaintX, 4)
                    curIndex += 1
                    curPaintY += self.dataValue[curIndex]
                    self.dataValue[curIndex] = round(curPaintY, 4)
                    curIndex += 1
            elif cmd == 12:
                if self.cmdRelativeFlag_[index] == 0:
                    curIndex += 4
                    curPaintX = self.dataValue[curIndex]
                    curIndex += 1
                    curPaintY = self.dataValue[curIndex]
                    curIndex += 1
                else:
                    self.dataValue[curIndex] = round((curPaintX + float(self.dataValue[curIndex])), 4)
                    curIndex += 1
                    self.dataValue[curIndex] = round((curPaintY + float(self.dataValue[curIndex])), 4)
                    curIndex += 1
                    self.dataValue[curIndex] = round((curPaintX + float(self.dataValue[curIndex])), 4)
                    curIndex += 1
                    self.dataValue[curIndex] = round((curPaintY + float(self.dataValue[curIndex])), 4)
                    curIndex += 1
                    curPaintX += self.dataValue[curIndex]
                    self.dataValue[curIndex] = round(curPaintX, 4)
                    curIndex += 1
                    curPaintY += self.dataValue[curIndex]
                    self.dataValue[curIndex] = round(curPaintY, 4)
                    curIndex += 1
            elif cmd == 18:
                curIndex += 3
                arcFlag = int(self.dataValue[curIndex], 10)
                del self.dataValue[curIndex]
                sweepFlag = int(self.dataValue[curIndex], 10)
                del self.dataValue[curIndex]
                if arcFlag == 0 and sweepFlag == 1:
                    self.dataCmd[index] = 18
                elif arcFlag == 0 and sweepFlag == 0:
                    self.dataCmd[index] = 20
                elif arcFlag == 1 and sweepFlag == 1:
                    self.dataCmd[index] = 22
                elif arcFlag == 1 and sweepFlag == 0:
                    self.dataCmd[index] = 24

                self.PresentationAttr_.stroke_ = '000000'
                self.PresentationAttr_.strokeType_ = "FILL_TYPE_COL"
                self.PresentationAttr_.strokeWidth_ = 0
                self.PresentationAttr_.strokeOpacity_ = 1.0

                if self.cmdRelativeFlag_[index] == 0:
                    curPaintX = self.dataValue[curIndex]
                    curIndex += 1
                    curPaintY = self.dataValue[curIndex]
                    curIndex += 1
                else:
                    curPaintX += self.dataValue[curIndex]
                    self.dataValue[curIndex] = round(curPaintX, 4)
                    curIndex += 1
                    curPaintY += self.dataValue[curIndex]
                    self.dataValue[curIndex] = round(curPaintY, 4)
                    curIndex += 1

    def ParseDAttrCmd(self, index, data):
        cmdIndex = self.SVG_PATH_CMD_NAME.index(data)
        if cmdIndex == 0 or cmdIndex == 1:
            self.cmdRelativeFlag_.append(0)
            return 0
        else:
            if cmdIndex % 2 == 0:
                self.cmdRelativeFlag_.append(1)
                return cmdIndex
            else:
                self.cmdRelativeFlag_.append(0)
                return cmdIndex - 1

    def ParseAttribute(self, string):
        consecutiveFlag = 0
        for index, data in enumerate(string):
            endIndex = index
            if data in self.SVG_PATH_CMD_NAME:
                if consecutiveFlag == 1:
                    self.dataValue.append(round(float(string[startIndex:endIndex]), 4))
                    consecutiveFlag = 0
                self.dataCmd.append(self.ParseDAttrCmd(index, data))
            elif data == ' ' or data == ',':
                if consecutiveFlag == 1:
                    self.dataValue.append(round(float(string[startIndex:endIndex]), 4))
                    consecutiveFlag = 0
            elif data in self.number_sym:
                if consecutiveFlag == 0:
                    startIndex = index
                    consecutiveFlag = 1
        if consecutiveFlag == 1:
            self.dataValue.append(round(float(string[startIndex:endIndex + 1]), 4))
            consecutiveFlag = 0
        self.RelativeToAbsolute()

    def PreTextPath(self):
        lastPointX = 0
        lastpointY = 0
        for index, cmd in enumerate(self.dataCmd):
            if cmd == 4:
                curPointX = round(self.dataValue[index * 2])
                curpointY = round(self.dataValue[index * 2 + 1])
                line = LineInfo(lastPointX, lastpointY, curPointX, curpointY)
                self.line.append(line)
                lastPointX = round(self.dataValue[index * 2])
                lastpointY = round(self.dataValue[index * 2 + 1])
            elif cmd == 2:
                lastPointX = round(self.dataValue[index * 2])
                lastpointY = round(self.dataValue[index * 2 + 1])
            else:
                print("[ERROR]text path non-linear conversion is not supported.")
                return

    def CalculatePathMinRect(self):
        self.PreTextPath()
        totalSX = 0xffff
        totalSY = 0xffff
        totalEX = 0
        totalEY = 0
        for line in self.line:
            totalSX = min(totalSX, line.sx)
            totalSY = min(totalSY, line.sy)
            totalEX = max(totalEX, line.ex)
            totalEY = max(totalEY, line.ey)
        self.rect = Rect()
        self.rect.x = totalSX
        self.rect.y = totalSY
        self.rect.width = totalEX - totalSX
        self.rect.height = totalEY - totalSY

class DefsDataStruct:
    def __init__(self, pt, type, id):
        self.point = pt
        self.id = id
        self.type = type

    def ParseAttribute(self, attr, imgCollection):
        if self.type == "IMAGE_TYPE":
            if attr.hasAttribute("xlink:href"):
                xlinkHref = attr.getAttribute("xlink:href")
                self.imageId = imgCollection.CovnertBase64(xlinkHref)
            if attr.hasAttribute("width"):
                width = attr.getAttribute("width")
                self.width = width
            if attr.hasAttribute("height"):
                height = attr.getAttribute("height")
                self.height = height
        elif self.type == "PATH_TYPE":
            if attr.hasAttribute("d"):
                self.dAttrData = PathDAttr()
                self.dAttrData.ParseAttribute(attr.getAttribute("d"))
                self.dAttrData.CalculatePathMinRect()

class StringStyle:
    def __init__(self, type, id):
        self.id = id
        self.type = type
        self.fontSize = 0
        self.fontColor = Color24()
        self.fontStrokWidth = 0.0

class Color24(Structure):
    _fields_ = [
        ('bule', c_ubyte),
        ('green', c_ubyte),
        ('red', c_ubyte),
    ]
    def SetColorValue(self, color):
        self.red = int(color[:2], 16)
        self.green = int(color[2:4], 16)
        self.bule = int(color[4:6], 16)

    def SetColorValueRGB(self, red, green, bule):
        self.red = int(red)
        self.green = int(green)
        self.bule = int(bule)

class MapHeader(Structure):
    _fields_ = [
        ('bgColor', Color24),
        ('nodeNum', c_ubyte),
        ('pathStyleNum', c_ubyte),
        ('width', c_short),
        ('height', c_short),
        ('imgDataOffset', c_uint),
    ]

class MapNode(Structure):
    _fields_ = [
        ('type', c_ubyte),
        ('count', c_ubyte),
        ('offset', c_uint),
    ]

class SVGPathStyle(Structure):
    _fields_ = [
        ('strokeCap', c_ubyte, 4),
        ('strokeJoin', c_ubyte, 4),
        ('strokeColor', Color24),
        ('fillColor', Color24),
        ('strokeWidth', c_float),
    ]

class PathStyleExt:
    FILL_TYPE = 2
    STROKE_TYPE = 1
    FILL_STROKE_TYPE = FILL_TYPE | STROKE_TYPE
    def __init__(self, id):
        self.id = id
        self.type = 0
        self.paintStyle = SVGPathStyle()

    def ParseAttribute(self, painStyle):
        stroke = re.findall(r"stroke:(.+?);", painStyle)
        if len(stroke) != 0 and stroke[0][0:1] == "#":
            self.type |= self.STROKE_TYPE
            self.paintStyle.strokeColor.SetColorValue(stroke[0][1:])

        fill = re.findall(r"fill:(.+?);", painStyle)
        if len(fill) != 0 and fill[0][0:1] == "#":
            self.type |= self.FILL_TYPE
            self.paintStyle.fillColor.SetColorValue(fill[0][1:])

        strokeWidth = re.findall(r"stroke-width:(.+?);", painStyle)
        if len(strokeWidth) != 0:
            self.paintStyle.strokeWidth = float(strokeWidth[0])

        strokeLinecap = re.findall(r"stroke-linecap:(.+?);", painStyle)
        if len(strokeLinecap) != 0:
            if strokeLinecap[0].lower() == "round":
                self.paintStyle.strokeCap = 0
            elif strokeLinecap[0].lower() == "butt":
                self.paintStyle.strokeCap = 1

        strokeLinejoin = re.findall(r"stroke-linejoin:(.+?);", painStyle)
        if len(strokeLinejoin) != 0:
            if strokeLinejoin[0].lower() == "round":
                self.paintStyle.strokeJoin = 0
            elif strokeLinejoin[0].lower() == "miter":
                self.paintStyle.strokeJoin = 1

class MapPath(Structure):
    m_cmdTabel = ['Z', 'M', 'L', 'H', 'V', 'Q', 'C', 'T', 'S', 'A']
    _fields_ = [
        ('type', c_ubyte),
        ('pathStyleIndex', c_ubyte),
        ('cmdNum', c_ushort),
        ('dataNum', c_ushort),
    ]
    def __init__(self):
        self.dAttrData = PathDAttr()

    def GetSize(self):
        return sizeof(MapPath) + sizeof(c_ubyte) * len(self.dAttrData.dataCmd) + \
            sizeof(c_float) * len(self.dAttrData.dataValue)

    def GetBytes(self):
        data = bytes(self)
        for cmd in self.dAttrData.dataCmd:
            data += struct.pack('@B', int(cmd))
        for value in self.dAttrData.dataValue:
            data += struct.pack('=f', float(value))
        return data

    def ParseAttribute(self, path):
        # 引用def里的style
        if path.hasAttribute("class"):
            classValue = path.getAttribute("class")
            for index, value in enumerate(g_pathStyleDataList):
                if value.id == classValue:
                    self.pathStyleIndex = index
                    self.type = value.type

        # path单独的style
        if path.hasAttribute("style"):
            style = path.getAttribute("style")
            data = PathStyleExt("none")
            data.ParseAttribute(style)
            g_pathStyleDataList.append(data)
            self.pathStyleIndex = len(g_pathStyleDataList) - 1
            self.type = data.type

        if path.hasAttribute("d"):
            self.dAttrData.ParseAttribute(path.getAttribute("d"))

        self.cmdNum = len(self.dAttrData.dataCmd)
        self.dataNum = len(self.dAttrData.dataValue)

class Rect(Structure):
    _fields_ = [
        ('x', c_short),
        ('y', c_short),
        ('width', c_short),
        ('height', c_short),
    ]

class MapImage(Structure):
    _fields_ = [
        ('id', c_ubyte),
        ('rect', Rect),
    ]

    def ParseAttribute(self, use):
        if use.hasAttribute("xlink:href"):
            classValue = use.getAttribute("xlink:href")
            for value in g_defsDataList:
                if classValue[1:] == value.id and value.type == "IMAGE_TYPE":
                    self.rect.width = int(value.width)
                    self.rect.height = int(value.height)
                    self.id = value.imageId
                    break
        if use.hasAttribute("x"):
            x = use.getAttribute("x")
            self.rect.x = int(round(float(x)))
        if use.hasAttribute("y"):
            y = use.getAttribute("y")
            self.rect.y = int(round(float(y)))

class MapText(Structure):
    _fields_ = [
        ('fontSize', c_ubyte),
        ('fontColor', Color24),
        ('strokeColor', Color24),
        ('strokeWidth', c_float),
        ('rect', Rect),
        ('charLen', c_ushort),
    ]

    def __init__(self, style):
        self.offset = []
        self.string = []
        self.textLength = 0
        if style.type == "FONT_STYLE_TYPE":
            self.fontColor = style.fontColor
            self.fillStyle = style
            self.fontSize = style.fontSize
        else:
            print("[Waring][font color]text style type error!")

    def ParseAttribute(self, backgroundText, foregroundText):
        bgText = backgroundText.firstChild.data
        fgText = foregroundText.firstChild.data
        if bgText != fgText:
            print("background text is not equal to foreground text")
            return -1

        self.string = bgText
        self.characterLen = len(bgText)
        self.charLen = len(bgText.encode('utf-8'))
        if backgroundText.hasAttribute("class"):
            classValue = backgroundText.getAttribute("class")
            for value in g_stringStyleDataList:
                if value.id == classValue:
                    self.strokeColor = value.fontColor
                    self.strokeWidth = value.fontStrokWidth
                    self.strokeStyle = value
                    break
        if backgroundText.hasAttribute("textLength"):
            self.textLength = int(backgroundText.getAttribute("textLength"))
        else:
            print("has no textLength param")

        if backgroundText.hasAttribute("xlink:href"):
            xlinkHref = backgroundText.getAttribute("xlink:href")
            for value in g_defsDataList:
                if value.id == xlinkHref[1:] and value.type == "PATH_TYPE":
                    self.rect.x = value.dAttrData.rect.x - (int)(self.fontSize / 2)
                    self.rect.y = value.dAttrData.rect.y - (int)(self.fontSize / 2)
                    self.rect.width = value.dAttrData.rect.width + self.fontSize
                    self.rect.height = value.dAttrData.rect.height + self.fontSize
                    spaceTatol = self.textLength - (self.characterLen * self.fontSize)
                    space = spaceTatol / (self.characterLen - 1)
                    for index in range(self.characterLen):
                        startLen = index * (self.fontSize + space)
                        line = ""
                        for line in value.dAttrData.line:
                            if startLen < line.len:
                                if line.isVertical == 1:
                                    offsetX = round(line.sx)
                                    offsetY_1 = round(line.sy - startLen)
                                    offsetY = round(line.sy + startLen)
                                    if round(line.sy) < offsetY_1 < round(line.ey):
                                        offsetY = offsetY_1
                                else:
                                    num = startLen / math.sqrt(1 + (line.slope * line.slope))
                                    offsetX_1 = round(num + line.sx)
                                    offsetX = round(-num + line.sx)
                                    if round(line.sx) < offsetX_1 < round(line.ex):
                                        offsetX = offsetX_1
                                    offsetY = round(line.slope * offsetX + line.d)
                                self.offset.append(offsetX - value.dAttrData.rect.x)
                                self.offset.append(offsetY - value.dAttrData.rect.y)
                                break
                            startLen -= line.len
                    break

    def GetSize(self):
        return sizeof(MapText) + sizeof(c_short) * self.characterLen * 2 + self.charLen

    def GetBytes(self):
        data = bytes(self)
        data += struct.pack(str(self.charLen) + 's', bytes(self.string, 'utf-8'))
        for offset in self.offset:
            data += struct.pack('@h', int(offset))
        return data

class MapPOI(Structure):
    _fields_ = [
        ('imgIndex', c_ubyte),
        ('textIndex', c_ubyte * 2),
        ('tag', c_ubyte),
        ('rank', c_ushort),
        ('id', c_ushort)
    ]

    def __init__(self):
        self.imgIndex = -1
        self.textIndex[0] = -1
        self.textIndex[1] = -1

    def set_id(self, id):
        self.id = id

    def ParseAttribute(self, gAttr, mapImgList, mapTextList):
        if gAttr.hasAttribute("data-rank"):
            self.rank = int(gAttr.getAttribute("data-rank"))
        if gAttr.hasAttribute("data-tag"):
            tag = gAttr.getAttribute("data-tag")
            if tag == "attraction":
                self.tag = 1
            elif tag == "road":
                self.tag = 2
            elif tag == "realty":
                self.tag = 3
            elif tag == "government":
                self.tag = 4
            else:
                self.tag = 0

        ## 需要保证use 和 text 最大为1
        useList = gAttr.getElementsByTagName("use")
        if len(useList) >= 1:
            image = MapImage()
            image.ParseAttribute(useList[0])
            self.imgIndex = len(mapImgList)
            mapImgList.append(image)

        textList = gAttr.getElementsByTagName("text")
        if len(textList) >= 1:
            textStyle = StringStyle("FONT_STROKE_STYLE_TYPE", "none")
            if textList[0].hasAttribute("class"):
                classValue = textList[0].getAttribute("class")
                for value in g_stringStyleDataList:
                    temp = classValue.split(" ")
                    if value.id == temp[0]:
                        textStyle = value
                        break
            else:
                print("[text] element has not [class] tar name!")
                return -1

            textPathList = textList[0].getElementsByTagName("textPath")
            textListLen = len(textPathList)
            index = 1
            while index < textListLen:
                text = MapText(textStyle)
                text.ParseAttribute(textPathList[index - 1], textPathList[index])
                self.textIndex[int(index / 2)] = len(mapTextList)
                index += 2
                mapTextList.append(text)

class MapRoad(Structure):
    _fields_ = [
        ('textIndex', c_byte),
    ]

    def __init__(self):
        self.textIndex = -1

    def ParseAttribute(self, text, mapTextList):
        textStyle = StringStyle("FONT_STROKE_STYLE_TYPE", "none")
        if text.hasAttribute("class"):
            classValue = text.getAttribute("class")
            styleId, testType = classValue.split(" ")
            for value in g_stringStyleDataList:
                if value.id == styleId:
                    textStyle = value
                    break

        textPathList = text.getElementsByTagName("textPath")
        if len(textPathList) != 2:
            print("[ERROR]:road text need 2 pieces of textPath")
            return

        mapText = MapText(textStyle)
        mapText.ParseAttribute(textPathList[0], textPathList[1])
        self.textIndex = len(mapTextList)
        mapTextList.append(mapText)

def MapPOIRankSort(elem):
    return elem.rank

class MapCollectionClass():
    def __init__(self):
        # Map Header
        self.mapHeader = MapHeader()
        self.mapHeader.imgDataOffset = sizeof(MapHeader)
        self.mapNode = []
        self.pathStyle = []
        self.mapPath = []
        self.mapText = []
        self.mapImg = []
        self.mapRoad = []
        self.mapPOI = []

    def GetSizeByNodeType(self, type):
        offset = 0
        if type == 0:
            for path in self.mapPath:
                offset += path.GetSize()
        elif type == 1:
            for text in self.mapText:
                offset += text.GetSize()
        elif type == 2:
            offset += len(self.mapImg) * sizeof(MapImage)
        elif type == 3:
            offset += len(self.mapRoad) * sizeof(MapRoad)
        elif type == 4:
            offset += len(self.mapPOI) * sizeof(MapPOI)
        return offset

    def CalculationMapNode(self):
        if len(self.mapPath) != 0:
            self.mapHeader.nodeNum += 1
            mapNode = MapNode()
            mapNode.type = 0
            mapNode.count = len(self.mapPath)
            self.mapNode.append(mapNode)
        if len(self.mapText) != 0:
            self.mapHeader.nodeNum += 1
            mapNode = MapNode()
            mapNode.type = 1
            mapNode.count = len(self.mapText)
            self.mapNode.append(mapNode)
        if len(self.mapImg) != 0:
            self.mapHeader.nodeNum += 1
            mapNode = MapNode()
            mapNode.type = 2
            mapNode.count = len(self.mapImg)
            self.mapNode.append(mapNode)
        if len(self.mapRoad) != 0:
            self.mapHeader.nodeNum += 1
            mapNode = MapNode()
            mapNode.type = 3
            mapNode.count = len(self.mapRoad)
            self.mapNode.append(mapNode)
        if len(self.mapPOI) != 0:
            self.mapHeader.nodeNum += 1
            mapNode = MapNode()
            mapNode.type = 4
            mapNode.count = len(self.mapPOI)
            self.mapNode.append(mapNode)
        offset = sizeof(MapHeader) + sizeof(MapNode) * len(self.mapNode) + len(self.pathStyle) * sizeof(SVGPathStyle)
        for node in self.mapNode:
            node.offset = offset
            offset += self.GetSizeByNodeType(node.type)

    def CalculateImgOffset(self):
        offset = sizeof(MapHeader)
        offset += len(self.mapNode) * sizeof(MapNode)
        offset += len(self.pathStyle) * sizeof(SVGPathStyle)
        for path in self.mapPath:
            offset += path.GetSize()
        for text in self.mapText:
            offset += text.GetSize()
        offset += len(self.mapImg) * sizeof(MapImage)
        offset += len(self.mapRoad) * sizeof(MapRoad)
        offset += len(self.mapPOI) * sizeof(MapPOI)
        self.mapHeader.imgDataOffset = offset

    def ParseAttribute(self, domTree):
        svg = domTree.documentElement
        ## 需要保证rect有且自有一个
        rect = svg.getElementsByTagName("rect")
        if len(rect) < 1:
            return

        # MapHeader Width
        if rect[0].hasAttribute("width"):
            self.mapHeader.width = int(rect[0].getAttribute("width"))
        # MapHeader Height
        if rect[0].hasAttribute("height"):
            self.mapHeader.height = int(rect[0].getAttribute("height"))
        # MapHeader BackGroupColor
        if rect[0].hasAttribute("style"):
            styleList = rect[0].getAttribute("style").split(';')
            for style in styleList:
                if style[:5] == "fill:":
                    self.mapHeader.bgColor.SetColorValue(style[6:])

        gList = svg.getElementsByTagName("g")
        for g in gList:
            if g.hasAttribute("class"):
                classValue = g.getAttribute("class")
                if classValue == "label":
                    poi = MapPOI()
                    poi.ParseAttribute(g, self.mapImg, self.mapText)
                    self.mapPOI.append(poi)
            else:
                pathList = g.getElementsByTagName("path")
                for path in pathList:
                    data = MapPath()
                    data.ParseAttribute(path)
                    self.mapPath.append(data)
                textList = g.getElementsByTagName("text")
                for text in textList:
                    if text.hasAttribute("class"):
                        classValue = text.getAttribute("class")
                        if classValue[-9:] == "type-road":
                            road = MapRoad()
                            road.ParseAttribute(text, self.mapText)
                            self.mapRoad.append(road)

        self.pathStyle = g_pathStyleDataList
        self.mapHeader.pathStyleNum = len(self.pathStyle)
        self.CalculationMapNode()
        self.CalculateImgOffset()
        return 0

    def WriteToBin(self, fb):
        # MapHeader
        fb.write(bytes(self.mapHeader))

        # MapNode
        for mapNode in self.mapNode:
            fb.write(bytes(mapNode))

        # PathStyle
        for style in self.pathStyle:
            fb.write(bytes(style.paintStyle))

        # MapPath
        for mapPath in self.mapPath:
            fb.write(mapPath.GetBytes())

        # MapText
        for mapText in self.mapText:
            fb.write(mapText.GetBytes())

        # MapImg
        for mapImg in self.mapImg:
            fb.write(bytes(mapImg))

        # mapRoad
        for mapRoad in self.mapRoad:
            fb.write(bytes(mapRoad))

        # mapPOI
        self.mapPOI.sort(key=MapPOIRankSort)
        for mapPOI in self.mapPOI:
            fb.write(bytes(mapPOI))

    def WriteToLog(self, fb):
        # MapHeader
        string = "MapHeader:\n"
        string += "  struct_size: %d\n" % sizeof(self.mapHeader)
        string += "  Data:\n"
        string += "    Color(BGR): (%x, %x, %x)\n" % (self.mapHeader.bgColor.bule,
                                                      self.mapHeader.bgColor.green, self.mapHeader.bgColor.red)
        string += "    nodeNum: %d\n" % self.mapHeader.nodeNum
        string += "    pathStyleNum: %d\n" % self.mapHeader.pathStyleNum
        string += "    width: %d\n" % self.mapHeader.width
        string += "    height: %d\n" % self.mapHeader.height
        string += "    imgDataOffset: %u\n" % self.mapHeader.imgDataOffset
        string += "\n"
        fb.write(string)

        # MapNode
        string = "MapNode:\n"
        string += "  struct_size: %d; type:[0:PATH, 1:TEXT, 2:IMAGE, 3:ROAD, 4:POI]\n" % sizeof(MapNode)
        for index, mapNode in enumerate(self.mapNode):
            string += "  Data %d:\n" % index
            string += "    type: %d\n" % mapNode.type
            string += "    count: %d\n" % mapNode.count
            string += "    offset: %u\n" % mapNode.offset
        string += "\n"
        fb.write(string)

        # PathStyle
        string = "SVGPathStyle:\n"
        string += "  struct_size: %d stokeCap:[0:ROUND, 1:BUTT] stroleJoin:[0:ROUND, 1:MITER]\n" % sizeof(SVGPathStyle)
        for index, pathStyle in enumerate(self.pathStyle):
            style = pathStyle.paintStyle
            string += "  Data %d:\n" % index
            string += "    strokeCap: %d\n" % style.strokeCap
            string += "    strokeJoin: %d\n" % style.strokeJoin
            string += "    strokeColor(BGR): (%x, %x, %x)\n" % (style.strokeColor.bule,
                                                                style.strokeColor.green, style.strokeColor.red)
            string += "    fillColor(BGR): (%x, %x, %x)\n" % (style.fillColor.bule,
                                                              style.fillColor.green, style.fillColor.red)
            string += "    strokeWidth: %0.3f\n" % style.strokeWidth
        string += "\n"
        fb.write(string)

        # MapPath
        string = "MapPath:\n"
        string += "  type:[1:STROKE, 2:FILL, 3:FILL_STROKE]"
        for index, path in enumerate(self.mapPath):
            string += "  Data %d: size(%d)\n" % (index, path.GetSize())
            string += "    type: %d \n" % path.type
            string += "    pathStyleIndex: %d \n" % path.pathStyleIndex
            string += "    cmdNum: %u \n" % path.cmdNum
            string += "    dataNum: %u \n" % path.dataNum
            string += "    cmd: %s\n" % path.dAttrData.dataCmd
            string += "    data: %s\n" % path.dAttrData.dataValue
        string += "\n"
        fb.write(string)

        # MapText
        string = "MapText:\n"
        for index, text in enumerate(self.mapText):
            string += "  Data %d: size(%d)\n" % (index, text.GetSize())
            string += "    fontSize: %d \n" % text.fontSize
            string += "    fontColor(BGR): (%x, %x, %x)\n" % (text.fontColor.bule,
                                                              text.fontColor.green, text.fontColor.red)
            string += "    strokeColor(BGR): (%x, %x, %x)\n" % (text.strokeColor.bule,
                                                                text.strokeColor.green, text.strokeColor.red)
            string += "    strokeWidth: %0.3f\n" % text.strokeWidth
            string += "    rect: (%d, %d, %d, %d) \n" % (text.rect.x, text.rect.y, text.rect.width, text.rect.height)
            string += "    charLen: %u \n" % text.charLen
            string += "    offset: %s\n" % text.offset
            string += "    string: %s\n" % text.string
        string += "\n"
        fb.write(string)

        # MapImg
        string = "MapImg:\n"
        string += "  struct_size: %d\n" % sizeof(MapImage)
        for index, image in enumerate(self.mapImg):
            string += "  Data %d\n" % index
            string += "    id: %d \n" % image.id
            string += "    rect: (%d, %d, %d, %d) \n" % (image.rect.x, image.rect.y, image.rect.width, image.rect.height)
        string += "\n"
        fb.write(string)

        # mapRoad
        string = "MapRoad:\n"
        string += "  struct_size: %d\n" % sizeof(MapRoad)
        for index, road in enumerate(self.mapRoad):
            string += "  Data %d\n" % index
            string += "    textIndex: %d \n" % road.textIndex
        string += "\n"
        fb.write(string)

        # mapPOI
        string = "MapPOI:\n"
        string += "  struct_size: %d tag:[0:unkonwn, 1:attraction, 2:road, 3:realty, 4:government]\n" % sizeof(MapPOI)
        for index, poi in enumerate(self.mapPOI):
            string += "  Data %d\n" % index
            string += "    imgIndex: %d \n" % poi.imgIndex
            string += "    textIndex[0]: %d \n" % poi.textIndex[0]
            string += "    textIndex[1]: %d \n" % poi.textIndex[1]
            string += "    tag: %d \n" % poi.tag
            string += "    rank: %d \n" % poi.rank
        string += "\n"
        fb.write(string)

class MapConverter:
    def __init__(self, srcFile, dstDir, enableLog):
        self.outputPath = dstDir
        self.inputFile = srcFile
        self.mapCollection = MapCollectionClass()
        self.imgCollection = ImageCollectionClass()
        self.logEnabled = enableLog

    def StartConvert(self):
        # open srcfile
        domTree = xml.dom.minidom.parse(self.inputFile)

        g_defsDataList.clear()
        g_stringStyleDataList.clear()
        g_pathStyleDataList.clear()
        # parse style data
        self.PareseStyleData(domTree)
        # parse defs data
        self.PareseDefsData(domTree)
        # parse render data
        self.mapCollection.ParseAttribute(domTree)

        # create & open dstfile
        outputfile = self.outputPath + "/" + os.path.basename(self.inputFile)[:-3] + "bin"
        fb = open(outputfile, 'wb')
        self.mapCollection.WriteToBin(fb)
        self.imgCollection.WriteToBin(fb)
        fb.close()

        if self.logEnabled:
            outLogfile = self.outputPath + "/" + os.path.basename(self.inputFile)[:-3] + "txt"
            logFb = open(outLogfile, 'w')
            self.mapCollection.WriteToLog(logFb)
            self.imgCollection.WriteToLog(logFb)
            logFb.close()

    def PareseDefsData(self, domTree):
        svg = domTree.documentElement
        defsList = svg.getElementsByTagName("defs")
        for defs in defsList:
            imageList = defs.getElementsByTagName("image")
            for image in imageList:
                id = "none"
                if image.hasAttribute("id"):
                    id = image.getAttribute("id")
                data = DefsDataStruct(image, "IMAGE_TYPE", id);
                data.ParseAttribute(image, self.imgCollection)
                g_defsDataList.append(data)

            pathList = defs.getElementsByTagName("path")
            for path in pathList:
                id = "none"
                if path.hasAttribute("id"):
                    id = path.getAttribute("id")
                data = DefsDataStruct(path, "PATH_TYPE", id);
                data.ParseAttribute(path, "none")
                g_defsDataList.append(data)

    def PareseStyleData(self, domTree):
        svg = domTree.documentElement
        styleList = svg.getElementsByTagName("style")
        for style in styleList:
            if style.hasAttribute("type") and style.getAttribute("type") == "text/css":
                if style.hasChildNodes():
                    textList = style.firstChild.data.splitlines()
                    for line in textList:
                        if line[:2] == '.t':
                            data = PathStyleExt(line.split(' ')[0][1:])
                            data.ParseAttribute(line)
                            g_pathStyleDataList.append(data)

                        elif line[:3] == '.ss':
                            data = StringStyle("FONT_STROKE_STYLE_TYPE", line.split('{')[0][1:])
                            fontWidth = re.findall(r"stroke-width:(.+?);", line)
                            if len(fontWidth) != 0:
                                data.fontStrokWidth = float(fontWidth[0])

                            fontColor = re.findall(r"stroke:rgba\((.+?)\)", line)
                            if len(fontColor) != 0:
                                color = fontColor[0].split(',')
                                data.fontColor.SetColorValueRGB(color[0], color[1], color[2])
                            g_stringStyleDataList.append(data)

                        elif line[:2] == '.s':
                            data = StringStyle("FONT_STYLE_TYPE", line.split('{')[0][1:])
                            fontSize = re.findall(r"font-size:(.+?);", line)
                            if len(fontSize) != 0:
                                data.fontSize = int(fontSize[0][:-2])

                            fontColor = re.findall(r"fill:rgba\((.+?)\)", line)
                            if len(fontColor) != 0:
                                color = fontColor[0].split(',')
                                data.fontColor.SetColorValueRGB(color[0], color[1], color[2])

                            g_stringStyleDataList.append(data)