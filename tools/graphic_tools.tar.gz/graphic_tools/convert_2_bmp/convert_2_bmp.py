# -*- coding: utf-8 -*-
import sys
import os
import argparse
import struct
import numpy as np
import cv2
from PIL import Image
import ctypes
import sys
from ctypes import CDLL,cdll
import platform

global lib
if platform.system().lower() == 'windows':
    lib = cdll.LoadLibrary(sys.path[0] + r"/ext_lib/windows/libmp42yuv.dll")
elif platform.system().lower() == 'linux':
    CDLL("./ext_lib/linux/libjpeg.so", mode=ctypes.RTLD_GLOBAL)
    lib = cdll.LoadLibrary(sys.path[0] + r"/ext_lib/linux/libsample_dec_yuv.so")

LIMIT_TABLE = [0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
    17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
    33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
    49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
    65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96,
    97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112,
    113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128,
    129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144,
    145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160,
    161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176,
    177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192,
    193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208,
    209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224,
    225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240,
    241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
    17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
    33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
    49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
    65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96,
    97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112,
    113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127]

class GetVideoFirstFrame():
    def __init__(self, file_path, width, height, out_path):
        self.input_path = file_path
        self.input_file = os.path.basename(file_path)[:-4].lower()
        self.width = width
        self.height = height
        self.out_path = out_path
        self.rgb = []

    def run(self):
        if self.input_path[-3:].lower() == "mp4":
            self.mp4_path = file_path
            self._extract_frame()
            self._convert_yuv_420_to_rgb()
            self._convert_rgb_to_bmp()
        elif self.input_path[-3:].lower() == "rgb":
            self.rgb_path = file_path
            self._convert_rgb_to_bmp()
        elif self.input_path[-3:].lower() == "yuv":
            self.yuv_path = file_path
            self._convert_yuv_420_to_rgb()
            self._convert_rgb_to_bmp()
        else:
            print(self.input_path, "is not supported")
            sys.exit(1)
        print("success!!")

    def _extract_frame(self):
        self.yuv_path = os.path.join(self.out_path, self.input_file + ".yuv")
        lib.get_yuv_from_mp4.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        lib.get_yuv_from_mp4.restype = ctypes.c_int
        lib.get_yuv_from_mp4(self.input_path.encode('utf-8'), self.yuv_path.encode('utf-8'))
        jpg_name = self.input_file + ".jpg"
        if os.path.exists(jpg_name):
            os.remove(jpg_name)

    def _yuv_to_rgb(self, row, col, y, cr, cb):
        r = int((((((y << 2) - 64) * 1024) + (((cr << 2) - 512) * 1576)) >> 10) >> 2)
        g = int((((((y << 2) - 64) * 1024) - (((cb << 2) - 512) * 187) - (((cr << 2) - 512) * 470)) >> 10) >> 2)
        b = int((((((y << 2) - 64) * 1024) + (((cb << 2) - 512) * 1859)) >> 10) >> 2)

        self.img[row, col, 0] = LIMIT_TABLE[b + 256]
        self.img[row, col, 1] = LIMIT_TABLE[g + 256]
        self.img[row, col, 2] = LIMIT_TABLE[r + 256]


    def _convert_yuv_420_to_rgb(self):
        with open(self.yuv_path, 'rb') as fp:
            data = fp.read()

        self.img = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        u_start_pos = self.width * self.height
        v_start_pos = self.width * self.height * 5 / 4
        for i in range(0, height) :
            for j in range(0, width) :
                y = data[i * width + j]
                cb = data[int(u_start_pos + int(i / 2) * int(self.width / 2) + int(j / 2))]
                cr = data[int(v_start_pos + int(i / 2) * int(self.width / 2) + int(j / 2))]
                self._yuv_to_rgb(i, j, y, cr, cb)
        self.rgb_path = os.path.join(self.out_path, self.input_file + ".rgb")
        with open(self.rgb_path, 'wb') as f:
            f.write(self.img.tobytes())

    def _convert_rgb_to_bmp(self):
        with open(self.rgb_path, 'rb') as f:
            binary_data = f.read()
        data = np.frombuffer(binary_data, dtype=np.uint8)
        img = data.reshape(self.height, self.width, 3)
        out_bmp_path = os.path.join(self.out_path, self.input_file + ".bmp")
        cv2.imwrite(out_bmp_path, img)

def GetParameters():
    parser = argparse.ArgumentParser()
    parser.add_argument('-file', '-f', type=str, required=True,
                        help='The input file path, support .rgb, .yuv, .mp4')
    parser.add_argument('-size', '-s', type=str, required=True,
                        help='The frame size, such as 466x466')
    parser.add_argument('-out', '-o', type=str, default=os.getcwd() + "/out", required=False,
                        help='output dir')
    config = parser.parse_args()
    return config

if __name__ == "__main__":
    user_input = GetParameters()
    out_path = user_input.out
    file_path = user_input.file
    parts = user_input.size.split("x")
    if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
        width = int(parts[0])
        height = int(parts[1])
    else:
        print(user_input.s, "is not illegal")
        sys.exit(1)
    if not os.path.exists(out_path):
        os.mkdir(out_path)

    obj = GetVideoFirstFrame(file_path, width, height, out_path)
    obj.run()