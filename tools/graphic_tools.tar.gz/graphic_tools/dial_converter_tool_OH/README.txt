usage: main.py [-h] [-file FILE] [-dir DIR] [-output OUTPUT]

options:
  -h, --help           显示帮助信息。
  -file FILE, -f FILE  指定待转化的离线表盘xml文件路径（注意xml中图片和视频的路径是相对于xml文件本身的）。
  -dir DIR, -d DIR     指定待转化的文件夹路径。根据指定路径，转化文件夹下所有xml类型文件（注意xml中图片和视频的路径是相对于xml文件本身的）。
  -output OUTPUT       指定转化后离线表盘打包资源所在路径

example:
windows: python .\main.py -dir .\instance