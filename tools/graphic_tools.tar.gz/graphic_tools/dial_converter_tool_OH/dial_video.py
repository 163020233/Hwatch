#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Rect
from common_types import CommonParser
import video_convert
import img_convert


class DialVideo(Structure):
    _fields_ = [
        ('rect', Rect),
        ('offset', c_uint),
        ('color_key', c_uint),
        ('img_id', c_uint),
        ('display_mode', c_ubyte),
    ]

    def __init__(self):
        self.display_mode = 0
        self.common_parser = CommonParser()

    def parse_attributes(self, attributes):
        x, y, w, h = attributes["rect"].split(" ")
        self.rect.x = int(x)
        if self.rect.x < np.iinfo(np.int16).min or self.rect.x > np.iinfo(np.int16).max:
            print("[ERR]:video rect x out of range")
            sys.exit(1)
        self.rect.y = int(y)
        if self.rect.y < np.iinfo(np.int16).min or self.rect.y > np.iinfo(np.int16).max:
            print("[ERR]:video rect y out of range")
            sys.exit(1)
        self.rect.w = int(w)
        if self.rect.w < np.iinfo(np.int16).min or self.rect.w > np.iinfo(np.int16).max:
            print("[ERR]:video rect w out of range")
            sys.exit(1)
        self.rect.h = int(h)
        if self.rect.h < np.iinfo(np.int16).min or self.rect.h > np.iinfo(np.int16).max:
            print("[ERR]:video rect h out of range")
            sys.exit(1)

        self.color_key = int(attributes["color_key"], 16)
        self.offset = video_convert.instance.convert_video(attributes["source"])
        self.img_id = img_convert.instance.convert_img(attributes["preview_frame"])

        if "display_mode" in attributes.getNames():
            self.display_mode = self.common_parser.parse_display_mode(DialVideo.__name__, attributes['display_mode'])

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)

    def calculate_relative_pos(self, x, y):
        self.rect.x = self.rect.x - x
        self.rect.y = self.rect.y - y