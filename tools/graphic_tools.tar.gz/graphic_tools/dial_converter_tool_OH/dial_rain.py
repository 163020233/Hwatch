#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from ctypes import *
import img_convert


class DialRain(Structure):
    _fields_ = [
        ('count', c_ubyte),
        ('blur_radius', c_float),
        ('update_interval', c_uint8),
        ('pause_interval', c_uint8),
        ('duration', c_int16),
    ]

    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        self.img_id = []
        self.count = 0
        self.blur_radius = 0
        self.update_interval = 0
        self.pause_interval = 0
        self.duration = 3000
        self.display_mode = 0

    def parse_attributes(self, attributes):
        img_names = attributes["img_names"].split(",")
        self.count = len(img_names)
        for img in img_names:
            img_id = img_convert.instance.convert_img(img)
            self.img_id.append(img_id)

        option_attr_int = {'update_interval': (0, 255), 'pause_interval': (0, 255),
                           'duration': (0, np.iinfo(np.int16).max)}
        for attr in attributes.getNames():
            if attr == 'blur_radius':
                val = float(attributes[attr])
                if 0 <= val <= 32.0:
                    self.blur_radius = val
                else:
                    print(f"[ERR]:DialRain {attr} : {val} out of range")
                    sys.exit(1)
            elif attr in option_attr_int:
                val = int(attributes[attr])
                if option_attr_int[attr][0] <= val <= option_attr_int[attr][1]:
                    setattr(self, attr, val)
                else:
                    print(f"[ERR]:DialRain {attr} : {val} out of range")
                    sys.exit(1)

    def get_bytes(self):
        ret = bytes(self)
        for index in range(self.count):
            ret += struct.pack('@H', self.img_id[index])
        return ret

    def get_size(self):
        size = sizeof(self) + sizeof(c_ushort) * self.count
        return size
