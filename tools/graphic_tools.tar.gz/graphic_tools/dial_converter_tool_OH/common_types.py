#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
from enum import Enum
from ctypes import *
import re


class Point(Structure):
    _fields_ = [
        ('x', c_short),
        ('y', c_short),
    ]


class Rect(Structure):
    _fields_ = [
        ('x', c_short),
        ('y', c_short),
        ('w', c_ushort),
        ('h', c_ushort)
    ]


class ColorStop(Structure):
    _fields_ = [
        ('stop', c_float),
        ('color', c_uint),
    ]


class TimeInterval(Structure):
    _fields_ = [
        ('start', c_ubyte),
        ('end', c_ubyte),
    ]

    def __init__(self, start, end, *args, **kw):
        super().__init__(*args, **kw)
        self.start = start
        self.end = end

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)


class TimeIntervals:
    def __init__(self, tuples):
        self.tuples = []
        for element in tuples:
            self.tuples.append(TimeInterval(element[0], element[1]))

    def get_bytes(self):
        ret = bytes(0)
        for t in self.tuples:
            ret += t.get_bytes()
        return ret

    def get_size(self):
        return len(self.tuples) * sizeof(TimeInterval)

    def get_cnt(self):
        return len(self.tuples)


class CommonParser:
    @staticmethod
    def parse_language(class_name, val):
        language = int(val)
        min_val, max_val = 0, 255
        if language < min_val or language > max_val:
            print(f'[ERR]:{class_name} language out of range')
            sys.exit(1)
        return language

    @staticmethod
    def parse_is_periodic(class_name, val):
        is_periodic = False
        if val == 'true':
            is_periodic = True
        elif val == 'false':
            is_periodic = False
        else:
            print(f'[ERR]:{class_name} is_periodic out of range')
            sys.exit(1)
        return is_periodic

    @staticmethod
    def parse_display_mode(class_name, val):
        display_mode = 0
        if val == "normal":
            display_mode = 0
        elif val == "ambient":
            display_mode = 1
        elif val == "always":
            display_mode = 2
        else:
            print(f'[ERR]:{class_name} display_mode wrong value')
            sys.exit(1)
        return display_mode

    @staticmethod
    def parse_time_intervals(class_name, val):
        separator = r'\s+'
        pattern = re.compile(r'(\d+)-(\d+)')
        values = val.strip()
        words = re.split(separator, values)
        res = []
        for e in words:
            match = re.match(pattern, e)
            if match:
                start, end = int(match.group(1)), int(match.group(2))
                if start < end and (0 <= start < 24) and (0 < end <= 24):
                    res.append([start, end])
        res.sort(key=lambda x: x[0])
        merge_tuples = []
        for e in res:
            if len(merge_tuples) == 0:
                merge_tuples.append(e)
            else:
                last = merge_tuples[-1]
                if e[0] <= last[1]:
                    last[1] = max(e[1], last[1])
                else:
                    merge_tuples.append(e)
        return TimeIntervals(merge_tuples)
