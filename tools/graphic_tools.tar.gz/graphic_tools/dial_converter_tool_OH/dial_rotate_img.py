#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point
from common_types import CommonParser
import img_convert


class DialRotateImg(Structure):
    _fields_ = [
        ('pos', Point),
        ('center', Point),
        ('rotate_start', c_short),
        ('rotate_end', c_short),
        ('img_id', c_ushort),
        ('bind_data', c_short),
        ('is_periodic', c_bool),
        ('display_mode', c_ubyte),
    ]

    def __init__(self):
        self.is_periodic = False
        self.display_mode = 0
        self.common_parser = CommonParser()

    def parse_attributes(self, attributes):
        input_pos_x, input_pos_y = attributes["position"].split(" ")
        self.pos.x = int(input_pos_x)
        if self.pos.x < np.iinfo(np.int16).min or self.pos.x > np.iinfo(np.int16).max:
            print("[ERR]:rotate image pos x out of range")
            sys.exit(1)

        self.pos.y = int(input_pos_y)
        if self.pos.y < np.iinfo(np.int16).min or self.pos.y > np.iinfo(np.int16).max:
            print("[ERR]:rotate image pos y out of range")
            sys.exit(1)

        x, y = attributes["rotate_center"].split(" ")
        self.center.x = round(float(x))
        self.center.y = round(float(y))

        self.rotate_start = int(attributes["rotate_start"])
        if self.rotate_start < 0.0 or self.rotate_start > 360.0 :
            print("[ERR]:rotate image start angle out of range, [0, 360]")
            sys.exit(1)

        self.rotate_end = int(attributes["rotate_end"])
        if self.rotate_end < 0.0 or self.rotate_end > 360.0 :
            print("[ERR]:rotate image end angle out of range, [0, 360]")
            sys.exit(1)

        self.bind_data = int(attributes["bind_data"])
        if self.bind_data < 0 or self.bind_data > np.iinfo(np.int16).max:
            print("[ERR]:rotate image bind data out of range")
            sys.exit(1)
        self.img_id = img_convert.instance.convert_img(attributes["img_name"])

        if 'is_periodic' in attributes:
            self.is_periodic = self.common_parser.parse_is_periodic(DialRotateImg.__name__, attributes['is_periodic'])
        if "display_mode" in attributes.getNames():
            self.display_mode = self.common_parser.parse_display_mode(DialRotateImg.__name__,
                                                                      attributes['display_mode'])

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)

    def calculate_relative_pos(self, x, y):
        self.pos.x = self.pos.x - x
        self.pos.y = self.pos.y - y