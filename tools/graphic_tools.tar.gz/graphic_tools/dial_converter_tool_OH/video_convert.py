#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import ctypes
from ctypes import *


class VideoConvertTool:
    def __init__(self):
        self.video_num = 0
        self.video_name = []
        self.video_index = []
        self.video_data = bytearray()

    def convert_video(self, path):
        if path in self.video_name:
            index = self.video_name.index(path)
            return self.video_index[index]
        fp = open(path, 'rb')
        data = fp.read()
        fp.close()
        self.video_name.append(path)
        self.video_num += 1
        ret = len(self.video_data)
        self.video_index.append(ret)
        self.video_data += data
        return ret

    def write_data_to_bin(self, fb):
        fb.write(self.video_data)

    def get_size(self):
        return len(self.video_data)

instance = VideoConvertTool()
