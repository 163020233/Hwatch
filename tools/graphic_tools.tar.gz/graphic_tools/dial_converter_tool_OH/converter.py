#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import os
import re
import struct
import ctypes
import sys
from ctypes import *
import xml.sax
from enum import Enum
import img_convert
import video_convert
import dial_sequence_img
from dial_static_img import DialStaticImg
from dial_sequence_img import DialSequenceImg
from dial_rotate_img import DialRotateImg
from dial_option_img import DialOptionImg
from dial_digital_img import DialDigitalImg
from dial_label import DialLabel
from dial_arc_label import DialArcLabel
from dial_box_progress import DialBoxProgress
from dial_arc_progress import DialArcProgress
from dial_video import DialVideo
from dial_click import DialClick
from dial_kaleidoscope import DialKaleidoscope
from dial_container import DialContainer
from dial_options import DialOptions
from dial_light_attr import DialLightAttr
from dial_ripple import DialRipple
from dial_earth import DialEarth
from dial_moon import DialMoon
from dial_rain import DialRain
from dial_file_pack import DialFilePack
from dial_lotti import DialLotti


class DialHeader(Structure):
    _fields_ = [
        ('dial_name', c_char * 16),
        ('width', c_short),
        ('height', c_short),
        ('version', c_char * 16),
        ('preview_img_id', c_ushort),
        ('description', c_char * 128),
        ('imgoffset', c_uint),
        ('dial_view_count', c_ubyte),
        ('display_capability', c_ubyte),
        ('ambient_period', c_ushort),
        ('normal_period', c_ushort),
        ('uuid', c_uint32),
        ('watch_type', c_ubyte),
        ('watch_version', c_char * 16),
    ]
    _DIAL_DEFAULT_MAX_WIDTH = 960
    _DIAL_DEFAULT_MAX_HEIGHT = 960

    def __init__(self):
        self.watch_version = bytes("", encoding="utf8")
        self.preview_img_id = 0
        self.version = bytes("", encoding="utf8")
        self.description = bytes("", encoding="utf8")
        self.dial_name = bytes("", encoding="utf8")
        self.imgoffset = 0
        self.dial_view_count = 0
        self.display_capability = 0
        self.ambient_period = 60000
        self.normal_period = 60000
        self.view_type = []
        self.view_pt = []
        self.uuid = 0
        self.watch_type = 0

    def get_version(self):
        return str(self.version, "utf-8")

    def parse_attributes(self, attributes):
        title = attributes["title"]
        self.dial_name = bytes(title, encoding="utf8")

        description = attributes["description"]
        self.description = bytes(description, encoding="utf8")

        version = attributes["version"]
        self.version = bytes(version, encoding="utf8")
        if attributes['version'] != "3.1" and attributes['version'] != "3.0":
            print("[ERR]version is not 3.1 or 3.0")
            sys.exit(1)

        self._parse_size_attr(attributes["size"])

        preview_str = attributes["preview_img"]
        self.preview_img_id = img_convert.instance.convert_img(preview_str)

        self.uuid = int(attributes['uuid'])
        self.watch_version = bytes(attributes['watch_version'], encoding="utf8")

        min_period, max_period = 16, 60000
        for attr in attributes.getNames():
            if attr == "tile_width":
                tile_width = int(attributes["tile_width"])
                img_convert.instance.set_tile_width(tile_width)
            elif attr == "ambient_period":
                self.ambient_period = int(attributes[attr])
                if self.ambient_period < min_period or self.ambient_period > max_period:
                    print("[WARNING]:dial ambient period value not support, using default value 0")
                    self.ambient_period = max_period
            elif attr == 'normal_peroid':
                self.normal_period = int(attributes[attr])
                if self.normal_period < min_period or self.normal_period > max_period:
                    print("[WARNING]:dial normal period value not support, using default value 0")
                    self.normal_period = max_period
            elif attr == 'watch_type':
                self.watch_type = int(attributes[attr])
                if self.watch_type < 0 or self.watch_type > 255:
                    print("[ERR]:dial watch_type out of range")
                    sys.exit(1)

    def add_view(self, view_obj, view_type):
        self.view_pt.append(view_obj)
        self.view_type.append(view_type)
        self.dial_view_count += 1

    def get_bytes(self):
        ret = bytes(self)
        for index in range(self.dial_view_count):
            ret += struct.pack('@b', self.view_type[index])
        return ret

    def get_size(self):
        return sizeof(self) + sizeof(c_ubyte) * self.dial_view_count

    def _parse_size_attr(self, input_size):
        input_width, input_height = input_size.split(' ')
        width = int(input_width)
        if width <= 0 or width > DialHeader._DIAL_DEFAULT_MAX_WIDTH :
            print(f"[ERR]:dial size width out of range, (0, {DialHeader._DIAL_DEFAULT_MAX_WIDTH}], value:{width}")
            sys.exit(1)
        self.width = width

        height = int(input_height)
        if height <= 0 or height > DialHeader._DIAL_DEFAULT_MAX_HEIGHT :
            print(f"[ERR]:dial size height out of range, (0, {DialHeader._DIAL_DEFAULT_MAX_HEIGHT}], value:{height}")
            sys.exit(1)
        self.height = height


class DialConvertTool(xml.sax.ContentHandler):
    parser = xml.sax.make_parser()
    # the type of view
    DIAL_STATIC_IMG_TYPE = 0
    DIAL_SEQUENCE_IMG_TYPE = 1
    DIAL_ROTATE_IMG_TYPE = 2
    DIAL_OPTION_IMG_TYPE = 3
    DIAL_DIGITAL_IMG_TYPE = 4
    DIAL_LABEL_TYPE = 5
    DIAL_ARC_LABEL_TYPE = 6
    DIAL_BOX_PROGRESS_TYPE = 7
    DIAL_ARC_PROGRESS_TYPE = 8
    DIAL_VIDEO_TYPE = 9
    DIAL_CLICK_TYPE = 10
    DIAL_KALEIDOSCCOPE_TYPE = 11
    DIAL_CONTAINER_TYPE = 12
    DIAL_OPTIONS_TYPE = 13
    DIAL_LOTTI_TYPE = 14
    DIAL_LIGHT_ATTR_TYPE = 15
    DIAL_RIPPLE_TYPE = 16
    DIAL_EARTH_TYPE = 17
    DIAL_MOON_TYPE = 18
    DIAL_RAIN_TYPE = 19

    def __init__(self):
        img_convert.instance.clear()
        self.in_file = ""
        self.out_path = ""
        self.header = DialHeader()
        self.parser.setFeature(xml.sax.handler.feature_namespaces, 0)
        self.parser.setContentHandler(self)
        self.cur_container = None
        self.cur_option = None
        self.cur_seq = None
        self.sub_imgs = []
        self.file_packer = DialFilePack()

    def _try_add_view_to_container(self, view):
        if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
            self.cur_container.add_child_view(view)

    def _try_add_view_to_options(self, view):
        if self.cur_option is not None and isinstance(self.cur_option, DialOptions):
            self.cur_option.add_child_view(view)

    def startElement(self, tag, attributes):
        if tag == "dial":
            self.header.parse_attributes(attributes)
        elif tag == "options":
            view = DialOptions()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_OPTIONS_TYPE)
            self.cur_option = view
        elif tag == 'container':
            view = DialContainer()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_CONTAINER_TYPE)
            self.cur_container = view
            self._try_add_view_to_options(view)
        elif tag == "static_img":
            view = DialStaticImg()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_STATIC_IMG_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)
        elif tag == "sequence_img":
            view = DialSequenceImg()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_SEQUENCE_IMG_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)
            self.cur_seq = view
            self.sub_imgs = []
        elif tag == "rotate_img":
            view = DialRotateImg()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_ROTATE_IMG_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)
        elif tag == "option_img":
            view = DialOptionImg()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_OPTION_IMG_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)
        elif tag == "digital_img":
            view = DialDigitalImg()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_DIGITAL_IMG_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)
        elif tag == "label":
            view = DialLabel()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_LABEL_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)
        elif tag == "arc_label":
            view = DialArcLabel()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_ARC_LABEL_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)
        elif tag == "box_progress":
            view = DialBoxProgress()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_BOX_PROGRESS_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)
        elif tag == "arc_progress":
            view = DialArcProgress()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_ARC_PROGRESS_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)
        elif tag == "video":
            view = DialVideo()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_VIDEO_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)
        elif tag == "click":
            view = DialClick()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_CLICK_TYPE)
            if self.cur_container is not None:
                print("[ERR]:cannot add click under container")
                sys.exit(1)
        elif tag == "kaleidoscope":
            view = DialKaleidoscope()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_KALEIDOSCCOPE_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
        elif tag == 'imgs':
            view = dial_sequence_img.Imgs()
            view.parse_attributes(attributes)
            self.sub_imgs.append(view)
        elif tag == 'element':
            if 'layer' in attributes.getNames() and attributes['layer'] == 'light':
                if self.header.get_version() == "3.0":
                    raise Exception(f"version is not 3.1 when parse light")
                view = DialLightAttr()
                view.parse_attributes(attributes)
                self.header.add_view(view, self.DIAL_LIGHT_ATTR_TYPE) # light attr is not in option or group
        elif tag == 'ripple':
            if self.header.get_version() == "3.0":
                raise Exception(f"version is not 3.1 when parse ripple")
            view = DialRipple()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_RIPPLE_TYPE)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
        elif tag == 'earth':
            if self.header.get_version() == "3.0":
                raise Exception(f"version is not 3.1 when parse earth")
            view = DialEarth(self.file_packer)
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_EARTH_TYPE)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
        elif tag == 'moon':
            if self.header.get_version() == "3.0":
                raise Exception(f"version is not 3.1 when parse moon")
            view = DialMoon(self.file_packer)
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_MOON_TYPE)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
        elif tag == 'rain':
            if self.header.get_version() == "3.0":
                raise Exception(f"version is not 3.1 when parse rain")
            view = DialRain()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_RAIN_TYPE)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
        elif tag == 'lottie':
            view = DialLotti(self.file_packer)
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_LOTTI_TYPE)
            self._try_add_view_to_container(view)
            if self.cur_container is None:
                self._try_add_view_to_options(view)
                if self.cur_option is not None and isinstance(self.cur_option, DialOptions):
                    if self.cur_option.display_mode != 0:
                        print("[ERR]:lotti can not be added into an option that supports aod!")
                        sys.exit(1)
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                if self.cur_container.display_mode != 0:
                    print("[ERR]:lotti can not be added into a container that supports aod!")
                    sys.exit(1)
                view.calculate_relative_pos(self.cur_container.rect.x, self.cur_container.rect.y)

    def endElement(self, tag):
        if tag == "dial":
            # create & open dstfile
            outputfile = self.out_path + "/" + os.path.basename(self.in_file)[:-3] + "bin"
            fb = open(outputfile, 'wb')
            os.chmod(outputfile, 0o0755)
            self._write_data_to_bin(fb)
            fb.close()
        elif tag == 'container':
            if self.cur_container is not None and isinstance(self.cur_container, DialContainer):
                self.cur_container.set_display_mode(self.cur_container.display_mode)
            self.cur_container = None
        elif tag == 'options':
            if self.cur_option is not None and isinstance(self.cur_option, DialOptions):
                self.cur_option.set_display_mode(self.cur_option.display_mode)
                self.cur_option.update_tag_num()
                self.cur_option.update_date_size()
            self.cur_option = None
        elif tag == "sequence_img":
            if isinstance(self.cur_seq, DialSequenceImg):
                if len(self.sub_imgs) == 0:
                    print("[ERR]: tag <imgs> must be at least 1!")
                    sys.exit(1)
                for imgs in self.sub_imgs:
                    self.cur_seq.add_imgs(imgs)
            self.cur_seq = None
            self.sub_imgs = []

    def convert_xml_to_output(self, in_file, out_path):
        self.in_file = in_file
        self.out_path = out_path
        self.parser.parse(in_file)

    def _set_display_capability(self):
        aod_only, normal_only = 0, 0
        for view in self.header.view_pt:
            if view.display_mode == 1:
                aod_only = aod_only + 1
            elif view.display_mode == 2:
                aod_only = aod_only + 1
                normal_only = normal_only + 1
            else:
                normal_only = normal_only + 1
        if normal_only > 0 and aod_only > 0:
            self.header.display_capability = 2
        elif normal_only > 0 and aod_only == 0:
            self.header.display_capability = 0
        else:
            self.header.display_capability = 1

    def _write_header(self, fb):
        self._set_display_capability()
        self.header.imgoffset += self.header.get_size()
        for view in self.header.view_pt:
            self.header.imgoffset += view.get_size()

    def _write_views(self, fb):
        for view in self.header.view_pt:
            if isinstance(view, DialVideo):
                view.offset += self.header.imgoffset + img_convert.instance.get_size()
            elif isinstance(view, DialEarth) or isinstance(view, DialMoon) or isinstance(view, DialLotti):
                view.offset = self.header.imgoffset + img_convert.instance.get_size() +\
                              video_convert.instance.get_size() + self.file_packer.get_offset(view.file_index)
            fb.write(view.get_bytes())

    def _write_data_to_bin(self, fb):
        self._write_header(fb)
        fb.write(self.header.get_bytes())
        self._write_views(fb)
        img_convert.instance.write_data_to_bin(fb)
        video_convert.instance.write_data_to_bin(fb)
        self.file_packer.write_to_fb(fb)
