#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
# 1\ 解析命令 python main.py -d [DIR] -o [OUT_DIR]
# 2\ 循环执行svg解析写入
import sys
import os
import argparse
from converter import DialConvertTool


def get_parameters():
    parser = argparse.ArgumentParser()

    parser.add_argument('-file', '-f', type=str, default=None, required=False,
                        help='Specifies the path of the offline watch face XML file to be converted.')

    parser.add_argument('-dir', '-d', type=str, default=None, required=False,
                        help='Specifies the path of the folder to be converted. '
                             'Convert all .xml files in the folder according to the specified path.')

    parser.add_argument('-output', type=str, default=os.getcwd() + "/out", required=False,
                        help='output dir')

    config = parser.parse_args()
    return config

if __name__ == "__main__":
    userInput = get_parameters()
    outputPath = userInput.output
    inputFile = userInput.file
    inputDir = userInput.dir
    if inputFile is None and inputDir is None:
        print("ERROR: there are no input file or dir")
        exit(1)
    # Create an output folder.
    print("output dir : " + outputPath)
    if not os.path.exists(outputPath):
        os.mkdir(outputPath)

    cwd = os.getcwd()
    if inputFile is not None and not os.path.isdir(inputFile) and inputFile[-3:].lower() == "xml":
        inputFile = os.path.abspath(inputFile)
        os.chdir(os.path.dirname(inputFile))
        print("input file : " + inputFile)
        converter = DialConvertTool()
        converter.convert_xml_to_output(inputFile, outputPath)
        os.chdir(cwd)

    if inputDir is None:
        exit(0)
    for root, _, files in os.walk(os.path.abspath(inputDir)):
        # 遍历当前文件夹下的所有文件
        for file in files:
            file_path = os.path.join(root, file)
            if not os.path.isdir(file) and file[-3:].lower() == "xml":
                os.chdir(os.path.dirname(file_path))
                print("input:" + file_path)
                converter = DialConvertTool()
                converter.convert_xml_to_output(file_path, outputPath)
                print("out:" + outputPath)
                os.chdir(cwd)