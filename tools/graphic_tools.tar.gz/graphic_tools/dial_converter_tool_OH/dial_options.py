#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
from xml.dom.minidom import parse
from ctypes import *
from common_types import Rect
from common_types import CommonParser
import dial_container
import numpy as np


class DialOptions(Structure):
    _fields_ = [
        ('display_mode', c_ubyte),
        ('tag_num', c_ubyte),
        ('data_size', c_uint16),
    ]

    def _parse_display_mode(self, val):
        self.display_mode = self.common_parser.parse_display_mode(DialOptions.__name__, val)

    def __init__(self):
        self.display_mode = 0
        self.data_size = 0
        self.tag_num = 0
        self.subviews = []
        self.common_parser = CommonParser()
        self.parse_fn = {
            'display_mode': self._parse_display_mode,
        }

    def parse_attributes(self, attributes):
        option_attr = ['display_mode', ]
        for attr in option_attr:
            if attr in attributes:
                self.parse_fn[attr](attributes[attr])

    def set_display_mode(self, mode):
        for view in self.subviews:
            if isinstance(view, dial_container.DialContainer):
                view.set_display_mode(mode)
            elif hasattr(view, 'display_mode'):
                view.display_mode = mode

    def add_child_view(self, view):
        if view is not None:
            self.subviews.append(view)

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)

    def update_tag_num(self):
        self.tag_num = 0
        for view in self.subviews:
            self.tag_num = self.tag_num + 1
            if isinstance(view, dial_container.DialContainer):
                self.tag_num = self.tag_num + view.get_child_view_num()

    def update_date_size(self):
        self.data_size = 0
        for view in self.subviews:
            if view is None:
                continue
            if isinstance(view, dial_container.DialContainer):
                self.data_size = self.data_size + view.get_size() + view.data_size
            elif hasattr(view, 'get_size'):
                self.data_size = self.data_size + view.get_size()
