#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
from xml.dom.minidom import parse
from ctypes import *
from common_types import Rect
from common_types import CommonParser
import numpy as np


class DialContainer(Structure):
    _fields_ = [
        ('rect', Rect),
        ('dialview_num', c_ubyte),
        ('display_mode', c_ubyte),
        ('data_size', c_uint16)
    ]

    def _parse_rect(self, val):
        x, y, w, h = val.split(" ")
        self.rect.x = int(x)
        if self.rect.x < np.iinfo(np.int16).min or self.rect.x > np.iinfo(np.int16).max:
            print("[ERR]:container rect x out of range")
            sys.exit(1)
        self.rect.y = int(y)
        if self.rect.y < np.iinfo(np.int16).min or self.rect.y > np.iinfo(np.int16).max:
            print("[ERR]:container rect y out of range")
            sys.exit(1)
        self.rect.w = int(w)
        if self.rect.w < np.iinfo(np.int16).min or self.rect.w > np.iinfo(np.int16).max:
            print("[ERR]:container rect w out of range")
            sys.exit(1)
        self.rect.h = int(h)
        if self.rect.h < np.iinfo(np.int16).min or self.rect.h > np.iinfo(np.int16).max:
            print("[ERR]:container rect h out of range")
            sys.exit(1)

    def _parse_display_mode(self, val):
        self.display_mode = self.common_parser.parse_display_mode(DialContainer.__name__, val)

    def __init__(self):
        self.rect = Rect(0, 0, 200, 200)
        self.dialview_num = 0
        self.display_mode = 0
        self.common_parser = CommonParser()
        self.data_size = 0
        self.subviews = []
        self.parse_fn = {
            'rect': self._parse_rect,
            'display_mode': self._parse_display_mode,
        }

    def parse_attributes(self, attributes):
        must_attr = ['rect', ]
        for attr in must_attr:
            self.parse_fn[attr](attributes[attr])
        option_attr = ['display_mode', ]
        for attr in option_attr:
            if attr in attributes:
                self.parse_fn[attr](attributes[attr])

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)

    def set_display_mode(self, mode):
        self.display_mode = mode
        for view in self.subviews:
            if hasattr(view, 'display_mode'):
                view.display_mode = mode

    def add_child_view(self, view):
        self.dialview_num = self.dialview_num + 1
        if view is not None:
            self.subviews.append(view)
        if hasattr(view, 'get_size'):
            self.data_size = self.data_size + view.get_size()

    def get_child_view_num(self):
        return self.dialview_num
