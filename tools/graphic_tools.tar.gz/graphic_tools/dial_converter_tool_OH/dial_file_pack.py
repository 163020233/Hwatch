import os
import sys
import subprocess
import platform


def get_flat_buffers_tool():
    path = None
    if platform.system().lower() == 'windows':
        path = os.path.abspath(os.path.join(sys.path[0], r"lott_tool\flatbufferstool.exe"))
    elif platform.system().lower() == 'linux':
        path = os.path.abspath(os.path.join(sys.path[0], r"lott_tool/flatbufferstool"))
    else:
        raise Exception("only support windows or linux")
    if not os.path.exists(path):
        raise Exception(f"{path} not exists!")
    return path


class Item:
    def __init__(self, path: str):
        self.path = path
        if not os.path.exists(self.path):
            raise Exception(f"{self.path} is invalid path!")
        self.len = os.path.getsize(self.path)

    def write_to_file(self, fb):
        with open(self.path, mode="rb") as f:
            data = f.read()
            fb.write(data)

    def get_len(self):
        return self.len

    def __eq__(self, other):
        if isinstance(other, Item):
            return os.path.samefile(self.path, other.path)
        return False


class LottItem(Item):
    def __init__(self, path: str):
        super().__init__(path)
        lott_tool = get_flat_buffers_tool()
        out_file = self.path + ".bin"
        proc = subprocess.Popen([lott_tool, self.path, out_file],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = proc.communicate()
        if proc.returncode != 0:
            print("lott tool error msg:")
            print(stderr)
            raise Exception(f"parse lott file {self.path} error!")
        print(stdout)
        with open(out_file, "rb") as f:
            self.data = f.read()
            self.len = len(self.data)
        os.remove(out_file)

    def write_to_file(self, fb):
        fb.write(self.data)


class DialFilePack:
    def __init__(self):
        self.table = []

    def add_path(self, path: str):
        """
        store path
        :param path: file path
        :return: index in packer
        """
        item = Item(path)
        for i, it in enumerate(self.table):
            if it == item:
                return i
        self.table.append(item)
        return len(self.table) - 1

    def add_lott(self, path: str):
        """
        store path
        :param path: file path
        :return: index in packer
        """
        item = LottItem(path)
        for i, it in enumerate(self.table):
            if it == item:
                return i
        self.table.append(item)
        return len(self.table) - 1

    def write_to_fb(self, fb):
        for it in self.table:
            if isinstance(it, Item):
                it.write_to_file(fb)
            else:
                raise Exception(f"invalid item was added! {it}")

    def get_offset(self, index: int):
        """
        Obtain the offset position of the specified sequence number file in the final packaged data.
        :param index: sequence number
        :return: offset position
        """
        if index >= len(self.table) or index < 0:
            raise Exception(f"index is out of range {index}")
        offset = 0
        for i in range(index):
            offset += self.table[i].get_len()
        return offset

    def get_size(self, index: int):
        if index >= len(self.table) or index < 0:
            raise Exception(f"index is out of range {index}")
        return self.table[index].get_len()
