#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Rect
from common_types import CommonParser


class DialLabel(Structure):
    _fields_ = [
        ('break_mode', c_ubyte),
        ('align', c_ubyte),
        ('font_size', c_ubyte),
        ('is_periodic', c_bool),
        ('rect', Rect),
        ('color', c_uint),
        ('font_name', c_char * 64),
        ('text', c_char * 64),
        ('bind_data', c_short),
        ('display_mode', c_ubyte),
        ('language', c_ubyte)
    ]

    def __init__(self):
        self.bind_data = 0
        self.text = bytes("", encoding="utf8")
        self.font_name = bytes("", encoding="utf8")
        self.color = 0
        self.font_size = 0
        self.align = 0
        self.break_mode = 0
        self.is_periodic = False
        self.display_mode = 0
        self.language = 255
        self.common_parser = CommonParser()

    def parse_attributes(self, attributes):
        x, y, w, h = attributes["rect"].split(" ")
        self.rect.x = int(x)
        if self.rect.x < np.iinfo(np.int16).min or self.rect.x > np.iinfo(np.int16).max:
            print("[ERR]:label rect x out of range")
            sys.exit(1)
        self.rect.y = int(y)
        if self.rect.y < np.iinfo(np.int16).min or self.rect.y > np.iinfo(np.int16).max:
            print("[ERR]:label rect y out of range")
            sys.exit(1)
        self.rect.w = int(w)
        if self.rect.w < np.iinfo(np.int16).min or self.rect.w > np.iinfo(np.int16).max:
            print("[ERR]:label rect w out of range")
            sys.exit(1)
        self.rect.h = int(h)
        if self.rect.h < np.iinfo(np.int16).min or self.rect.h > np.iinfo(np.int16).max:
            print("[ERR]:label rect h out of range")
            sys.exit(1)

        mode = attributes["break_mode"]
        if mode == "adapt":
            self.break_mode = 0
        elif mode == "stretch":
            self.break_mode = 1
        elif mode == "wrap":
            self.break_mode = 2
        elif mode == "ellipsis":
            self.break_mode = 3
        elif mode == "marquee":
            self.break_mode = 4
        elif mode == "clip":
            self.break_mode = 5
        else:
            self.break_mode = 3
            print("[WARNING][label:break_mode]Incorrect input:", mode)

        align_str = attributes["align"]
        if align_str == "bottom":
            self.align = 4
        elif align_str == "top":
            self.align = 3
        elif align_str == "center":
            self.align = 2
        elif align_str == "right":
            self.align = 1
        elif align_str == "left":
            self.align = 0
        else:
            self.align = 0
            print("[WARNING][label:align]Incorrect input:", align_str)

        self.font_size = int(attributes["font_size"])
        if self.font_size < 0 or self.font_size > np.iinfo(np.uint8).max:
            print("[ERR]:label font size out of range")
            sys.exit(1)

        self.color = int(attributes["color"], 16)
        self.font_name = bytes(attributes["font"], encoding="utf8")
        self.text = bytes(attributes["text"], encoding="utf8")

        for attr in attributes.getNames():
            if attr == "bind_data":
                self.bind_data = int(attributes["bind_data"])
                if self.bind_data < 0 or self.bind_data > np.iinfo(np.int16).max:
                    print("[ERR]:label bind data out of range")
                    sys.exit(1)
            elif attr == 'display_mode':
                self.display_mode = self.common_parser.parse_display_mode(DialLabel.__name__, attributes[attr])
            elif attr == 'is_periodic':
                self.is_periodic = self.common_parser.parse_is_periodic(DialLabel.__name__, attributes[attr])
            elif attr == 'language':
                self.language = self.common_parser.parse_language(DialLabel.__name__, attributes[attr])

        if self.is_periodic != 0 and self.bind_data == 0:
            print("[ERR]:[bind_data] is not set, [period] cannot be set")
            sys.exit(1)

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)

    def calculate_relative_pos(self, x, y):
        self.rect.x = self.rect.x - x
        self.rect.y = self.rect.y - y