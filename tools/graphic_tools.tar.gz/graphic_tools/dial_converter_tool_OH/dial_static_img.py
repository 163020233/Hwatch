#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from ctypes import *

import common_types
from common_types import Point
from common_types import CommonParser
import img_convert


class DialStaticImg(Structure):
    _fields_ = [
        ('pos', Point),
        ('center', Point),
        ('rotate', c_float),
        ('count', c_ubyte),
        ('display_mode', c_ubyte),
        ('language', c_ubyte),
        ('interval_cnt', c_ubyte),
    ]

    def __init__(self):
        self.count = 0
        self.center.x = 0
        self.center.y = 0
        self.rotate = 0.0
        self.display_mode = 0
        self.language = 255
        self.img_id = []
        self.interval_cnt = 0
        self.time_intervals = None
        self.common_parser = CommonParser()

    def parse_attributes(self, attributes):
        input_pos_x, input_pos_y = attributes["position"].split(" ")
        self.pos.x = int(input_pos_x)
        if self.pos.x < np.iinfo(np.int16).min or self.pos.x > np.iinfo(np.int16).max:
            print("[ERR]:static image pos x out of range")
            sys.exit(1)

        self.pos.y = int(input_pos_y)
        if self.pos.y < np.iinfo(np.int16).min or self.pos.y > np.iinfo(np.int16).max:
            print("[ERR]:static image pos y out of range")
            sys.exit(1)

        imgNames = attributes["img_names"].split(",")
        self.count = len(imgNames)
        for img in imgNames:
            img_id = img_convert.instance.convert_img(img)
            self.img_id.append(img_id)

        for attr in attributes.getNames():
            if attr == "center":
                input_center_x, input_center_y = attributes["center"].split(" ")
                self.center.x = int(input_center_x)
                if self.center.x < np.iinfo(np.int16).min or self.center.x > np.iinfo(np.int16).max:
                    print("[ERR]:static image center x out of range")
                    sys.exit(1)

                self.center.y = int(input_center_y)
                if self.center.y < np.iinfo(np.int16).min or self.center.y > np.iinfo(np.int16).max:
                    print("[ERR]:static image center y out of range")
                    sys.exit(1)
            elif attr == "rotate":
                rotate = float(attributes["rotate"])
                if rotate < 0.0 or rotate > 360.0 :
                    print("[ERR]:static image rotate out of range, [0, 360]")
                    sys.exit(1)
                self.rotate = rotate
            elif attr == 'language':
                self.language = self.common_parser.parse_language(DialStaticImg.__name__, attributes[attr])
            elif attr == 'display_mode':
                self.display_mode = self.common_parser.parse_display_mode(DialStaticImg.__name__, attributes[attr])
            elif attr == 'time_intervals':
                self.time_intervals = \
                    self.common_parser.parse_time_intervals(DialStaticImg.__name__, attributes['time_intervals'])
                self.interval_cnt = self.time_intervals.get_cnt()

    def get_bytes(self):
        ret = bytes(self)
        for index in range(self.count):
            ret += struct.pack('@H', self.img_id[index])
        if isinstance(self.time_intervals, common_types.TimeIntervals):
            ret += self.time_intervals.get_bytes()
        return ret

    def get_size(self):
        size = sizeof(self) + sizeof(c_ushort) * self.count
        if isinstance(self.time_intervals, common_types.TimeIntervals):
            size = size + self.time_intervals.get_size()
        return size

    def calculate_relative_pos(self, x, y):
        self.pos.x = self.pos.x - x
        self.pos.y = self.pos.y - y
