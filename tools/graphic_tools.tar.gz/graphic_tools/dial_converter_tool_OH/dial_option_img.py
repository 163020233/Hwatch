#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point
from common_types import CommonParser
import common_types
import img_convert


class DialOptionImg(Structure):
    _fields_ = [
        ('pos', Point),
        ('bind_data', c_short),
        ('is_periodic', c_bool),
        ('count', c_ubyte),
        ('display_mode', c_ubyte),
        ('language', c_ubyte),
        ('interval_cnt', c_ubyte),
    ]

    def __init__(self):
        self.img_id = []
        self.is_periodic = False
        self.display_mode = 0
        self.language = 255
        self.interval_cnt = 0
        self.time_intervals = None
        self.common_parser = CommonParser()

    def parse_attributes(self, attributes):
        input_pos_x, input_pos_y = attributes["position"].split(" ")
        self.pos.x = int(input_pos_x)
        if self.pos.x < np.iinfo(np.int16).min or self.pos.x > np.iinfo(np.int16).max:
            print("[ERR]:option image pos x out of range")
            sys.exit(1)

        self.pos.y = int(input_pos_y)
        if self.pos.y < np.iinfo(np.int16).min or self.pos.y > np.iinfo(np.int16).max:
            print("[ERR]:option image pos y out of range")
            sys.exit(1)

        self.bind_data = int(attributes["bind_data"])
        if self.bind_data < 0 or self.bind_data > np.iinfo(np.int16).max:
            print("[ERR]:option image bind data out of range")
            sys.exit(1)

        img_names = attributes["img_names"].split(",")

        self.count = len(img_names)
        for img in img_names:
            img_id = img_convert.instance.convert_img(img)
            self.img_id.append(img_id)

        if "display_mode" in attributes:
            self.display_mode = self.common_parser.parse_display_mode(DialOptionImg.__name__,
                                                                      attributes['display_mode'])
        if 'is_periodic' in attributes:
            self.is_periodic = self.common_parser.parse_is_periodic(DialOptionImg.__name__, attributes['is_periodic'])
        if 'language' in attributes:
            self.language = self.common_parser.parse_language(DialOptionImg.__name__, attributes['language'])
        if 'time_intervals' in attributes:
            self.time_intervals = \
                self.common_parser.parse_time_intervals(DialOptionImg.__name__, attributes['time_intervals'])
            self.interval_cnt = self.time_intervals.get_cnt()

    def get_bytes(self):
        ret = bytes(self)
        for index in range(self.count):
            ret += struct.pack('@H', self.img_id[index])
        if isinstance(self.time_intervals, common_types.TimeIntervals):
            ret += self.time_intervals.get_bytes()
        return ret

    def get_size(self):
        size = sizeof(self) + sizeof(c_ushort) * self.count
        if isinstance(self.time_intervals, common_types.TimeIntervals):
            size = size + self.time_intervals.get_size()
        return size

    def calculate_relative_pos(self, x, y):
        self.pos.x = self.pos.x - x
        self.pos.y = self.pos.y - y