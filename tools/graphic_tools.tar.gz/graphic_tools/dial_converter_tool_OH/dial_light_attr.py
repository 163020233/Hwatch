#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import numpy as np
from ctypes import *
from common_types import Point


class DialLightAttr(Structure):
    _fields_ = [
        ('spec', c_float),
        ('amp', c_float),
        ('night_spec', c_float),
        ('night_amp', c_float),
        ('fan_range', c_int16),
        ('duration', c_int16),
    ]

    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        self.spec = 1.0
        self.amp = 1.0
        self.night_spec = 1.0
        self.night_amp = 1.0
        self.fan_range = 30
        self.duration = 3000
        self.display_mode = 0

    def parse_attributes(self, attributes):
        option_attr_float = ['spec', 'amp', 'night_spec', 'night_amp', ]
        option_attr_int16 = {
            'fan_range': (0, 90),
            'duration': (0, np.iinfo(np.int16).max),
        }
        for attr in attributes.getNames():
            if attr in option_attr_float:
                val = float(attributes[attr])
                if 0 <= val <= 255.0:
                    setattr(self, attr, val)
                else:
                    print(f"[ERR]:light {attr} : {val} out of range")
                    sys.exit(1)
            elif attr in option_attr_int16.keys():
                val = int(attributes[attr])
                if option_attr_int16[attr][0] <= val <= option_attr_int16[attr][1]:
                    setattr(self, attr, val)
                else:
                    print(f"[ERR]:light {attr} : {val} out of range")
                    sys.exit(1)

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)
