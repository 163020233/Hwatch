#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
from ctypes import *
import img_convert
from dial_file_pack import DialFilePack


class DialEarth(Structure):
    _fields_ = [
        ('texture', c_uint16),
        ('start_longitude', c_float),
        ('offset', c_uint32),
        ('len', c_uint32),
    ]

    def __init__(self, file_packer: DialFilePack, *args, **kw):
        super().__init__(*args, **kw)
        self.texture = 0
        self.start_longitude = 0.0
        self.display_mode = 0
        self.file_packer = file_packer
        self.file_index = 0
        self.offset = 0
        self.len = 0

    def parse_attributes(self, attributes):
        self.texture = img_convert.instance.convert_img(attributes['texture'])
        self.file_index = self.file_packer.add_path(attributes['model'])
        self.len = self.file_packer.get_size(self.file_index)
        self.start_longitude = float(attributes['start_longitude'])
        if not (-180 <= self.start_longitude <= 180):
            print(f"[ERR]:DialEarth start_longitude : {self.start_longitude} out of range")
            sys.exit(1)

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)
