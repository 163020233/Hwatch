#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
from xml.dom.minidom import parse
from ctypes import *
import img_convert
from common_types import CommonParser


class DialKaleidoscope(Structure):
    _fields_ = [
        ('img_id', c_ushort),
        ('rotate_event_factor', c_float),
        ('rotate_animator_value', c_float),
        ('display_mode', c_ubyte),
    ]

    def __init__(self):
        self.img_id = 0
        self.rotate_event_factor = 1.0
        self.rotate_animator_value = 1.0
        self.display_mode = 0
        self.common_parser = CommonParser()

    def parse_attributes(self, attributes):
        self.img_id = img_convert.instance.convert_img(attributes["img_name"])
        for attr in attributes.getNames():
            if attr == "crown_rotate_step":
                self.rotate_event_factor = float(attributes["crown_rotate_step"])
            elif attr == "animator_rotate_step":
                self.rotate_animator_value = float(attributes["animator_rotate_step"])

        if "display_mode" in attributes:
            self.display_mode = \
                self.common_parser.parse_display_mode(DialKaleidoscope.__name__, attributes['display_mode'])

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)
