#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
from ctypes import *
from dial_file_pack import DialFilePack
from common_types import Rect
import numpy as np


class DialLotti(Structure):
    _fields_ = [
        ('rect', Rect),
        ('repeat', c_uint8),
        ('offset', c_uint32),
        ('len', c_uint32)
    ]

    def __init__(self, file_packer: DialFilePack, *args, **kw):
        super().__init__(*args, **kw)
        self.rect.x, self.rect.y, self.rect.w, self.h = 0, 0, 0, 0
        self.repeat = 0
        self.offset = 0
        self.len = 0
        self.display_mode = 0
        self.file_packer = file_packer
        self.file_index = 0

    def parse_attributes(self, attributes):
        x, y, w, h = attributes["rect"].split(" ")
        self.rect.x = int(x)
        if self.rect.x < np.iinfo(np.int16).min or self.rect.x > np.iinfo(np.int16).max:
            print("[ERR]:lotti rect x out of range")
            sys.exit(1)
        self.rect.y = int(y)
        if self.rect.y < np.iinfo(np.int16).min or self.rect.y > np.iinfo(np.int16).max:
            print("[ERR]:lotti rect y out of range")
            sys.exit(1)
        self.rect.w = int(w)
        if self.rect.w < np.iinfo(np.int16).min or self.rect.w > np.iinfo(np.int16).max:
            print("[ERR]:lotti rect w out of range")
            sys.exit(1)
        self.rect.h = int(h)
        if self.rect.h < np.iinfo(np.int16).min or self.rect.h > np.iinfo(np.int16).max:
            print("[ERR]:lotti rect h out of range")
            sys.exit(1)

        lott_path = attributes['src']
        if lott_path.endswith(".json"):
            self.file_index = self.file_packer.add_lott(attributes['src'])
        else:
            self.file_index = self.file_packer.add_path(attributes['src'])
        self.len = self.file_packer.get_size(self.file_index)
        if attributes['repeat'] == 'true':
            self.repeat = 1
        else:
            self.repeat = 0

    def get_size(self):
        return sizeof(self)

    def get_bytes(self):
        return bytes(self)
