#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point
from common_types import CommonParser
import img_convert


class Imgs:
    def __init__(self):
        self.repeat = False
        self.img_id = []

    def parse_attributes(self, attributes):
        if "repeat" in attributes:
            if attributes["repeat"].lower() == "true" :
                self.repeat = True
            elif attributes["repeat"].lower() == "false" :
                self.repeat = False
            else:
                print("[ERR]:sequence image repeat only 'True' or 'False'")
                sys.exit(1)
        names = attributes["names"].split(",")
        for img in names:
            img_id = img_convert.instance.convert_img(img)
            self.img_id.append(img_id)


class DialSequenceImg(Structure):
    _fields_ = [
        ('pos', Point),
        ('interval', c_ushort),
        ('sub_seq_num', c_ubyte),
        ('repeat', c_bool * 3), # max seq
        ('img_num', c_ubyte * 3), # max seq
        ('display_mode', c_ubyte),
    ]

    def __init__(self):
        self.sub_seq_num = 0
        self.display_mode = 0
        self.common_parser = CommonParser()
        self.seq_imgs = []

    def parse_attributes(self, attributes):
        x, y = attributes["position"].split(" ")
        self.pos.x = int(x)
        if self.pos.x < np.iinfo(np.int16).min or self.pos.x > np.iinfo(np.int16).max :
            print("[ERR]:sequence image pos x out of range")
            sys.exit(1)

        self.pos.y = int(y)
        if self.pos.y < np.iinfo(np.int16).min or self.pos.y > np.iinfo(np.int16).max :
            print("[ERR]:sequence image pos y out of range")
            sys.exit(1)

        interval = int(attributes["interval"])
        if interval < 0 or interval > np.iinfo(np.int16).max :
            print("[ERR]: sequence image interval out of range")
            sys.exit(1)
        else:
            self.interval = interval

        if "display_mode" in attributes.getNames():
            self.display_mode = \
                self.common_parser.parse_display_mode(DialSequenceImg.__name__, attributes['display_mode'])

    def get_bytes(self):
        ret = bytes(self)
        for imgs in self.seq_imgs:
            for img_id in imgs.img_id:
                ret += struct.pack('@H', img_id)
        return ret

    def get_size(self):
        size = sizeof(self)
        for i in range(self.sub_seq_num):
            size += sizeof(c_ushort) * self.img_num[i]
        return size

    def calculate_relative_pos(self, x, y):
        self.pos.x = self.pos.x - x
        self.pos.y = self.pos.y - y

    def add_imgs(self, imgs: Imgs):
        if isinstance(imgs, Imgs):
            self.repeat[self.sub_seq_num] = imgs.repeat
            self.img_num[self.sub_seq_num] = len(imgs.img_id)
            self.sub_seq_num = self.sub_seq_num + 1
            self.seq_imgs.append(imgs)
            if self.sub_seq_num > 3:
                print("[ERR]: imgs cannot be greater than 3!")
                sys.exit(1)
