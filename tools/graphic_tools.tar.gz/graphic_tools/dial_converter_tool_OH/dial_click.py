#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Rect
from common_types import CommonParser


class ClickTypeUnion(Union):
    _fields_ = [
        ('slice_id', c_uint),
        ('bundle_name', c_char * 64)
    ]


class DialClick(Structure):
    _fields_ = [
        ('type', c_ubyte),
        ('rect', Rect),
        ('union_type', ClickTypeUnion),
        ('display_mode', c_ubyte),
    ]

    def __init__(self):
        self.display_mode = 0
        self.common_parser = CommonParser()

    def parse_attributes(self, attributes):
        x, y, w, h = attributes["rect"].split(" ")
        self.rect.x = int(x)
        if self.rect.x < np.iinfo(np.int16).min or self.rect.x > np.iinfo(np.int16).max:
            print("[ERR]:click rect x out of range")
            sys.exit(1)
        self.rect.y = int(y)
        if self.rect.y < np.iinfo(np.int16).min or self.rect.y > np.iinfo(np.int16).max:
            print("[ERR]:click rect y out of range")
            sys.exit(1)
        self.rect.w = int(w)
        if self.rect.w < np.iinfo(np.int16).min or self.rect.w > np.iinfo(np.int16).max:
            print("[ERR]:click rect w out of range")
            sys.exit(1)
        self.rect.h = int(h)
        if self.rect.h < np.iinfo(np.int16).min or self.rect.h > np.iinfo(np.int16).max:
            print("[ERR]:click rect h out of range")
            sys.exit(1)

        for attr in attributes.getNames():
            if attr == "action_slice":
                self.union_type.slice_id = int(attributes["action_slice"])
                self.type = 0
                break
            elif attr == "action_bundle":
                self.union_type.bundle_name = bytes(attributes["action_bundle"], encoding="utf8")
                self.type = 1
                break

        if "display_mode" in attributes.getNames():
            self.display_mode = self.common_parser.parse_display_mode(DialClick.__name__, attributes['display_mode'])

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)