#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
from ctypes import *

class DialRipple(Structure):
    _fields_ = [
        ('anim_time', c_int16),
    ]

    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        self.anim_time = 500
        self.display_mode = 0

    def parse_attributes(self, attributes):
        if 'anim_time' in attributes.getNames():
            val = int(attributes['anim_time'])
            if 0 <= val <= 5000:
                self.anim_time = val
            else:
                print(f"[ERR]:DialRipple anim_time : {val}")
                sys.exit(1)

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)