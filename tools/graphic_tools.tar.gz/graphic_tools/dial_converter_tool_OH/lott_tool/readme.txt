单文件处理
./flatbufferstool input.json output_flatbuffer.bin
按路径处理
./flatbufferstool input output

相比上一版的修改为适配了windows，改动了图片压缩库