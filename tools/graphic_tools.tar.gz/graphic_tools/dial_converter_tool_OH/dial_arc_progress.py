#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Rect
from common_types import ColorStop
from common_types import CommonParser
import img_convert


class ProgressUnion(Union):
    _fields_ = [
        ('stop_count', c_ubyte),
        ('img_id', c_ushort),
        ('color', c_uint),
    ]


class DialArcProgress(Structure):
    _fields_ = [
        ('cap', c_ubyte),
        ('is_periodic', c_bool),
        ('radius', c_ushort),
        ('start_angle', c_int16),
        ('end_angle', c_int16),
        ('line_width', c_ushort),
        ('bind_data', c_short),
        ('bg_color', c_uint),
        ('type', c_ubyte),
        ('rect', Rect),
        ('union_value', ProgressUnion),
        ('display_mode', c_ubyte),
    ]

    def __init__(self):
        self.bg_color = 0
        self.type = 0
        self.bind_data = 0
        self.line_width = 0
        self.end_angle = 0
        self.start_angle = 0
        self.radius = 0
        self.cap = 0
        self.stop = []
        self.is_periodic = False
        self.display_mode = 0
        self.common_parser = CommonParser()

    def parse_attributes(self, attributes):
        x, y, w, h = attributes["rect"].split(" ")
        self.rect.x = int(x)
        if self.rect.x < np.iinfo(np.int16).min or self.rect.x > np.iinfo(np.int16).max:
            print("[ERR]:arc progress rect x out of range")
            sys.exit(1)
        self.rect.y = int(y)
        if self.rect.y < np.iinfo(np.int16).min or self.rect.y > np.iinfo(np.int16).max:
            print("[ERR]:arc progress rect y out of range")
            sys.exit(1)
        self.rect.w = int(w)
        if self.rect.w < np.iinfo(np.int16).min or self.rect.w > np.iinfo(np.int16).max:
            print("[ERR]:arc progress rect w out of range")
            sys.exit(1)
        self.rect.h = int(h)
        if self.rect.h < np.iinfo(np.int16).min or self.rect.h > np.iinfo(np.int16).max:
            print("[ERR]:arc progress rect h out of range")
            sys.exit(1)

        cap = attributes["cap_type"]
        if cap == "round":
            self.cap = 1
        else:
            self.cap = 0

        self.radius = int(attributes["radius"])
        if self.radius < 0 or self.radius > np.iinfo(np.int16).max:
            print("[ERR]:arc progress radius out of range")
            sys.exit(1)

        self.start_angle = int(attributes["start_angle"])

        self.end_angle = int(attributes["end_angle"])

        self.line_width = int(attributes["line_width"])
        if self.line_width < 0 or self.line_width > np.iinfo(np.int16).max:
            print("[ERR]:arc progress line_width out of range")
            sys.exit(1)

        self.bind_data = int(attributes["bind_data"])
        if self.bind_data < 0 or self.bind_data > np.iinfo(np.int16).max:
            print("[ERR]:arc progress bind data out of range")
            sys.exit(1)

        attr_list = attributes.getNames()
        for attr in attr_list:
            if attr == "img_name":
                self.union_value.img_id = img_convert.instance.convert_img(attributes["img_name"])
                self.type = 0
                break
            elif attr == "color":
                self.union_value.color = int(attributes["color"], 16)
                self.type = 1
                break
            elif attr == "gradient_colors":
                self.type = 2
                stop_list = attributes["gradient_stops"].split(" ")
                color_list = attributes["gradient_colors"].split(" ")
                if len(stop_list) != len(color_list):
                    print("[ERROR]:[gradient_stops] attr not equal [color_list] attr")
                self.union_value.stop_count = min(len(color_list), len(stop_list))
                for index in range(self.union_value.stop_count):
                    color_stop = ColorStop()
                    color_stop.stop = float(stop_list[index])
                    color_stop.color = int(color_list[index], 16)
                    self.stop.append(color_stop)
                break

        if "display_mode" in attributes.getNames():
            self.display_mode = \
                self.common_parser.parse_display_mode(DialArcProgress.__name__, attributes['display_mode'])
        if "background_color" in attr_list:
            self.bg_color = int(attributes["background_color"], 16)
        if 'is_periodic' in attributes:
            self.is_periodic = self.common_parser.parse_is_periodic(DialArcProgress.__name__, attributes['is_periodic'])

    def get_bytes(self):
        ret = bytes(self)
        if self.type == 2:
            for stop in self.stop:
                ret += bytes(stop)
        return ret

    def get_size(self):
        ret = sizeof(self)
        if self.type == 2:
            for stop in self.stop:
                ret += sizeof(stop)
        return ret

    def calculate_relative_pos(self, x, y):
        self.rect.x = self.rect.x - x
        self.rect.y = self.rect.y - y