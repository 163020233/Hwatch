#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point
from common_types import CommonParser


class DialArcLabel(Structure):
    _fields_ = [
        ('align', c_ubyte),
        ('font_size', c_ubyte),
        ('center', Point),
        ('radius', c_ushort),
        ('rotate_start', c_short),
        ('rotate_end', c_short),
        ('color', c_uint),
        ('font_name', c_char * 64),
        ('text', c_char * 64),
        ('bind_data', c_short),
        ('is_periodic', c_bool),
        ('display_mode', c_ubyte),
        ('letter_space', c_ubyte),
        ('language', c_ubyte)
    ]

    def __init__(self):
        self.bind_data = 0
        self.text = bytes("", encoding="utf8")
        self.font_name = bytes("", encoding="utf8")
        self.color = 0
        self.rotate_end = 0
        self.rotate_start = 0
        self.radius = 0
        self.font_size = 0
        self.align = 0
        self.is_periodic = False
        self.display_mode = 0
        self.letter_space = 0
        self.language = 255
        self.common_parser = CommonParser()

    def parse_attributes(self, attributes):
        align_str = attributes["align"]
        if align_str == "bottom":
            self.align = 4
        elif align_str == "top":
            self.align = 3
        elif align_str == "center":
            self.align = 2
        elif align_str == "right":
            self.align = 1
        elif align_str == "left":
            self.align = 0
        else:
            self.align = 0
            print("[WARNING] arc label align value input error, using default value")

        self.font_size = int(attributes["font_size"])
        if self.font_size < np.iinfo(np.int16).min or self.font_size > np.iinfo(np.int16).max:
            print("[ERR]:label font size out of range")
            sys.exit(1)

        x, y = attributes["center"].split(" ")
        self.center.x = int(x)
        if self.center.x < np.iinfo(np.int16).min or self.center.x > np.iinfo(np.int16).max:
            print("[ERR]:arc label center x out of range")
            sys.exit(1)
        self.center.y = int(y)
        if self.center.y < np.iinfo(np.int16).min or self.center.y > np.iinfo(np.int16).max:
            print("[ERR]:arc label center y out of range")
            sys.exit(1)

        self.radius = int(attributes["radius"])
        if self.radius < 0 or self.radius > np.iinfo(np.int16).max:
            print("[ERR]:arc label radius out of range")
            sys.exit(1)

        self.rotate_start = int(attributes["start_angle"])
        self.rotate_end = int(attributes["end_angle"])

        self.color = int(attributes["color"], 16)
        self.font_name = bytes(attributes["font"], encoding="utf8")
        self.text = bytes(attributes["text"], encoding="utf8")
        for attr in attributes.getNames():
            if attr == "bind_data":
                self.bind_data = int(attributes["bind_data"])
                if self.bind_data < 0 or self.bind_data > np.iinfo(np.int16).max:
                    print("[ERR]:arc label bind data out of range")
                    sys.exit(1)
            elif attr == "display_mode":
                self.display_mode = self.common_parser.parse_display_mode(DialArcLabel.__name__, attributes[attr])
            elif attr == 'letter_space':
                self.letter_space = int(attributes[attr])
                if self.letter_space < 0 or self.letter_space >= 255: # 255: max letter space
                    print("[ERR]:[letter_space] out of range")
                    sys.exit(1)
            elif attr == 'is_periodic':
                self.is_periodic = self.common_parser.parse_is_periodic(DialArcLabel.__name__, attributes[attr])
            elif attr == 'language':
                self.language = self.common_parser.parse_language(DialArcLabel.__name__, attributes[attr])

        if self.is_periodic != 0 and self.bind_data == 0:
            print("[ERR]:[bind_data] is not set, [period] cannot be set")
            sys.exit(1)

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)

    def calculate_relative_pos(self, x, y):
        self.center.x = self.center.x - x
        self.center.y = self.center.y - y