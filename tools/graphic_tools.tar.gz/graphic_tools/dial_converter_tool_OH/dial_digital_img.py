#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point
from common_types import CommonParser
from common_types import TimeIntervals
import img_convert


class DialDigitalImg(Structure):
    _fields_ = [
        ('align_type', c_ubyte, 4),
        ('integer_length', c_ubyte, 4),
        ('decimal_precision', c_ubyte),
        ('img_ids', c_ushort * 10),
        ('sign_img_id', c_ushort),
        ('decimal_point_img_id', c_ushort),
        ('space', c_ushort),
        ('align_position', Point),
        ('bind_data', c_short),
        ('is_periodic', c_bool),
        ('display_mode', c_ubyte),
        ('interval_cnt', c_ubyte),
    ]

    def __init__(self):
        self.decimal_precision = 0
        self.decimal_point_img_id = 0
        self.integer_length = 0
        self.sign_img_id = 0
        self.bind_data = 0
        self.align_type = 0
        self.space = 0
        self.is_periodic = False
        self.display_mode = 0
        self.interval_cnt = 0
        self.time_intervals = None
        self.common_parser = CommonParser()

    def parse_attributes(self, attributes):
        img_names = attributes["img_names"].split(",")
        length = len(img_names)
        if length < 10:
            print("[ERR]:tag:[digital_img] attr[img_names] less than 10!")
            sys.exit(1)
        else:
            for index in range(10):
                self.img_ids[index] = img_convert.instance.convert_img(img_names[index])

        self.space = int(attributes["space"])
        if self.space < 0 or self.space > np.iinfo(np.int16).max:
            print("[ERR]:digital image space out of range")
            sys.exit(1)

        align_str = attributes["align"]
        if align_str == "right":
            self.align_type = 2
        elif align_str == "center":
            self.align_type = 1
        elif align_str == "left":
            self.align_type = 0
        else:
            print("[ERR]:digital image align not support")

        align_pos_x, align_pos_y = attributes["align_pos"].split(" ")
        align_x = int(align_pos_x)
        if align_x < np.iinfo(np.int16).min or align_x > np.iinfo(np.int16).max:
            print("[ERR]:digital image align x out of range")
            sys.exit(1)
        self.align_position.x = align_x

        align_y = int(align_pos_y)
        if align_y < np.iinfo(np.int16).min or align_y > np.iinfo(np.int16).max:
            print("[ERR]:digital image align y out of range")
            sys.exit(1)
        self.align_position.y = align_y

        self.bind_data = int(attributes["bind_data"])
        if self.bind_data < 0 or self.bind_data > np.iinfo(np.int16).max:
            print("[ERR]:digital image bind data out of range")
            sys.exit(1)

        for attr in attributes.getNames():
            if attr == "sign_img_name":
                sign_img_name = attributes["sign_img_name"]
                self.sign_img_id = img_convert.instance.convert_img(sign_img_name)
            elif attr == "integer_length":
                self.integer_length = int(attributes["integer_length"])
                if self.integer_length < 0 or self.integer_length > np.iinfo(np.uint8).max:
                    print("[ERR]:digital image integer length out of range")
                    sys.exit(1)
            elif attr == "img_decimal_point":
                decimal_point_img_name = attributes["img_decimal_point"]
                self.decimal_point_img_id = img_convert.instance.convert_img(decimal_point_img_name)
            elif attr == "decimal_precision":
                self.decimal_precision = int(attributes["decimal_precision"])
                if self.decimal_precision < 0 or self.decimal_precision > np.iinfo(np.uint8).max:
                    print("[ERR]:digital image decimal precision out of range")
                    sys.exit(1)
            elif attr == 'is_periodic':
                self.is_periodic = self.common_parser.parse_is_periodic(DialDigitalImg.__name__, attributes[attr])
            elif attr == 'display_mode':
                self.display_mode = self.common_parser.parse_display_mode(DialDigitalImg.__name__, attributes[attr])
            elif attr == 'time_intervals':
                self.time_intervals = \
                    self.common_parser.parse_time_intervals(DialDigitalImg.__name__, attributes['time_intervals'])
                self.interval_cnt = self.time_intervals.get_cnt()

    def get_bytes(self):
        ret = bytes(self)
        if isinstance(self.time_intervals, TimeIntervals):
            ret += self.time_intervals.get_bytes()
        return ret

    def get_size(self):
        size = sizeof(self)
        if isinstance(self.time_intervals, TimeIntervals):
            size = size + self.time_intervals.get_size()
        return size

    def calculate_relative_pos(self, x, y):
        self.align_position.x = self.align_position.x - x
        self.align_position.y = self.align_position.y - y