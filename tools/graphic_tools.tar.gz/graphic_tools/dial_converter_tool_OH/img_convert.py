#!/usr/bin/python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import base64
from PIL import Image
from io import BytesIO
import cv2
import ctypes
from ctypes import *
from PIL import Image

import os
import sys
import struct
import time
import platform
import numpy as np
import pickle as p
import requests
import matplotlib.pyplot as pyplot

global dll
if platform.system().lower() == 'windows':
    dll = ctypes.CDLL(sys.path[0] + r"\dll\x64\release_cs\ICE_V5R1_BLOCK_HTC.dll")
elif platform.system().lower() == 'linux':
    dll = ctypes.CDLL(sys.path[0] + r"/dll/linux_cs/libcodec.so")


class Header(ctypes.Structure):
    _fields_ = [
        ("width", c_uint),
        ("height", c_uint),
        ("stride", c_uint),
        ("pixel_format", c_uint),
        ("tile_width", c_uint),
        ("mode_alpha", c_uint),
        ("mode_rgb", c_uint)
    ]


class BsData(ctypes.Structure):
    _fields_ = [
        ("bs_data", POINTER(c_ubyte)),
        ("data_size", c_uint),
        ("cmp_ratio", c_uint),
        ("is_valid", c_uint),
        ("subjective_review", c_uint),
        ("para", Header)
    ]


class AutoCmpOutput(ctypes.Structure):
    _fields_ = [
        ("cmp_bs0", POINTER(BsData)),
        ("cmp_bs1", POINTER(BsData)),
        ("cmp_bs2", POINTER(BsData)),
        ("cmp_bs3", POINTER(BsData)),
        ("auto_cmp_mode", c_uint),
        ("valid_bs_num", c_uint)
    ]


class CmpInput(ctypes.Structure):
    _fields_ = [
        ("width", c_uint),
        ("height", c_uint),
        ("stride", c_uint),
        ("pixel_format", c_uint),
        ("tile_width", c_uint),
        ("mode_alpha", c_uint),
        ("mode_rgb", c_uint),
        ("red_channel", POINTER(c_ubyte)),
        ("green_channel", POINTER(c_ubyte)),
        ("blue_channel", POINTER(c_ubyte)),
        ("alpha_channel", POINTER(c_ubyte))
    ]


class AutoCmpInput(ctypes.Structure):
    _fields_ =[
        ("auto_cmp_mode", c_uint),
        ("high_quality_mode", c_uint),
        ("high_cmp_ratio_mode", c_uint),
        ("cmp_in", POINTER(CmpInput))
    ]


class BinHeader(ctypes.Structure):
    _fields_ = [
        ("dir_id", c_uint),
        ("count", c_uint)
    ]


class SeekInfo(ctypes.Structure):
    _fields_ = [
        ("offset", c_uint),
        ("size", c_uint)
    ]


class ImageHeader(ctypes.Structure):
    _fields_ = [
        ("color_mode", c_uint, 8),
        ("version", c_uint, 4),
        ("compress_mode", c_uint, 4),
        ("reserved", c_uint, 16),
        ("width", c_ushort),
        ("height", c_ushort)
    ]


class ImageConverTool:
    binHeader = BinHeader()
    binHeader.dir_id = 0xfef
    seekInfo = []
    imageHeader = []
    imageData = []
    image_num = 0
    isConvertedFile = []
    tile_width_support = {4, 6, 8, 16}

    def __init__(self):
        self.mark_cur_offset = 0
        self.width = 0
        self.height = 0
        self.file_alpha = False
        self.cmp_mode = "HFBC"
        self.color_fmt = ' '
        self.align = 1
        self.tile_width = 6
        self.mode_alpha = 1
        self.mode_rgb = 1
        self.auto_cmp_mode = 0
        self.high_quality_mode = 0
        self.high_cmp_ratio_mode = 0
        self.version = 1

    def set_tile_width(self, tile_width):
        if tile_width not in self.tile_width_support:
            print("[ERR]:The tile_width:{tile_width} value is not supported.")
            sys.exit(1)

        self.tile_width = tile_width

    def convert_img(self, path):
        if path in self.isConvertedFile:
            return self.isConvertedFile.index(path) + 1

        if not self._check_path(path):
            sys.exit(1)

        self.image = Image.open(path)
        if self.image.mode == 'RGBA':
            self.color_fmt = 'ARGB8888'
        elif self.image.mode == 'RGB':
            self.color_fmt = 'RGB888'
        else:
            self.image = self.image.convert('RGBA')
            self.color_fmt = 'ARGB8888'
        self.isConvertedFile.append(path)
        return self._convert()

    def write_data_to_bin(self, fb):
        fb.write(bytes(self.binHeader))
        for seek in self.seekInfo:
            fb.write(bytes(seek))

        for index in range(0, self.image_num):
            bt = bytearray()
            color_fmt = self.imageHeader[index].color_mode
            header = color_fmt + (self.imageHeader[index].width << 32) + \
                    (self.imageHeader[index].height << 48) + (self.imageHeader[index].version << 8)
            header_bin = struct.pack("<Q", header)

            if (self.cmp_mode == "HFBC"):
                header = header + (4 << 12)
            elif (self.cmp_mode == "HFBC_ABYPASS"):
                header = header + (5 << 12)

            header_bin = struct.pack("<Q", header)
            bt += header_bin
            for i in range(self.imageData[index].data_size):
                bt += struct.pack("B", self.imageData[index].bs_data[i])
            fb.writelines([bt])

    def get_size(self):
        ret = sizeof(self.binHeader)
        ret += len(self.seekInfo) * sizeof(SeekInfo)
        for index in range(0, self.image_num):
            bt = bytearray()
            color_fmt = self._get_cmp_px_format()
            header = color_fmt + (self.imageHeader[index].width << 32) + \
                    (self.imageHeader[index].height << 48) + (self.imageHeader[index].version << 8)
            header_bin = struct.pack("<Q", header)

            if (self.cmp_mode == "HFBC"):
                header = header + (4 << 12)
            elif (self.cmp_mode == "HFBC_ABYPASS"):
                header = header + (5 << 12)

            header_bin = struct.pack("<Q", header)
            bt += header_bin
            for i in range(self.imageData[index].data_size):
                bt += struct.pack("B", self.imageData[index].bs_data[i])
            ret += len(bt)
        return ret

    def clear(self):
        self.binHeader.count = 0
        self.seekInfo.clear()
        self.imageHeader.clear()
        self.imageData.clear()
        self.image_num = 0
        self.isConvertedFile.clear()
        self.mark_cur_offset = 0
        self.width = 0
        self.height = 0
        self.file_alpha = False
        self.cmp_mode = "HFBC"
        self.color_fmt = ' '
        self.align = 1
        self.tile_width = 6
        self.mode_alpha = 1
        self.mode_rgb = 1
        self.auto_cmp_mode = 0
        self.high_quality_mode = 0
        self.high_cmp_ratio_mode = 0
        self.version = 1

    def _get_cmp_px_format(self):
        if self.color_fmt == 'RGB565':
            return 2
        elif self.color_fmt == 'RGB888':
            return 0
        elif self.color_fmt == 'ARGB8888':
            return 1

    def _get_color_mode(self):
        if self.color_fmt == 'RGB565':
            return 2
        elif self.color_fmt == 'RGB888':
            return 1
        elif self.color_fmt == 'ARGB8888':
            return 0

    def _get_auto_cmp_input(self, auto_cmp_input, cmp_input):
        auto_cmp_input.auto_cmp_mode = self.auto_cmp_mode
        auto_cmp_input.high_quality_mode = self.high_quality_mode
        auto_cmp_input.high_cmp_ratio_mode = self.high_cmp_ratio_mode
        auto_cmp_input.cmp_in = ctypes.cast(pointer(cmp_input), POINTER(CmpInput))

    def _get_cmp_input(self, cmp_input):
        cmp_input.width = self.width
        cmp_input.height = self.height
        cmp_input.stride = self.width
        cmp_input.tile_width = self.tile_width
        cmp_input.mode_alpha = self.mode_alpha
        cmp_input.mode_rgb = self.mode_rgb
        cmp_input.pixel_format = self._get_cmp_px_format()
        size = self.width * self.height
        red = (c_ubyte * size)()
        green = (c_ubyte * size)()
        blue = (c_ubyte * size)()
        alpha = (c_ubyte * size)()

        for row in range(self.height):
            for col in range(self.width):
                position = row * self.width + col
                red[position] = self.image.getdata()[position][0]
                green[position] = self.image.getdata()[position][1]
                blue[position] = self.image.getdata()[position][2]
                if self.file_alpha == False:
                    alpha[position] = 0xFF
                else:
                    alpha[position] = self.image.getdata()[position][3]
        cmp_input.red_channel = red
        cmp_input.green_channel = green
        cmp_input.blue_channel = blue
        cmp_input.alpha_channel = alpha

    def _convert(self):
        width, height = self.image.size
        self.width = width
        self.height = height
        self.stride_pixel = (self.width + self.align - 1) // self.align * self.align
        if len(self.image.split()) > 3:
            self.file_alpha = True
        else:
            self.file_alpha = False

        # initialize CmpInput
        cmp_input = CmpInput()
        self._get_cmp_input(cmp_input)
        auto_cmp_input = AutoCmpInput()
        self._get_auto_cmp_input(auto_cmp_input, cmp_input)

        # call GetBufferSize to get buffer size
        # initialize CmpOutput
        auto_cmp_output = AutoCmpOutput()

        cmp_bs0 = BsData()
        buf_size0 = dll.ice_v5r1_block_get_buffer_size(byref(cmp_input))  # 压缩后输出数据的大小
        cmp_bs0.bs_data = (c_ubyte * buf_size0)()
        auto_cmp_output.cmp_bs0 = ctypes.cast(pointer(cmp_bs0), POINTER(BsData))
        ret = dll.ice_v5r1_block_htc_auto_cmp(byref(auto_cmp_input), byref(auto_cmp_output))  # 对输入数据进行压缩返回值是函数正常运行标志位

        # add imageinfo to list
        self.binHeader.count += 1

        image_info = ImageHeader()
        image_info.width = self.width
        image_info.height = self.height
        image_info.color_mode = self._get_color_mode()
        image_info.version = 1
        image_info.compress_mode = 4
        image_info.reserved = 0
        seek_info = SeekInfo()
        seek_info.offset = self.mark_cur_offset
        seek_info.size = sizeof(image_info) + cmp_bs0.data_size
        self.mark_cur_offset += seek_info.size
        self.seekInfo.append(seek_info)
        self.imageHeader.append(image_info)
        self.imageData.append(cmp_bs0)
        self.image_num += 1
        return self.image_num

    @staticmethod
    def _check_path(path):
        if not os.path.exists(path):
            print("[ERROR]:", path, "is not exist")
            return False
        else:
            if (not path[-3:].lower() == "png") and (not path[-3:].lower() == "jpg") and\
                    (not path[-3:].lower() == "bmp"):
                print("[ERROR]:", path, "is not jpg or png or bmp format image")
                return False
        return True

instance = ImageConverTool()
