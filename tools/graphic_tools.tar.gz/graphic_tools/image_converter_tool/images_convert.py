#!/usr/bin/env python
# coding: utf-8
# Description: image converter tool

import argparse
import os
import struct
import time
import cv2
import numpy as np
from PIL import Image
from converter import Converter

COLOR_FMT = ('RGB565', 'RGB888', 'ARGB8888')
CMP_MODE = ('NONE', 'HFBC', 'HFBC_ABYPASS')

def get_parameters():
    parser = argparse.ArgumentParser()

    # image dir
    parser.add_argument('--img_dir', type=str, default='D:\\Code\\PythonCode\\projects\\image_converter_tool\\',
                        help='图片所在目录, 例如 D:\\img\\')

    # image name, null means to convert all pictures in the folder
    parser.add_argument('--img_name', type=str, default='', # A094_051.png
                        help='图片名称,为空时表示批量转换文件夹中所有图片,默认为空')

    # color format : RGB565 / RGB888 / ARGB8888
    parser.add_argument('--color_fmt', type=str, default='ARGB8888',
                        choices=['RGB565', 'RGB888', 'ARGB8888'],
                        help='像素格式')

    # whether to compress
    # HFBC only applicable when color format ARGB8888
    parser.add_argument('--cmp_mode', type=str, default='NONE',
                        choices=['NONE', 'HFBC', 'HFBC_ABYPASS'],
                        help='是否压缩数据, NONE:不压缩, HFBC:压缩ARGB, HFBC_ABYPASS:压缩RGB, \
                        HFBC仅适用于color_fmt为ARGB8888的源图片')

    parser.add_argument('--align', type=int, default=16,
                        choices=[16, 32, 64],
                        help='不压缩数据时的对齐长度')

    config = parser.parse_args()
    return config

def print_args(args):
    para = vars(args)
    print('------------ Options -------------')
    for key, val in sorted(para.items()):
        log = '%s = %s ' % (str(key), str(val))
        print(log)
    print('-------------- End ----------------')

def check_cmp(cmp_mode, color_fmt):
    if cmp_mode not in CMP_MODE:
        print("Invalid Args: cmp_mode must be %s" \
              % (" / ".join(CMP_MODE)))
        return False
    if cmp_mode == "HFBC" and color_fmt != 'ARGB8888':
        print("Invalid Args: color_fmt must be ARGB8888 to do HFBC")
        return False
    return True

def check_path(path):
    if (os.path.exists(path) == False):
        print("Invalid Args: image_dir does not exist")
        return False
    return True

def check_color_fmt(color_fmt):
    if color_fmt not in COLOR_FMT:
        print("Invalid Args: color_fmt must be %s" \
              % (" / ".join(COLOR_FMT)))
        return False
    return True

import searchdir
def process_args(opt):
    print("start converter")
    if check_color_fmt(opt.color_fmt) == False \
        or check_cmp(opt.cmp_mode, opt.color_fmt) == False \
        or check_path(opt.img_dir) == False:
        print("Stop Conversion!")
        return
    start = time.time()
    # convert each img file in img_dir
    if opt.img_name == '':
        dirlist = searchdir.BASE(["png", "bmp", "jpg"])
        #dirlist.RecusWalkDir(dir=argv[1])
        dirlist.RecusWalkDir(dir=opt.img_dir)
        for image in dirlist.fileList:
            if (not image.endswith(".png")):
                continue
            img_name = image
            convert(opt, img_name)
    # convert single img file specified by img_name
    else:
        img_name = opt.img_name
        img_path = os.path.join(opt.img_dir, img_name)
        if (not img_name.endswith(".png")):
            print("Invalid Args: src file should be a png file")
            print("Stop Conversion!")
            return
        if (os.path.exists(img_path) == False):
            print("Invalid Args: src file does not exist")
            print("Stop Conversion!")
            return False
        convert(opt, img_name)
    end = time.time()
    print("finish convert, cost", int(end - start), "seconds")

def convert(opt, img_name):
    converter = Converter(img_name, img_name[:len(img_name)-4]+'.bin', opt.color_fmt, opt.cmp_mode, opt.align)
    converter.convert()

if __name__ == "__main__":
    user_input = get_parameters()
    print_args(user_input)
    process_args(user_input)
