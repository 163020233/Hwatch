#!/usr/bin/env python
# coding: utf-8
# Description: image converter tool
import cv2
import ctypes
from ctypes import byref
from ctypes import c_uint
from ctypes import c_ubyte
from ctypes import POINTER
from ctypes import pointer
from PIL import Image
import os
import sys
import struct
import time
import platform
import numpy as np
import pickle as p

class CmpInput(ctypes.Structure):
    _fields_ = [
        ("width", c_uint),
        ("height", c_uint),
        ("stride", c_uint),
        ("pixel_format", c_uint),
        ("tile_width", c_uint),
        ("mode_alpha", c_uint),
        ("mode_rgb", c_uint),
        ("red_channel", POINTER(c_ubyte)),
        ("green_channel", POINTER(c_ubyte)),
        ("blue_channel", POINTER(c_ubyte)),
        ("alpha_channel", POINTER(c_ubyte))
    ]
global dll
if platform.system().lower() == 'windows':
    dll = ctypes.CDLL(sys.path[0] + r"\dll\x64\release_cs\ICE_V5R1_BLOCK_HTC.dll")
elif platform.system().lower() == 'linux':
    dll = ctypes.CDLL(sys.path[0] + r"/dll/linux_cs/BLOCK_HTC.so")


class Header(ctypes.Structure):
    _fields_ = [
        ("width", c_uint),
        ("height", c_uint),
        ("stride", c_uint),
        ("pixel_format", c_uint),
        ("tile_width", c_uint),
        ("mode_alpha", c_uint),
        ("mode_rgb", c_uint)
    ]

class BsData(ctypes.Structure):
    _fields_ = [
        ("bs_data", POINTER(c_ubyte)),
        ("data_size", c_uint),
        ("cmp_ratio", c_uint),
        ("is_valid", c_uint),
        ("subjective_review", c_uint),
        ("para", Header)
    ]

class AutoCmpOutput(ctypes.Structure):
    _fields_ = [
        ("cmp_bs0", POINTER(BsData)),
        ("cmp_bs1", POINTER(BsData)),
        ("cmp_bs2", POINTER(BsData)),
        ("cmp_bs3", POINTER(BsData)),
        ("auto_cmp_mode", c_uint),
        ("high_cmp_ratio_mode", c_uint),
        ("valid_bs_num", c_uint)
    ]



class AutoCmpInput(ctypes.Structure):
    _fields_ =[
        ("auto_cmp_mode", c_uint),
        #("high_quality_mode", c_uint),
        ("high_cmp_ratio_mode", c_uint),
        ("cmp_in", POINTER(CmpInput))
    ]

class RecData(ctypes.Structure):
    _fields_ = [
        ("red_channel", POINTER(c_ubyte)),
        ("green_channel", POINTER(c_ubyte)),
        ("blue_channel", POINTER(c_ubyte)),
        ("alpha_channel", POINTER(c_ubyte)),
        ("cmp_ratio", c_uint),
        ("is_valid", c_uint),
        ("subjective_review", c_uint)
    ]

class AutoDcmpOutput(ctypes.Structure):
    _fields_ =[
        ("rec_out_data0", POINTER(RecData)),
        ("rec_out_data1", POINTER(RecData)),
        ("rec_out_data2", POINTER(RecData)),
        ("rec_out_data3", POINTER(RecData)),
        ("auto_cmp_mode", c_uint),
        ("valid_image_num", c_uint)
    ]

class Converter_C:
    ROTATE_MAGIC = 0xafa
    ROTATE_90 = 1
    ROTATE_180 = 2
    ROTATE_270 = 3
    """
    brief: convert png file into bin file
    """
    def __init__(self, img_dir, out_dir, color_fmt, cmp_mode, align, tile, alpha, rgb, autocmpmode, highqualitymode, highcmpratiomode, ver, rotate=0):
        self.path, self.img_name = os.path.split(img_dir)
        self.outpath, self.out_name = os.path.split(out_dir)

        self.filename = out_dir[:len(out_dir) - 4]
        self.cmp_mode = cmp_mode
        self.auto_cmp_mode = autocmpmode
        self.high_quality_mode = highqualitymode
        self.high_cmp_ratio_mode = highcmpratiomode

        self.im = Image.open(img_dir)
        #print(self.im.mode)
        
        self.img = cv2.imread(img_dir, cv2.IMREAD_UNCHANGED) #返回长宽分辨率元素组
        self.rotate = rotate
        self._rotate_if_necessary()
        #print(len(self.img.shape))
        
        if self.im.mode != 'L':
            if self.img.shape[2] > 3:
                self.file_alpha = True
            else:
                self.file_alpha = False
        
        if color_fmt != ' ':
            self.color_fmt = color_fmt
        else:
            if self.im.mode == 'L':
                self.color_fmt = 'A8'
                print("L:", self.color_fmt)
            elif self.im.mode == 'RGBA':
                self.color_fmt = 'ARGB8888'
                print("RGBA:", self.color_fmt)
            elif self.im.mode == 'RGB':
                self.color_fmt = 'RGB888'
                print("RGB:", self.color_fmt)
            elif self.file_alpha == True:
                self.color_fmt = 'ARGB8888'
                print("self.file_alpha == True:", self.color_fmt)
            else:
                self.color_fmt = 'RGB888'
                print("self.color_fmt = ", self.color_fmt)
        self.im.close()
        if (self.cmp_mode != "NONE") and (self.cmp_mode != "HFBC") and \
        (self.cmp_mode != "HFBC_ABYPASS") and (self.cmp_mode != "HFBC_A8") :
            print("error: unsupported compress mode:", self.cmp_mode)
            exit(1)
        if (self.color_fmt != "RGB565") and (self.color_fmt != "RGB888") and \
        (self.color_fmt != "ARGB8888") and (self.color_fmt != "A8"):
            print("error: unsupported image format:", self.color_fmt)
            exit(1)
        self.height = self.img.shape[0]
        self.width = self.img.shape[1]
        self.tile_width = tile #4
        self.mode_alpha = alpha
        self.mode_rgb = rgb #1
        self.align = align

        self.stride_pixel = (self.width +
                       self.align - 1) // self.align * self.align
        self.version = ver

    def _rotate_if_necessary(self):
        if self.rotate == self.ROTATE_90:
            self.img = cv2.rotate(self.img, cv2.ROTATE_90_CLOCKWISE)
        elif self.rotate == self.ROTATE_180:
            self.img = cv2.rotate(self.img, cv2.ROTATE_180)
        elif self.rotate == self.ROTATE_270:
            self.img = cv2.rotate(self.img, cv2.ROTATE_90_COUNTERCLOCKWISE)

    def _get_output_shape(self):
        if self.rotate == self.ROTATE_90 or self.rotate == self.ROTATE_270:
            return self.height, self.width
        return self.width, self.height

    def convert(self):
        if self.cmp_mode == "NONE":
            self.__get_uncmp_bin() #本步骤则需要将其转换为config.xml配置的像素格式，并保证字节对齐
        elif self.color_fmt == 'A8':
            self.__get_uncmp_abin() #本步骤则需要将其转换为config.xml配置的像素格式，并保证字节对齐
        else :
            self.__get_cmp_bin()

    def __get_cmp_px_format(self):
        if self.color_fmt == 'RGB565':
            return 2
        elif self.color_fmt == 'RGB888':
            return 0
        elif self.color_fmt == 'ARGB8888':
            return 1

    def __get_auto_cmp_input(self, auto_cmp_input, cmp_input):
        auto_cmp_input.auto_cmp_mode = self.auto_cmp_mode
        auto_cmp_input.high_quality_mode = self.high_quality_mode
        auto_cmp_input.high_cmp_ratio_mode = self.high_cmp_ratio_mode
        auto_cmp_input.cmp_in = ctypes.cast(pointer(cmp_input), POINTER(CmpInput))

    def __get_cmp_input(self, cmp_input):
        cmp_input.width = self.width

        cmp_input.height = self.height

        cmp_input.stride = self.width

        cmp_input.tile_width = self.tile_width

        cmp_input.mode_alpha = self.mode_alpha

        cmp_input.mode_rgb = self.mode_rgb
        cmp_input.pixel_format = self.__get_cmp_px_format()

        size = self.width * self.height
        red = (c_ubyte * size)()
        green = (c_ubyte * size)()
        blue = (c_ubyte * size)()
        alpha = (c_ubyte * size)()
        if self.color_fmt == "RGB565":
            for row in range(0, self.height):
                for col in range(0, self.width):
                    position = row * self.width + col
                    red[position] = ((self.img[row, col, 2] >> 3)) & 0x1f
                    green[position] = ((self.img[row, col, 1] >> 2)) & 0x3f
                    blue[position] = ((self.img[row, col, 0] >> 3)) & 0x1f
                    if self.file_alpha == False:
                        alpha[position] = 0xFF
                    else:
                        alpha[position] = self.img[row, col, 3]
        else:
            for row in range(0, self.height):
                for col in range(0, self.width):
                    position = row * self.width + col
                    red[position] = self.img[row, col, 2]
                    green[position] = self.img[row, col, 1]
                    blue[position] = self.img[row, col, 0]
                    if self.file_alpha == False:
                        alpha[position] = 0xFF
                    else:
                        alpha[position] = self.img[row, col, 3]
        cmp_input.red_channel = red
        cmp_input.green_channel = green
        cmp_input.blue_channel = blue
        cmp_input.alpha_channel = alpha

    def __image_compress(self):
        # initialize CmpInput
        para = Header()
        cmp_input = CmpInput()
        type(cmp_input)
        self.__get_cmp_input(cmp_input)
        auto_cmp_input = AutoCmpInput()
        self.__get_auto_cmp_input(auto_cmp_input, cmp_input)

        # call GetBufferSize to get buffer size
        matrix = [4, 6, 8, 16]
        # initialize CmpOutput
        auto_cmp_output = AutoCmpOutput()

        cmp_bs0 = BsData()
        cmp_bs1 = BsData()
        cmp_bs2 = BsData()
        cmp_bs3 = BsData()
        if auto_cmp_input.auto_cmp_mode == 1:
            cmp_input.tile_width = matrix[0]
            buf_size0 = dll.ice_v5r1_block_get_buffer_size(byref(cmp_input))  # 压缩后输出数据的大小
            cmp_input.tile_width = matrix[1]
            buf_size1 = dll.ice_v5r1_block_get_buffer_size(byref(cmp_input))  # 压缩后输出数据的大小
            cmp_input.tile_width = matrix[2]
            buf_size2 = dll.ice_v5r1_block_get_buffer_size(byref(cmp_input))  # 压缩后输出数据的大小
            cmp_input.tile_width = matrix[3]
            buf_size3 = dll.ice_v5r1_block_get_buffer_size(byref(cmp_input))  # 压缩后输出数据的大小

            cmp_bs0.bs_data = (c_ubyte * buf_size0)()
            cmp_bs1.bs_data = (c_ubyte * buf_size1)()
            cmp_bs2.bs_data = (c_ubyte * buf_size2)()
            cmp_bs3.bs_data = (c_ubyte * buf_size3)()

            auto_cmp_output.cmp_bs0 = ctypes.cast(pointer(cmp_bs0), POINTER(BsData))
            auto_cmp_output.cmp_bs1 = ctypes.cast(pointer(cmp_bs1), POINTER(BsData))
            auto_cmp_output.cmp_bs2 = ctypes.cast(pointer(cmp_bs2), POINTER(BsData))
            auto_cmp_output.cmp_bs3 = ctypes.cast(pointer(cmp_bs3), POINTER(BsData))

            ret = dll.ice_v5r1_block_htc_auto_cmp(byref(auto_cmp_input), byref(auto_cmp_output))  # 对输入数据进行压缩返回值是函数正常运行标志位

            if auto_cmp_output.valid_bs_num == 1:
                self.__mk_output_dir()
                self.__make_file_bin_0(cmp_bs0)
            elif auto_cmp_output.valid_bs_num == 2:
                self.__mk_output_file_dir()
                outputbin = os.path.join(self.filename, '1_' + self.out_name)
                self.__make_file_bin_1(auto_cmp_output.cmp_bs0, outputbin)
                outputbin = os.path.join(self.filename, '2_' + self.out_name)
                self.__make_file_bin_1(auto_cmp_output.cmp_bs1, outputbin)
            elif auto_cmp_output.valid_bs_num == 3:
                self.__mk_output_file_dir()
                outputbin = os.path.join(self.filename, '1_' + self.out_name)
                self.__make_file_bin_1(auto_cmp_output.cmp_bs0, outputbin)

                outputbin = os.path.join(self.filename, '2_' + self.out_name)
                self.__make_file_bin_1(auto_cmp_output.cmp_bs1, outputbin)

                outputbin = os.path.join(self.filename, '3_' + self.out_name)
                self.__make_file_bin_1(auto_cmp_output.cmp_bs2, outputbin)
            elif auto_cmp_output.valid_bs_num == 4:
                self.__mk_output_file_dir()
                outputbin = os.path.join(self.filename, '1_' + self.out_name)
                self.__make_file_bin_1(cmp_bs0, outputbin)

                outputbin = os.path.join(self.filename, '2_' + self.out_name)
                self.__make_file_bin_1(cmp_bs1, outputbin)

                outputbin = os.path.join(self.filename, '3_' + self.out_name)
                self.__make_file_bin_1(cmp_bs2, outputbin)

                outputbin = os.path.join(self.filename, '4_' + self.out_name)
                self.__make_file_bin_1(cmp_bs3, outputbin)

        else:
            buf_size0 = dll.ice_v5r1_block_get_buffer_size(byref(cmp_input))  # 压缩后输出数据的大小

            cmp_bs0.bs_data = (c_ubyte * buf_size0)()
            cmp_bs1.bs_data = (c_ubyte * buf_size0)()
            cmp_bs2.bs_data = (c_ubyte * buf_size0)()
            cmp_bs3.bs_data = (c_ubyte * buf_size0)()

            auto_cmp_output.cmp_bs0 = ctypes.cast(pointer(cmp_bs0), POINTER(BsData))
            auto_cmp_output.cmp_bs1 = ctypes.cast(pointer(cmp_bs1), POINTER(BsData))
            auto_cmp_output.cmp_bs2 = ctypes.cast(pointer(cmp_bs2), POINTER(BsData))
            auto_cmp_output.cmp_bs3 = ctypes.cast(pointer(cmp_bs3), POINTER(BsData))
            ret = dll.ice_v5r1_block_htc_auto_cmp(byref(auto_cmp_input), byref(auto_cmp_output))  # 对输入数据进行压缩返回值是函数正常运行标志位
            self.__mk_output_dir()
            self.__make_file_bin_0(cmp_bs0)

    def __make_file_bin_0(self, cmp_bs):
        out_img_name = os.path.join(self.outpath, self.out_name)
        self.__mk_output_dir()
        handle = open(out_img_name, 'wb')
        self.bytes = bytearray()

        color_fmt = self.__get_color_mode()
        if color_fmt == -1:
            print("unsupport color mode, stop Conversion!!")
            return
        w, h = self._get_output_shape()
        header = color_fmt + (w << 32) + \
                 (h << 48) + (self.version << 8) + ((self.ROTATE_MAGIC + self.rotate) << 16)
        header_bin = struct.pack("<Q", header)

        if (self.cmp_mode == "HFBC"):
            header = header + (4 << 12)
        elif (self.cmp_mode == "HFBC_ABYPASS"):
            header = header + (5 << 12)

        header_bin = struct.pack("<Q", header)
        self.bytes += header_bin
        for i in range(cmp_bs.data_size):
            self.bytes += struct.pack("B", cmp_bs.bs_data[i])

        handle.writelines([self.bytes])
        handle.close()

    def __make_file_bin_1(self, cmp_bs, outputbin):
        out_img_name = outputbin
        self.__mk_output_dir()
        handle = open(out_img_name, 'wb')
        self.bytes = bytearray()

        color_fmt = self.__get_color_mode()
        if color_fmt == -1:
            print("unsupport color mode, stop Conversion!!")
            return
        w, h = self._get_output_shape()
        header = color_fmt + (w << 32) + \
                 (h << 48) + (self.version << 8) + ((self.ROTATE_MAGIC + self.rotate) << 16)
        header_bin = struct.pack("<Q", header)
        if (self.cmp_mode == "HFBC"):
            header = header + (4 << 12)
        elif (self.cmp_mode == "HFBC_ABYPASS"):
            header = header + (5 << 12)

        header_bin = struct.pack("<Q", header)
        self.bytes += header_bin
        for i in range(cmp_bs.data_size):
            self.bytes += struct.pack("B", cmp_bs.bs_data[i])
        handle.writelines([self.bytes])
        handle.close()
    def __deal_arrar(self, rec_out_data, output):
        if rec_out_data.is_valid == 1: # 码流是否有效
            if self.color_fmt == 'ARGB8888':
                im = np.empty((self.width, self.height, 4), dtype="uint8")
                for row in range(0, self.height):
                    for col in range(0, self.width):
                        position = row * self.width + col
                        im[row][col][0] = rec_out_data.red_channel[position]
                        im[row][col][1] = rec_out_data.green_channel[position]
                        im[row][col][2] = rec_out_data.blue_channel[position]
                        im[row][col][3] = rec_out_data.alpha_channel[position]
                Image.fromarray(im).save(output)
            elif self.color_fmt == 'RGB888':
                im = np.empty((self.width, self.height, 3), dtype="uint8")
                for row in range(0, self.height):
                    for col in range(0, self.width):
                        position = row * self.width + col
                        im[row][col][0] = rec_out_data.red_channel[position]
                        im[row][col][1] = rec_out_data.green_channel[position]
                        im[row][col][2] = rec_out_data.blue_channel[position]
                Image.fromarray(im).save(output)
            elif self.color_fmt == 'RGB565':
                im = np.empty((self.width, self.height, 3), dtype="uint8")
                for row in range(0, self.height):
                    for col in range(0, self.width):
                        position = row * self.width + col
                        im[row][col][0] = rec_out_data.red_channel[position] << 3
                        im[row][col][1] = rec_out_data.green_channel[position] << 2
                        im[row][col][2] = rec_out_data.blue_channel[position] << 3
                self.__mk_output_dir()
                Image.fromarray(im).save(output)
            print("---------------Decompression complete----------------")
        else:
            print("Invalid stream data")

    def __get_color_mode(self):
        if self.color_fmt == 'RGB565':
            return 2
        elif self.color_fmt == 'RGB888':
            return 1
        elif self.color_fmt == 'ARGB8888':
            return 0
        elif self.color_fmt == 'A8':
            return 14

    # acquires whether the path exists, if not, create one
    def __mk_output_dir(self):
        path = self.outpath.strip().rstrip("\\")
        if not os.path.exists(path):
            os.makedirs(path)
        else:
            return False
    def __mk_output_file_dir(self):
        path = self.filename.strip().rstrip("\\")
        if not os.path.exists(path):
            os.makedirs(path)
        else:
            return False

    def __get_cmp_bin(self):
        print("begin to pack cmp bin")
        # convert to compress one
        self.__image_compress() #对裸数据开始压缩
        print("Conversion Success!")

    def __save_px_rgb565(self):
        for row in range(0, self.height):
            for col in range(0, self.width):
                c16 = ((self.img[row, col, 2] & 0xF8) << 8) | \
                ((self.img[row, col, 1] & 0xFC) << 3) | \
                ((self.img[row, col, 0] & 0xF8) >> 3)
                self.bytes += struct.pack('B', np.uint8(c16 & 0xFF))
                self.bytes += struct.pack('B', np.uint8((c16 >> 8) & 0xFF))
            for col in range(self.width, self.stride_pixel):
                self.bytes += struct.pack('H', 0)

    def __save_px_rgb888(self):
        for row in range(0, self.height):
            for col in range(0, self.width):
                self.bytes += struct.pack('B', self.img[row, col, 0])
                self.bytes += struct.pack('B', self.img[row, col, 1])
                self.bytes += struct.pack('B', self.img[row, col, 2])
            for col in range(self.width, self.stride_pixel):
                self.bytes += struct.pack('H', 0)
                self.bytes += struct.pack('B', 0)

    def __save_px_argb8888_with_alpha(self):
        for row in range(0, self.height):
            for col in range(0, self.width):
                self.bytes += struct.pack('B', self.img[row, col, 0])
                self.bytes += struct.pack('B', self.img[row, col, 1])
                self.bytes += struct.pack('B', self.img[row, col, 2])
                self.bytes += struct.pack('B', self.img[row, col, 3])
            for col in range(self.width, self.stride_pixel):
                self.bytes += struct.pack('I', 0)

    def __save_px_argb8888_without_alpha(self):
        for row in range(0, self.height):
            for col in range(0, self.width):
                self.bytes += struct.pack('B', self.img[row, col, 0])
                self.bytes += struct.pack('B', self.img[row, col, 1])
                self.bytes += struct.pack('B', self.img[row, col, 2])
                self.bytes += struct.pack('B', 0xFF)
            for col in range(self.width, self.stride_pixel):
                self.bytes += struct.pack('I', 0)
    def __save_px_a8(self):
        for row in range(0, self.height):
            for col in range(0, self.width):
                self.bytes += struct.pack('B', self.img[row, col])
            for col in range(self.width, self.stride_pixel):
                self.bytes += struct.pack('B', 0)
    def __save_px_argb8888_a8(self):
        for row in range(0, self.height):
            for col in range(0, self.width):
                self.bytes += struct.pack('B', self.img[row, col, 0])
            for col in range(self.width, self.stride_pixel):
                self.bytes += struct.pack('B', 0)
    def __get_uncmp_abin(self):
        print("begin to pack uncmp abin")
        self.bytes = bytearray()
        if len(self.img.shape) == 3:
            self.__save_px_argb8888_a8()
        elif len(self.img.shape) == 2:
            self.__save_px_a8()

        color_fmt = self.__get_color_mode()
        if color_fmt == -1:
            print("unsupport color mode stop Conversion!")
            return
        header = color_fmt + (self.width << 32) + \
            (self.height << 48) + (self.version << 8) #文件头版本号
        header_bin = struct.pack("<Q", header)

        name = os.path.join(self.outpath, self.out_name)
        self.__mk_output_dir()
        file = open(name, "wb")
        file.write(header_bin)
        file.writelines([self.bytes])
        file.flush()
        file.close()
        print("Conversion Success!")
    def __get_uncmp_bin(self):
        print("begin to pack uncmp bin")
        self.bytes = bytearray()
        if self.color_fmt == 'RGB565':
            self.__save_px_rgb565()
        elif self.color_fmt == 'RGB888' :
            self.__save_px_rgb888()
        elif self.color_fmt == 'ARGB8888':
            if self.file_alpha == True :
                self.__save_px_argb8888_with_alpha()
            else :
                self.__save_px_argb8888_without_alpha()

        color_fmt = self.__get_color_mode()
        if color_fmt == -1:
            print("unsupport color mode stop Conversion!")
            return
        w, h = self._get_output_shape()
        header = color_fmt + (w << 32) + \
            (h << 48) + (self.version << 8) + ((self.ROTATE_MAGIC + self.rotate) << 16) #文件头版本号
        header_bin = struct.pack("<Q", header)

        name = os.path.join(self.outpath, self.out_name)
        self.__mk_output_dir()
        file = open(name, "wb")
        file.write(header_bin)
        file.writelines([self.bytes])
        file.flush()
        file.close()
        print("Conversion Success!")