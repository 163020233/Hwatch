#!/usr/bin/env python
# coding: utf-8
# Description: image converter tool

import ctypes
from ctypes import byref
from ctypes import c_uint
from ctypes import c_ubyte
from ctypes import POINTER
from ctypes import pointer
from PIL import Image
import os
import sys
import struct
import time
import platform
import cv2
import numpy as np

global dll
if platform.system().lower() == 'windows':
    dll = ctypes.CDLL(sys.path[0] + r".\dll\x64\release_cs\ICE_V5R1_BLOCK_HTC.dll")
elif platform.system().lower() == 'linux':
    dll = ctypes.CDLL(sys.path[0] + r"/dll/linux_cs/BLOCK_HTC.so")



class Header(ctypes.Structure):
    _fields_ = [
        ("width", c_uint),
        ("height", c_uint),
        ("stride", c_uint),
        ("pixel_format", c_uint),
        ("tile_width", c_uint),
        ("mode_alpha", c_uint),
        ("mode_rgb", c_uint)
    ]

class BsData(ctypes.Structure):
    _fields_ = [
        ("bs_data", POINTER(c_ubyte)),
        ("data_size", c_uint),
        ("cmp_ratio", c_uint),
        ("is_valid", c_uint),
        ("subjective_review", c_uint),
        ("para", Header)
    ]

class AutoCmpOutput(ctypes.Structure):
    _fields_ = [
        ("cmp_bs0", POINTER(BsData)),
        ("cmp_bs1", POINTER(BsData)),
        ("cmp_bs2", POINTER(BsData)),
        ("cmp_bs3", POINTER(BsData)),
        ("auto_cmp_mode", c_uint),
        ("valid_bs_num", c_uint)
    ]

class CmpHeader(ctypes.Structure):
    _fields_ = [
        ("version", c_uint),
        ("alpha_bypass", c_uint),
        ("width", c_uint),
        ("height", c_uint),
        ("stride", c_uint),
        ("pixel_format", c_uint),
        ("tile_size", c_uint),
        ("alpha_value", c_uint),
        ("mode", c_uint),
        ("tile_width", c_uint)
    ]

class CmpOutput(ctypes.Structure):
    _fields_ = [
        ("data_size", c_uint),
        ("data", POINTER(c_ubyte))
    ]

class CmpInput(ctypes.Structure):
    _fields_ = [
        ("width", c_uint),
        ("height", c_uint),
        ("stride", c_uint),
        ("pixel_format", c_uint),
        ("alpha_bypass", c_uint),
        ("red_channel", POINTER(c_ubyte)),
        ("green_channel", POINTER(c_ubyte)),
        ("blue_channel", POINTER(c_ubyte)),
        ("alpha_channel", POINTER(c_ubyte))
    ]

class DcmpOutput(ctypes.Structure):
    _fields_ = [
        ("width", c_uint),
        ("height", c_uint),
        ("stride", c_uint),
        ("pixel_format", c_uint),
        ("red_channel", POINTER(c_ubyte)),
        ("green_channel", POINTER(c_ubyte)),
        ("blue_channel", POINTER(c_ubyte)),
        ("alpha_channel", POINTER(c_ubyte))
    ]

class RecData(ctypes.Structure):
    _fields_ = [
        ("red_channel", POINTER(c_ubyte)),
        ("green_channel", POINTER(c_ubyte)),
        ("blue_channel", POINTER(c_ubyte)),
        ("alpha_channel", POINTER(c_ubyte)),
        ("cmp_ratio", c_uint),
        ("is_valid", c_uint),
        ("subjective_review", c_uint)
    ]

class AutoDcmpOutput(ctypes.Structure):
    _fields_ =[
        ("rec_out_data0", POINTER(RecData)),
        ("rec_out_data1", POINTER(RecData)),
        ("rec_out_data2", POINTER(RecData)),
        ("rec_out_data3", POINTER(RecData)),
        ("auto_cmp_mode", c_uint),
        ("valid_image_num", c_uint)
    ]

class Converterdcmp:
    """
    brief: convert png file into bin file
    """
    def __init__(self, in_dir, output_dir, isdir):
        self.path, self.name = os.path.split(output_dir)
        self.outpath = output_dir
        self.img_dir = in_dir
        if isdir == 'file':
            self.isdir = False
        else:
            self.isdir = True

    def convert(self):
        if self.isdir == False:
            self.get_header_info()
        else:
            self.get_header_info2()

    def get_header_info(self):
        with open(self.img_dir, 'rb') as f:
            f.seek(8, 0)
            a = f.read()
        cmp_heade = CmpHeader()
        ret = dll.uapi_vau_parse_cmp_header(a, 128, byref(cmp_heade))
        self.pixel_format = cmp_heade.pixel_format
        self.width = cmp_heade.width
        self.height = cmp_heade.height
        self.stride = cmp_heade.stride
        self.pixel_format = cmp_heade.pixel_format
        m = ctypes.cast(a, POINTER(c_ubyte))
        filesize = os.path.getsize(self.img_dir) - 8
        buffersize = self.width * self.height
        auto_cmp_output = AutoCmpOutput()
        cmp_bs0 = BsData()
        cmp_bs0.para.width = cmp_heade.width
        cmp_bs0.para.height = cmp_heade.height
        cmp_bs0.para.stride = cmp_heade.stride
        cmp_bs0.bs_data = (c_ubyte * buffersize)()
        cmp_bs0.bs_data = m
        cmp_bs0.data_size = filesize

        auto_cmp_output.cmp_bs0 = ctypes.cast(pointer(cmp_bs0), POINTER(BsData))
        auto_dcmp_out = AutoDcmpOutput()
        rec_out_data0 = RecData()
        rec_out_data0.red_channel = (c_ubyte * buffersize)()
        rec_out_data0.green_channel = (c_ubyte * buffersize)()
        rec_out_data0.blue_channel = (c_ubyte * buffersize)()
        rec_out_data0.alpha_channel = (c_ubyte * buffersize)()
        auto_dcmp_out.rec_out_data0 = ctypes.cast(pointer(rec_out_data0), POINTER(RecData))
        ret = dll.ice_v5r1_block_htc_auto_dcmp(byref(auto_cmp_output), byref(auto_dcmp_out))
        self.__deal_array(rec_out_data0)
        print("Decmpress Success")
        
    def get_header_info2(self):
        with open(self.img_dir, 'rb') as f:
            dirid = f.read(4)
            count = int.from_bytes(f.read(4), "little")
            offsetarray = []
            sizearrary = []
            for i in range(0, count):
                offset=int.from_bytes(f.read(4), "little")
                size=int.from_bytes(f.read(4), "little")
                offsetarray.append(offset)
                sizearrary.append(size)
            offsetstart = 8+count*8
                
            for i in range(0, count):
                f.seek(offsetstart+offsetarray[i] + 8)
                a=f.read(sizearrary[i] - 8)
                cmp_heade = CmpHeader()
                ret = dll.uapi_vau_parse_cmp_header(a, 128, byref(cmp_heade))
                self.pixel_format = cmp_heade.pixel_format
                print("++++++++++++++++++++++++")
                print("cmp_heade.version", cmp_heade.version)
                print("cmp_heade.alpha_bypass", cmp_heade.alpha_bypass)
                print("cmp_heade.width", cmp_heade.width)
                print("cmp_heade.height", cmp_heade.height)
                print("cmp_heade.stride", cmp_heade.stride)
                print("cmp_heade.pixel_format", cmp_heade.pixel_format)
                print("cmp_heade.tile_size", cmp_heade.tile_size)
                print("cmp_heade.alpha_value", cmp_heade.alpha_value)
                print("cmp_heade.mode", cmp_heade.mode)
                print("cmp_heade.tile_width", cmp_heade.tile_width)
                self.width = cmp_heade.width
                self.height = cmp_heade.height
                self.stride = cmp_heade.stride
                self.pixel_format = cmp_heade.pixel_format
                m = ctypes.cast(a, POINTER(c_ubyte))
                filesize = sizearrary[i] - 8
                buffersize = self.width * self.height
                auto_cmp_output = AutoCmpOutput()
                cmp_bs0 = BsData()
                cmp_bs0.para.width = cmp_heade.width
                cmp_bs0.para.height = cmp_heade.height
                cmp_bs0.para.stride = cmp_heade.stride
                cmp_bs0.bs_data = (c_ubyte * buffersize)()
                cmp_bs0.bs_data = m
                cmp_bs0.data_size = filesize

                auto_cmp_output.cmp_bs0 = ctypes.cast(pointer(cmp_bs0), POINTER(BsData))
                auto_dcmp_out = AutoDcmpOutput()
                rec_out_data0 = RecData()
                rec_out_data0.red_channel = (c_ubyte * buffersize)()
                rec_out_data0.green_channel = (c_ubyte * buffersize)()
                rec_out_data0.blue_channel = (c_ubyte * buffersize)()
                rec_out_data0.alpha_channel = (c_ubyte * buffersize)()
                auto_dcmp_out.rec_out_data0 = ctypes.cast(pointer(rec_out_data0), POINTER(RecData))
                ret = dll.ice_v5r1_block_htc_auto_dcmp(byref(auto_cmp_output), byref(auto_dcmp_out))
                self.__deal_array(rec_out_data0,str(i))
                print("Decmpress Success")
                

    def __deal_array(self, rec_out_data0, index=''):
        if self.pixel_format == 0:
            im = np.empty((self.height, self.width, 4), dtype="uint8")
            for row in range(0, self.height):
                for col in range(0, self.width):
                    position = row * self.width + col
                    im[row][col][0] = rec_out_data0.red_channel[position]
                    im[row][col][1] = rec_out_data0.green_channel[position]
                    im[row][col][2] = rec_out_data0.blue_channel[position]
                    im[row][col][3] = rec_out_data0.alpha_channel[position]

            self.__mk_output_dir()
            output = os.path.join(self.path, os.path.splitext(self.name)[0]+index+os.path.splitext(self.name)[1])
            Image.fromarray(im).save(output)
            
        elif self.pixel_format == 5:
            im = np.empty((self.height, self.width,  3), dtype="uint8")
            for row in range(0, self.height):
                for col in range(0, self.width):
                    position = row * self.width + col
                    im[row][col][0] = rec_out_data0.red_channel[position]
                    im[row][col][1] = rec_out_data0.green_channel[position]
                    im[row][col][2] = rec_out_data0.blue_channel[position]
            self.__mk_output_dir()
            output = os.path.join(self.path, os.path.splitext(self.name)[0]+index+os.path.splitext(self.name)[1])
            Image.fromarray(im).save(output)

        elif self.pixel_format == 8:
            im = np.empty((self.height,self.width,  3), dtype="uint8")
            for row in range(0, self.height):
                for col in range(0, self.width):
                    position = row * self.width + col
                    im[row][col][0] = rec_out_data0.red_channel[position] << 3
                    im[row][col][1] = rec_out_data0.green_channel[position] << 2
                    im[row][col][2] = rec_out_data0.blue_channel[position] << 3
                    Image.fromarray(im)
            self.__mk_output_dir()
            output = os.path.join(self.path, os.path.splitext(self.name)[0]+index+os.path.splitext(self.name)[1])
            Image.fromarray(im).save(output)

    def __mk_output_dir(self):
        path = self.path
        if not os.path.exists(path):
            os.makedirs(path)
        else:
            return False


