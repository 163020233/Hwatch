#/usr/bin/env python
# coding: utf-8
# Description: image converter tool
import argparse
import os
import shutil
import struct
import time
import xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
from converter_C import Converter_C
from converterdcmp import Converterdcmp
import searchdir
import cv2
import hashlib
import json
version = '0'
def make_sure_dir_exit(filename):
    if not os.path.exists(os.path.dirname(filename)):
        os.makedirs(os.path.dirname(filename))


def get_parameters():
    parser = argparse.ArgumentParser()

    parser.add_argument('-p', type=str, default='file',\
        choices=['dir', 'file'], help='像素格式')

    parser.add_argument('-d', type=str, default='cmp', \
                        choices=['cmp', 'dcmp'], help='像素格式')

    parser.add_argument('-c', type=str, default='./config.xml', help='配置文件路径')

    parser.add_argument('-i', type=str, default='./test', help='图片所在文件夹路径')

    parser.add_argument('-o', type=str, default='./output', help='输出文件路径')

    parser.add_argument('-t', type=str, default='./include', help='输出头文件路径')

    parser.add_argument('-e', type=str, default='./output', help='解压文件路径')

    parser.add_argument('-f', type=str, default='./output', help='解压文件输出路径')
    
    parser.add_argument('-cache', type=str, default='./output_cache', help='压缩文件缓存路径')

    parser.add_argument('-rotate', type=str, default='0', help='buffer预旋转角度，0：0，1：90，2：180，3：270')

    config = parser.parse_args()
    return config

g_config = {}
g_file_config = {}
g_file_output = {}
g_file_output2 = {}
dir_id = 1
g_image_resource = []

def parse_child(root, dir_name):
    global dir_id
    for child in root:
        parse_child(child, os.path.join(dir_name, child.get('name')))
    compress = root.get('compress')
    pixel_format = root.get('format')
    align = root.get('align')
    tile_width = root.get('tile')
    model_alpha = root.get('alpha')
    model_rgb = root.get('rgb')
    auto_cmp_mode = root.get('autocmpmode')
    high_quality_mode = root.get('highqualitymode')
    high_cmp_ratio_mode = root.get('highcmpratiomode')
    dir_id_str = root.get('dirid')
    if dir_id_str != None:
        if "0x" in dir_id_str: 
            dir_id = int(dir_id_str, 16)
        else:
            dir_id = int(dir_id_str, 10)

    global version
    version = root.get('ver')
    align_num = 16
    pixel = ' '
    if pixel_format != None:
        pixel = pixel_format
    if align != None :
        if compress != "NONE" :
            print("error align for xml tag", root.tag, root.attrib)
        else :
            align_num = int(align)
            if (align_num <= 0) or (isinstance(align_num, int) != True):
                print("error align value", align, ", reset to be 16")
                align_num = 16
    if version == '1':
        if compress != "NONE":
            g_config[dir_name] = [compress, pixel, align_num, tile_width, model_alpha, model_rgb,
                                  auto_cmp_mode, high_quality_mode, high_cmp_ratio_mode, version]
        else:
            g_config[dir_name] = [compress, pixel, align_num, 4, 1, 1, 0, 0, 0, version]
    else:
        g_config[dir_name] = [compress, pixel, align_num, auto_cmp_mode, high_quality_mode, high_cmp_ratio_mode,
                              version]

def parse_xml(opt):
    tree = ET.parse(opt.c).getroot()
    parse_child(tree, opt.i)

def load_hash_dict(cache_dir):
    """从文件加载哈希字典"""
    hash_file = os.path.join(cache_dir, 'hash_dict.json')
    if os.path.exists(hash_file):
        with open(hash_file, 'r') as f:
            return json.load(f)
    return {}

def save_hash_dict(hash_dict, cache_dir):
    """
    保存哈希字典到指定目录的JSON文件，自动处理目录和文件的创建
    
    参数:
    hash_dict (dict): 需要保存的哈希值字典
    cache_dir (str): 存储目录路径
    """
    # 构建完整文件路径
    hash_file_path = os.path.join(cache_dir, 'hash_dict.json')
    
    # 自动创建目录（递归处理多级目录）
    os.makedirs(cache_dir, exist_ok=True)
    
    # 使用原子写入方式避免写入中断导致的数据损坏
    with open(hash_file_path, 'w', encoding='utf-8') as file:
        json.dump(hash_dict, file, ensure_ascii=False, indent=4)

def calculate_file_hash(image_path, xml_base_dir):
    """
    计算图片和对应XML文件的组合哈希值
    
    参数:
    image_path (str): 图片文件路径
    xml_base_dir (str): XML文件基础目录（opt.c）
    
    返回:
    str: 组合哈希值
    """
    # 创建哈希对象
    hash_md5 = hashlib.md5()
    
    # 计算图片文件的哈希
    with open(image_path, 'rb') as f:
        hash_md5.update(f.read())
    with open(xml_base_dir, 'rb') as f:
        hash_md5.update(f.read())
    return hash_md5.hexdigest()

def do_conver(opt):
    hash_dict = load_hash_dict(opt.cache)
    dirlist = searchdir.BASE(["png", "bmp", "jpg", "PNG", "BMP", "JPG"])
    dirlist.RecusWalkDir(dir=opt.i)
    if len(dirlist.fileList) == 0:
        print(f"No valid png/bmp/jpg/PNG/BMP/JPG file in this dir ", opt.i)
        
    for image in dirlist.fileList:
        file_hash = calculate_file_hash(image, opt.c)
        img = cv2.imread(image, cv2.IMREAD_UNCHANGED) #返回长宽分辨率元素组
        height = img.shape[0]
        width = img.shape[1]
        if height > 800 or width > 1280 and (int(opt.rotate) == 0 or int(opt.rotate) == 2):
            print(image,f" exceeds the maximum pixel size of 1280x800 when rotate is {int(opt.rotate)}")
            continue
        if (height > 1280 or width > 800) and (int(opt.rotate) == 1 or int(opt.rotate) == 3):
            print(image, f" exceeds the maximum pixel size of 800x1280 when rotate is {int(opt.rotate)}")
            continue
        cachepath = opt.cache
        img_name = g_file_output.get(image)
        img_name = img_name.replace(os.path.abspath(opt.o), os.path.abspath(cachepath))
        make_sure_dir_exit(img_name)
        make_sure_dir_exit(g_file_output.get(image))
        if file_hash in hash_dict:
            print(f"Use cache result ", hash_dict[file_hash], f" for ", g_file_output.get(image))
            shutil.copyfile(hash_dict[file_hash], g_file_output.get(image))
        else:
            converter = Converter_C(image, g_file_output.get(image), g_file_config.get(image)[1], \
                                    g_file_config.get(image)[0], int(g_file_config.get(image)[2]), \
                                    int(g_file_config.get(image)[3]), int(g_file_config.get(image)[4]), \
                                    int(g_file_config.get(image)[5]), int(g_file_config.get(image)[6]), \
                                    int(g_file_config.get(image)[7]), int(g_file_config.get(image)[8]), \
                                    int(g_file_config.get(image)[9]), rotate=int(opt.rotate))
            converter.convert()
            # 在添加新映射前，删除其他值为 img_name 的映射
            keys_to_delete = []
            for existing_hash, existing_img_name in hash_dict.items():
                if existing_img_name == img_name:
                    keys_to_delete.append(existing_hash)
                    
            # 删除找到的键
            for key in keys_to_delete:
                del hash_dict[key]
            hash_dict[file_hash] = img_name
            shutil.copyfile(g_file_output.get(image), img_name)
        if opt.o == opt.i:
            os.remove(image)
        save_hash_dict(hash_dict, opt.cache)

def do_dcmp_conver(opt):
    dirlist = searchdir.BASE(["bin", "bs"])
    dirlist.RecusWalkDir(dir=opt.e)
    if len(dirlist.fileList) == 0:
        print(f"No valid bin file in this dir ", opt.e)
    for image in dirlist.fileList:
        converter = Converterdcmp(image, g_file_output.get(image), opt.p)
        converter.convert()

def print_args(args):
    para = vars(args)
    for key, val in sorted(para.items()):
        log = '%s = %s ' % (str(key), str(val))

def get_file_outputpath(img_name, opt):
    source = img_name
    img_name = img_name.replace(os.path.abspath(opt.i), os.path.abspath(opt.o))
    g_file_output[source] = img_name[:len(img_name)-4]+'.bin'
    img_name = source
    img_name = img_name.replace(os.path.abspath(
        opt.i), os.path.abspath(opt.o) + '_2')
    g_file_output2[source] = img_name[:len(img_name)-4]+'.bin'
    pass

def get_file_outputpngpath(img_name, opt):
    source = img_name
    img_name = img_name.replace(os.path.abspath(opt.e), os.path.abspath(opt.f))
    g_file_output[source] = img_name[:len(img_name) - 4] + '.png'
    img_name = source
    img_name = img_name.replace(os.path.abspath(
        opt.i), os.path.abspath(opt.o) + '_2')
    g_file_output2[source] = img_name[:len(img_name) - 4] + '.png'
    pass

def get_file_config(img_name, source):
    if img_name == "":
        return
    if img_name in g_config:
        g_file_config[source] = g_config.get(img_name)
    else:
        get_file_config(os.path.dirname(img_name), source)

def get_each_file_config(opt):
    dirlist = searchdir.BASE(["png", "bmp", "jpg", "PNG", "BMP", "JPG"])
    dirlist.RecusWalkDir(dir=opt.i)
    for image in dirlist.fileList:
        if (not image.endswith(".png") and not image.endswith(".jpg") and \
            not image.endswith(".bmp") and not image.endswith(".PNG") and \
            not image.endswith(".BMP") and not image.endswith(".JPG")):
            continue
        img_name = image
        get_file_config(img_name, img_name)
        get_file_outputpath(img_name, opt)


def get_each_dcmpfile_config(opt):
    dirlist = searchdir.BASE(["bin", "bs"])
    dirlist.RecusWalkDir(dir=opt.e)
    for image in dirlist.fileList:
        if (not image.endswith(".bin") and not image.endswith(".bs")):
            continue
        img_name = image
        get_file_outputpngpath(img_name, opt)

def packet_img(dir_name, output_name):
    global dir_id
    count = 0
    file_info = []
    offset = 0
    for s in sorted(os.listdir(dir_name)):
        new_dir = os.path.join(dir_name, s)
        if os.path.isfile(new_dir) and new_dir.endswith(".bin"):
            count += 1
            with open(new_dir, 'rb') as f:
                file_info.append([offset, os.path.getsize(new_dir), f.read()])
            offset += os.path.getsize(new_dir)
            os.remove(new_dir)
            g_image_resource.append(
                [os.path.split(dir_name + '_' + s)[1], dir_id, count])
    if file_info != []:
        with open(output_name, 'wb+') as f:
            bin_header = struct.pack("II", dir_id, count)
            dir_id += 1
            f.write(bin_header)
            for item in file_info:
                seek_info = struct.pack("II", item[0], item[1])
                f.write(seek_info)
            for item in file_info:
                f.write(item[2])
            f.flush()

    for s in os.listdir(dir_name):
        new_dir = os.path.join(dir_name, s)
        if os.path.isdir(new_dir):
            packet_img(new_dir, os.path.join(new_dir, s + '.bin'))


def creat_image_resource_cpp(opt):
    global g_image_resource
    result = '''#ifndef UI_RESOURCE_IMAGE_H
#define UI_RESOURCE_IMAGE_H
#include <cstdint>
namespace OHOS {
    '''
    result += 'enum UIResourceImage : uint32_t {\r\n'
    result += '    static const int DIR_MASK=0xfff00000; \r\n'
    result += '    static const int PNG_MASK=0x000fffff;\r\n'
    for item in g_image_resource:
        result += '    static const int ' + \
            item[0][:len(item[0]) - 4].upper() + ' = ' + \
            hex((item[1] << 20) + item[2]) + ';\r\n'
    result += '}\r\n'
    result += '''} // OHOS
#endif // UI_RESOURCE_IMAGE_H
'''
    make_sure_dir_exit(os.path.join(opt.t, 'ui_resource_image.h'))
    with open(os.path.join(opt.t, 'ui_resource_image.h'), 'wb+') as f:
        f.write(bytes(result, 'utf-8'))
        f.flush()

def process_args(opt):
    if opt.d == 'cmp':
        parse_xml(opt)
        get_each_file_config(opt)
        make_sure_dir_exit(opt.o)
        if os.path.exists(opt.o):
            if opt.o != opt.i:
                shutil.rmtree(opt.o)
        do_conver(opt)
        make_sure_dir_exit(opt.o)
        if opt.p == 'dir':
            packet_img(opt.o, os.path.join(opt.o, 'output.bin'))
            creat_image_resource_cpp(opt)
    else:
        make_sure_dir_exit(opt.f)
        if os.path.exists(opt.f):
            if opt.f != opt.e:
                shutil.rmtree(opt.f)
        make_sure_dir_exit(opt.e)
        if not os.path.exists(opt.e):
            os.makedirs(opt.e)
        if not os.path.exists(opt.f):
            os.makedirs(opt.f)
        get_each_dcmpfile_config(opt)
        do_dcmp_conver(opt)


if __name__ == "__main__":
    user_input = get_parameters()
    user_input.i = os.path.join(user_input.i, '')
    user_input.i = os.path.abspath(user_input.i)
    user_input.o = os.path.abspath(user_input.o)
    user_input.t = os.path.abspath(user_input.t)
    user_input.e = os.path.abspath(user_input.e)
    user_input.f = os.path.abspath(user_input.f)
    user_input.cache = os.path.abspath(user_input.cache)
    process_args(user_input)
