#!/usr/bin/env python
# coding: utf-8
# Description: image converter tool
import os

class BASE:
    fileList = []
    counter = 0
    Const_Song_Format = []

    def __init__(self, Format):
        self.__class__.fileList = []
        self.__class__.counter = 0
        self.__class__.Const_Song_Format = Format

    def RecusWalkDir(self, dir, filtrate=0):
        for s in os.listdir(dir):
            newDir = os.path.join(dir, s)
            if os.path.isdir(newDir):
                self.RecusWalkDir(newDir)
            else:
                if os.path.isfile(newDir):

                    if newDir and (self.GetFileFormat(newDir) in self.__class__.Const_Song_Format):
                        self.__class__.fileList.append(newDir)
                        self.__class__.counter += 1

    def CycWalkDir(self, dir, filtrate=0):
        fileList = []
        for s in os.listdir(dir):
            newDir = os.path.join(dir, s)
            if os.path.isfile(newDir):
                if filtrate:
                    if newDir and (self.GetFileFormat(newDir) in self.__class__.Const_Song_Format):
                        fileList.append(newDir)
                else:
                    fileList.append(newDir)
            else:
                newDir = os.path.join(dir, s)
            while os.path.isdir(newDir):
                for s in os.listdir(dir):
                    newDir = os.path.join(dir, s)
                    if os.path.isfile(newDir):
                        if filtrate:
                            if newDir and (self.GetFileFormat(newDir) in Const_Song_Format):
                                fileList.append(newDir)
                        else:
                            fileList.append(newDir)
                    else:
                        newDir = os.path.join(dir, s)
        return fileList

    def GetFileFormat(self, fileName):
        if fileName:
            BaseName = os.path.basename(fileName)
            str = BaseName.split(".")

            return str[-1]
        else:
            return fileName
