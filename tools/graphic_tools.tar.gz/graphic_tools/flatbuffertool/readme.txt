单文件处理
./flatbufferstool input.json output_flatbuffer.bin
按路径处理
./flatbufferstool input output