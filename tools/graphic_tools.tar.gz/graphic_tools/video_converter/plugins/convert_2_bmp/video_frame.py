#/usr/bin/env python
# coding: utf-8
# Description: vedie get first frame function
# Author: Hisi GUI Team
import os
import numpy as np
import cv2
from PIL import Image
import ctypes
from ctypes import CDLL,cdll
import platform
import ffmpeg
import ctypes
import os
import logging

# 获取当前脚本所在的目录
global lib
script_dir = os.path.dirname(__file__)
print(script_dir)
if platform.system().lower() == 'windows':
    lib = cdll.LoadLibrary(script_dir + r"/ext_lib/windows/libmp42yuv.dll")
elif platform.system().lower() == 'linux':
    dll_path = script_dir + "/ext_lib/linux/libjpeg.so"
    CDLL(dll_path, mode=ctypes.RTLD_GLOBAL)
    lib = cdll.LoadLibrary(script_dir + r"/ext_lib/linux/libsample_dec_yuv.so")

LIMIT_TABLE = [0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
    17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
    33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
    49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
    65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96,
    97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112,
    113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128,
    129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144,
    145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160,
    161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176,
    177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192,
    193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208,
    209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224,
    225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240,
    241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
    17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
    33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
    49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
    65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96,
    97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112,
    113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127]

class VideoFrame():
    def __init__(self, output_path):
        self.out_path = output_path

    def run(self, width, height, file_path):
        self.input_path = file_path
        self.input_file = os.path.basename(file_path)[:-4].lower()
        self.width = width
        self.height = height

        if self.input_path[-3:].lower() == "mp4":
            # 宽高为0,0以视频实际帧宽高
            # 宽高与视频帧宽高不匹配时，对视频进行缩放
            probe = ffmpeg.probe(file_path)
            video_stream = next((stream for stream in probe['streams'] if stream['codec_type'] == 'video'), None)
            frame_w = video_stream.get('width', 0)
            frame_h = video_stream.get('height', 0)
            codec_name = video_stream.get('codec_name', '').lower()
            codec_long_name = video_stream.get('codec_long_name', '').lower()
            logging.info("当前视频编解：%s", codec_long_name)
            logging.info("当前视频帧分辨率：%d %d", frame_w, frame_h)
            if (codec_name != "mjpeg"):
                ValueError(file_path, '当前视频流不是mjpeg编码格式，提取失败')
                return
            if ((width == 0) or (height == 0)) or ((width == frame_w) and (height == frame_h)):
                self.width = frame_w
                self.height = frame_h
            # elif (width < frame_w) and (height < frame_h):
            #     logging.warning(file_path, '当前设置宽高与帧宽高不一致，缩放视频')
            #     self.__scale_video(width, height)
            #     self.width = width
            #     self.height = height
            else:
                ValueError(file_path, '当前设置宽高大于帧宽高，提取失败')
                return
            self.mp4_path = file_path
            self._extract_frame()
            self._convert_yuv_420_to_rgb()
            self._convert_rgb_to_bmp()
        elif self.input_path[-3:].lower() == "rgb":
            self.rgb_path = self.file_path
            self._convert_rgb_to_bmp()
        elif self.input_path[-3:].lower() == "yuv":
            self.yuv_path = self.file_path
            self._convert_yuv_420_to_rgb()
            self._convert_rgb_to_bmp()
        else:
            ValueError(self.input_path, "is not supported")

    def _extract_frame(self):
        self.yuv_path = os.path.join(self.out_path, self.input_file + ".yuv")
        lib.get_yuv_from_mp4.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        lib.get_yuv_from_mp4.restype = ctypes.c_int
        lib.get_yuv_from_mp4(self.input_path.encode('utf-8'), self.yuv_path.encode('utf-8'))
        jpg_name = self.input_file + ".jpg"
        if os.path.exists(jpg_name):
            os.remove(jpg_name)

    def __yuv_to_rgb(self, row, col, y, cr, cb):
        r = int((((((y << 2) - 64) * 1024) + (((cr << 2) - 512) * 1576)) >> 10) >> 2)
        g = int((((((y << 2) - 64) * 1024) - (((cb << 2) - 512) * 187) - (((cr << 2) - 512) * 470)) >> 10) >> 2)
        b = int((((((y << 2) - 64) * 1024) + (((cb << 2) - 512) * 1859)) >> 10) >> 2)

        self.img[row, col, 0] = LIMIT_TABLE[b + 256]
        self.img[row, col, 1] = LIMIT_TABLE[g + 256]
        self.img[row, col, 2] = LIMIT_TABLE[r + 256]

    def _convert_yuv_420_to_rgb(self):
        with open(self.yuv_path, 'rb') as fp:
            data = fp.read()

        self.img = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        u_start_pos = self.width * self.height
        v_start_pos = self.width * self.height * 5 / 4
        for i in range(0, self.height) :
            for j in range(0, self.width) :
                y = data[i * self.width + j]
                cb = data[int(u_start_pos + int(i / 2) * int(self.width / 2) + int(j / 2))]
                cr = data[int(v_start_pos + int(i / 2) * int(self.width / 2) + int(j / 2))]
                self.__yuv_to_rgb(i, j, y, cr, cb)
        self.rgb_path = os.path.join(self.out_path, self.input_file + ".rgb")
        with open(self.rgb_path, 'wb') as f:
            f.write(self.img.tobytes())

    def _convert_rgb_to_bmp(self):
        with open(self.rgb_path, 'rb') as f:
            binary_data = f.read()
        data = np.frombuffer(binary_data, dtype=np.uint8)
        img = data.reshape(self.height, self.width, 3)
        out_bmp_path = os.path.join(self.out_path, self.input_file + ".bmp")
        cv2.imwrite(out_bmp_path, img)

    def __scale_video(self, width, height):
        file_name = os.path.basename(self.input_path)
        new_file = f"{os.path.splitext(file_name)[0]}_sacle{os.path.splitext(file_name)[1]}"
        new_path = os.path.join(self.out_path, new_file)
        stream = ffmpeg.input(self.input_path)
        stream = ffmpeg.filter(stream, 'crop', width, height)
        stream = ffmpeg.output(stream, new_path, vcodec='mjpeg', video_bitrate='4228k')
        if platform.system().lower() == 'windows':
            stream = ffmpeg.run(stream)
        elif platform.system().lower() == 'linux':
            stream = ffmpeg.run(stream, cmd='/usr/bin/ffmpeg')
        self.input_file = new_file[:-4].lower()
