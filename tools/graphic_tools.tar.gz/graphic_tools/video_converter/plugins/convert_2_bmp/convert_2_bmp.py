#/usr/bin/env python
# coding: utf-8
# Description: vedie convert to bmp main
# Author: Hisi GUI Team
import sys
import os
import argparse
import sys
from video_frame import VideoFrame

def GetParameters():
    parser = argparse.ArgumentParser()
    parser.add_argument('-file', '-f', type=str, required=True,
                        help='The input file path, support .rgb, .yuv, .mp4')
    parser.add_argument('-size', '-s', type=str, required=True,
                        help='The frame size, such as 466x466')
    parser.add_argument('-out', '-o', type=str, default=os.getcwd() + "/out", required=False,
                        help='output dir')
    config = parser.parse_args()
    return config

if __name__ == "__main__":
    user_input = GetParameters()
    out_path = user_input.out
    file_path = user_input.file
    parts = user_input.size.split("x")
    if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
        width = int(parts[0])
        height = int(parts[1])
    else:
        print(user_input.s, "is not illegal")
        sys.exit(1)
    if not os.path.exists(out_path):
        os.mkdir(out_path)

    obj = VideoFrame(out_path)
    obj.run(width, height, file_path)