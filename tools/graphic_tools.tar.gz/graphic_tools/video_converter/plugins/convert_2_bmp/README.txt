usage: python convert_2_bmp.py [-h] -f FILE -s ?x? [-o OUT]

optional arguments:
  -h, --help           show this help message and exit
  -file FILE, -f FILE  The input file path, support .rgb, .yuv, .mp4
  -size ?x?, -s ?x?  The frame size, such as 466x466
  -out OUT, -o OUT     output dir

example:
windows: python .\convert_2_bmp.py -f .\test.mp4 -s 466x466 -o .\output
linux: python ./convert_2_bmp.py -f ./test.mp4 -s 466x466 -o ./output

注意事项：
1、请使用python 3.7及以上版本。
2、工具脚本在指定目录生成一个.bmp文件。请使用该文件作为视频浏览帧。
3、调整视频大小。可借助ffmpeg工具。 例："ffmpeg -i video.mp4 -vf crop=454:454 -b:v 4228k -vcodec mjpeg out.mp4"