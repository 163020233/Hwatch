#/usr/bin/env python
# coding: utf-8
# Description: video processor function
# Author: Hisi GUI Team
import ffmpeg
import os
import platform
import logging

class VideoProcessor:
    def __init__(self, video_file):
        self.video_file = video_file

    def check_video_file(self):
    # 检测视频文件格式
        probe = ffmpeg.probe(self.video_file)
        video_stream = next((stream for stream in probe['streams'] if stream['codec_type'] == 'video'), None)
        if not video_stream:
            logging.error(self.video_file, "未找到视频流")
            return False

        # 检查B帧数量
        if video_stream.get('b_frames', 0) != 0:
            logging.warning(self.video_file, "视频使用了B帧,不符合条件")
            return False

        # 检查参考帧数量
        if not (1 <= video_stream.get('refs', 0) <= 2):
            logging.warning(self.video_file, "参考帧数量不为2, 不符合条件")
            return False

        # 检查视频编码器
        if video_stream.get('codec_name', '') != 'h264':
            logging.warning(self.video_file, "视频编码器不是H.264, 不符合条件")
            return False
        return True

    def updata_video_file(self, output_file, refsNum):
        if os.path.exists(output_file):
            os.remove(output_file)
        stream = ffmpeg.input(self.video_file)
        stream = ffmpeg.output(
            stream,
            output_file,
            vcodec='libx264',
            bf=0,               # 设置B帧数量为0
            refs=refsNum,
            x264opts='qp=65'    # 设置x264编码选项
        )
        if platform.system().lower() == 'windows':
            stream = ffmpeg.run(stream)
        elif platform.system().lower() == 'linux':
            stream = ffmpeg.run(stream, cmd='/usr/bin/ffmpeg')