#/usr/bin/env python
# coding: utf-8
# Description: video converter rotate function
# Author: Hisi GUI Team
import ffmpeg
import platform
import os

class VideoRotator:
    def __init__(self, rotate_degree, output_path):
        self.rotate_degree = rotate_degree
        self.output_path = output_path

    def __rotate_video_90_clockwise(self, input_file, output_file, temp_path):
        stream = ffmpeg.input(input_file)
        stream = ffmpeg.filter(stream, 'transpose', 1)
        stream = ffmpeg.output(stream, temp_path, bf=0)
        if platform.system().lower() == 'windows':
            ffmpeg.run(stream)
        elif platform.system().lower() == 'linux':
            ffmpeg.run(stream, cmd='/usr/bin/ffmpeg')

        stream = ffmpeg.input(temp_path)
        stream = ffmpeg.output(stream,
            output_file,
            c='copy',
            **{'metadata:s:v:0': 'rotate=270'}
        )
        if platform.system().lower() == 'windows':
            stream = ffmpeg.run(stream)
        elif platform.system().lower() == 'linux':
            stream = ffmpeg.run(stream, cmd='/usr/bin/ffmpeg')

    def __rotate_video_180_clockwise(self, input_file, output_file, temp_path):
        stream = ffmpeg.input(input_file)
        stream = ffmpeg.filter(stream, 'transpose', 1)
        stream = ffmpeg.filter(stream, 'transpose', 1)
        stream = ffmpeg.output(stream, temp_path, bf=0)
        if platform.system().lower() == 'windows':
            stream = ffmpeg.run(stream)
        elif platform.system().lower() == 'linux':
            stream = ffmpeg.run(stream, cmd='/usr/bin/ffmpeg')

        stream = ffmpeg.input(temp_path)
        stream = ffmpeg.output(stream,
            output_file,
            c='copy',
            **{'metadata:s:v:0': 'rotate=-180'}
        )
        if platform.system().lower() == 'windows':
            stream = ffmpeg.run(stream)
        elif platform.system().lower() == 'linux':
            stream = ffmpeg.run(stream, cmd='/usr/bin/ffmpeg')

    def __rotate_video_270_clockwise(self, input_file, output_file, temp_path):
        stream = ffmpeg.input(input_file)
        stream = ffmpeg.filter(stream, 'transpose', 2)
        stream = ffmpeg.output(stream, temp_path, bf=0)
        if platform.system().lower() == 'windows':
            stream = ffmpeg.run(stream)
        elif platform.system().lower() == 'linux':
            stream = ffmpeg.run(stream, cmd='/usr/bin/ffmpeg')

        stream = ffmpeg.input(temp_path)
        stream = ffmpeg.output(stream,
            output_file,
            c='copy',
            **{'metadata:s:v:0': 'rotate=90'}
        )
        if platform.system().lower() == 'windows':
            stream = ffmpeg.run(stream)
        elif platform.system().lower() == 'linux':
            stream = ffmpeg.run(stream, cmd='/usr/bin/ffmpeg')

    def __checke_file_exists(self, file):
        if os.path.exists(file):
            os.remove(file)

    def run(self, input_file):
        file_name = os.path.basename(input_file)
        new_file_name = f"{os.path.splitext(file_name)[0]}_{self.rotate_degree}{os.path.splitext(file_name)[1]}"
        output_file = os.path.join(self.output_path, new_file_name)
        self.__checke_file_exists(output_file)

        temp_file_name = f"{os.path.splitext(file_name)[0]}_temp{os.path.splitext(file_name)[1]}"
        temp_path = os.path.join(self.output_path, temp_file_name)
        print(input_file)
        if self.rotate_degree == 90:
            self.__rotate_video_90_clockwise(input_file, output_file, temp_path)
        elif self.rotate_degree == 180:
            self.__rotate_video_180_clockwise(input_file, output_file, temp_path)
        if self.rotate_degree == 270:
            self.__rotate_video_270_clockwise(input_file, output_file, temp_path)

        # 删除中间产物
        self.__checke_file_exists(temp_path)
