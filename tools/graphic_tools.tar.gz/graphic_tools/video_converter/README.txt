usage: main.py [-h] [-o OUTPUT] (--frame | --rotate) [-s SIZE] [-a {0,1,2,3}] [-r {1,2}] input_path

options:
  -h, --help            show this help message and exit
  --frame               获取视频首帧
  --rotate              顺时针方向旋转视频

公共参数:
  input_path            输入文件路径
  -o OUTPUT, --output OUTPUT
                        输出文件路径

取帧参数:
  仅在使用--frame时有效

  -s SIZE, --size SIZE  提取帧宽*高 (格式: WxH)

旋转参数:
  仅在使用--rotate时有效

  -a {0,1,2,3}, --angle {0,1,2,3}
                        旋转角度, 入参为90为倍数。90:1, 180:2, 270:3
  -r {1,2}, --refs {1,2}
                        参考帧数量

例：
windows：
python main.py --rotate -a 1 --refs 2 .\input -o .\output