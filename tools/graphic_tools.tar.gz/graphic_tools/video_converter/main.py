#/usr/bin/env python
# coding: utf-8
# Description: video converter main
# Author: Hisi GUI Team
import argparse
import os
import logging
from pathlib import Path
from core.video_rotator import VideoRotator
from core.video_processor import VideoProcessor
from plugins.convert_2_bmp.video_frame import VideoFrame

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
def checke_output_path(output_path):
    # 检查输出路径是否存在
    if not os.path.exists(output_path):
        # 如果路径不存在，创建它
        os.makedirs(output_path, exist_ok=True)

def get_parameters():
    parser = argparse.ArgumentParser()
    public_group = parser.add_argument_group('公共参数')
    public_group.add_argument('input_path', help='输入文件路径')
    public_group.add_argument('-o', '--output', default='./output', help='输出文件路径')

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--frame', action='store_true', help='获取视频首帧')
    group.add_argument('--rotate', action='store_true', help='顺时针方向旋转视频')

    frame_group = parser.add_argument_group('取帧参数', description='仅在使用--frame时有效')
    frame_group.add_argument('-s', '--size', type=str, help='提取帧宽*高 (格式: WxH)')

    rotate_group = parser.add_argument_group('旋转参数', description='仅在使用--rotate时有效')
    rotate_group.add_argument('-a', '--angle', type=int, choices=[0, 1, 2, 3], default=0, help='旋转角度, 入参为90为倍数。90:1, 180:2, 270:3')
    rotate_group.add_argument('-r', '--refs', type=int, choices=[1, 2], default=1, help='参考帧数量')
    config = parser.parse_args()
    return config

if __name__ == "__main__":
    args = get_parameters()
    checke_output_path(args.output)
    if args.frame:
        frame = VideoFrame(args.output)
    elif args.rotate:
        rotator = VideoRotator(args.angle * 90, args.output)

    for root, dirs, files in os.walk(args.input_path):
        for file in files:
            # 检查文件扩展名是否为.mp4
            if file.lower().endswith('.mp4'):
                # 构建完整的文件路径
                file_path = os.path.join(root, file)
                if args.frame:
                    logging.info("执行视频帧处理")
                    if args.size:
                        w, h = map(int, args.size.replace('x', '*').split('*'))
                        frame.run(w, h, file_path)
                    else:
                        ValueError("输入正常的尺寸格式:1920x1080")
                elif args.rotate:
                    logging.info("执行视频旋转处理")
                    processor = VideoProcessor(file_path)
                    if processor.check_video_file() == False:
                        new_file = f"{os.path.splitext(file)[0]}_H264{os.path.splitext(file)[1]}"
                        new_path = os.path.join(args.output, new_file)
                        processor.updata_video_file(new_path, args.refs)
                        file_path = new_path
                    rotator.run(file_path)