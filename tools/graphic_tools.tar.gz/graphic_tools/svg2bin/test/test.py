#!/usr/bin/env python3
# encoding=utf-8

import os
from ctypes import *
import time
import threading
# 定义结构体
class SvgBin(Structure):
    _fields_ = [("dataLen", c_uint32),
                ("data", POINTER(c_uint8))]

# 加载动态库
lib = cdll.LoadLibrary('../build/libsvg2bin.so')
lib.Svg2BinConverter.argtypes = [c_char_p, c_int]
lib.Svg2BinConverter.restype = SvgBin


# 测试用例代码
all_svg_File = []

def recursive_listdir(path):
    files = os.listdir(path)
    for file in files:
        file_path = os.path.join(path, file)
        if os.path.isfile(file_path):
            all_svg_File.append(file_path)
        elif os.path.isdir(file_path):
            recursive_listdir(file_path)

def test_svg():
    for path in all_svg_File:
        print("%s: %s" % ( path, time.ctime(time.time()) ))
        with open(path, 'rb') as inputF:  #打开文本
            data = inputF.read()   #读取文本
            # 调用动态库中的函数
            #result = lib.Svg2BinConverter(c_char_p(data.encode('utf-8')), -1)
            result = lib.Svg2BinConverter(c_char_p(data), -1)
            if (result.dataLen != 0xffffffff):
                filename = os.path.basename(path)
                output = os.path.splitext(filename)[0] + '.bin'
                print(result.dataLen, result.data)
                with open('bin/' + output, 'wb+') as outputF:
                    outputF.write(bytes(result.data[:result.dataLen]))
def test_svg2(path):
    print("%s: %s" % ( path, time.ctime(time.time()) ))
    with open(path, 'rb') as inputF:  #打开文本
        data = inputF.read()   #读取文本
        # 调用动态库中的函数
        #result = lib.Svg2BinConverter(c_char_p(data.encode('utf-8')), -1)
        result = lib.Svg2BinConverter(c_char_p(data), -1)
        if (result.dataLen != 0xffffffff):
            filename = os.path.basename(path)
            output = os.path.splitext(filename)[0] + '.bin'
            print(result.dataLen, result.data)
            with open('bin/' + output, 'wb+') as outputF:
                outputF.write(bytes(result.data[:result.dataLen]))

class myThread (threading.Thread):
    def __init__(self, threadID, path):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.path = path
    def run(self):
        print ("开始线程：" + self.path)
        test_svg2(self.path)
        print ("退出线程：" + self.path)

recursive_listdir('./src')

test_svg()

for path in all_svg_File:
    thread1 = myThread(1, path)

    # 开启新线程
    thread1.start()

thread1.join()












