#ifndef API_SVG_TO_BIN_H
#define API_SVG_TO_BIN_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int32_t dataLen;
    uint8_t* data;
} SvgBin;

/**
 * Converts data from SVG format to binary format.
 * @param svgData is the character pointer of the SVG data.
 * @param svgLen is the length of the SVG data. may pass (-1) if 'svgData' points to a
 * null terminated string.
 * @return the value of dataLen is a positive number if success,
 * or (-1) if failed.
 */
SvgBin Svg2BinConverter(char* svgData, int svgLen);

#ifdef __cplusplus
}
#endif

#endif
