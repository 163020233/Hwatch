#!/usr/bin/env python
# coding: utf-8
# Description: language_trans

import sys
sys.dont_write_bytecode = True
import xml.etree.ElementTree as ET
import zlib
import struct
import searchdir
import os

g_lang_info = {}
g_lang_id = []
g_lang_default_text_info = {}

def make_sure_dir_exit(filename):
    if not os.path.exists(os.path.dirname(filename)):
        try:
            os.makedirs(os.path.dirname(filename))
        except OSError as exc: # Guard against race condition
            if exc.errno != errno.EEXIST:
                raise

class TextInfo:
    KEY_VALUE = "value"
    KEY_fontName = "fontName"
    KEY_SIZE = "size"
    KEY_DIRECT = "direct"
    DIRECT_LTR = 0
    DIRECT_RTL = 1
    DIRECT_MIXED = 2
    DIRECT_NONE = 3

    def __init__(self, info):
        self._info = info

    def get_size(self):
        if TextInfo.KEY_SIZE in self._info:
            return int(self._info[TextInfo.KEY_SIZE])
        else:
            return 0

    def get_font_name(self):
        if TextInfo.KEY_fontName in self._info:
            return self._info[TextInfo.KEY_fontName]
        return None

    def get_value(self):
        if TextInfo.KEY_VALUE in self._info:
            return self._info[TextInfo.KEY_VALUE]
        return ""

    def get_direct(self):
        if TextInfo.KEY_DIRECT in self._info:
            if self._info[TextInfo.KEY_DIRECT] == "ltr":
                return TextInfo.DIRECT_LTR
            if self._info[TextInfo.KEY_DIRECT] == "rtl":
                return TextInfo.DIRECT_RTL
            if self._info[TextInfo.KEY_DIRECT] == "mixed":
                return TextInfo.DIRECT_MIXED
        return TextInfo.DIRECT_NONE

    def __repr__(self):
        return "%s" % (self._info)


def int_prim_xml_layer_tree(tree):
    root = tree.getroot()
    layer_root_element = ET.Element('')
    for child_1 in root:
        if child_1.tag == 'language':
            layer_root_element = child_1
            break
    return layer_root_element


def get_lang_binary_body(tree):
    offset = b''
    str = b''
    num = b''
    crcData = b''
    langId = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    # print(len(tree.findall('lanstr')))
    num += len(tree.findall('lanstr')).to_bytes(4, byteorder="little")
    for item in tree.findall('lanstr'):
        id = item.get('id')
        value = item.get('value')
        str += bytes(value, 'utf-8')
        str += b'\x00'
        offset += (len(bytes(value, 'utf-8')) +
                   1).to_bytes(4, byteorder="little")

    langId = struct.pack('16s', bytes(tree.get('languageinfo'), 'utf-8'))
    crcData += zlib.crc32(langId + num + offset +
                          str).to_bytes(4, byteorder="little")
    return crcData + langId + num + offset + str


def get_lang_head_body(tree):
    result = ''
    index = 0
    result += '/*\r\n'
    result += '* Copyright (c) xxxxxxxx Technologies Co., Ltd. 2021-2021. All rights reserved.\r\n'
    result += '* Description: language\r\n'
    result += '* Author: Graphic develop team\r\n'
    result += '* Create: 2021-07-06\r\n'
    result += '*/\r\n'
    result += '\r\n'
    result += '#ifndef UI_TEXT_LANGUAGE_H\r\n'
    result += '#define UI_TEXT_LANGUAGE_H\r\n'
    result += '#include <cstdint>\r\n'
    result += 'namespace OHOS {\r\n'
    result += 'enum UITextLanguageTextId : uint16_t {\r\n'

    for item in tree.findall('lanstr'):
        id = item.get('id')
        value = item.get('value')
        result += '    ' + id + ' = ' + str(index) + ',\r\n'
        index += 1
    result += '}; // UITextLanguageTextId\r\n'
    result += '#endif  /* UI_TEXT_LANGUAGE_H */\r\n'
    return result


def get_lang_binary_body_map(map, langType):
   # print(langType)
    offset = b''
    str = b''
    num = b''
    crcData = b''
    langId = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    # print(len(tree.findall('lanstr')))
    keys = map.keys()
    totalNum = len(keys)
    index = 0
    default_text_info = g_lang_default_text_info[langType]
    # check default fontName
    default_fontName = default_text_info.get_font_name()
    if default_fontName != None:
        str += bytes(default_fontName, 'utf-8')
        str += b'\x00'
        index += len(bytes(default_fontName, 'utf-8')) + 1
        totalNum |= 0x8000
    num += totalNum.to_bytes(2, byteorder="little")

    for item in keys:
        id = item
        if langType in map[item]:
            text_info = map[item][langType]
        else:
            text_info = TextInfo({})
        value = text_info.get_value()
        str += bytes(value, 'utf-8')
        str += b'\x00'
        index_value = index
        font_size = text_info.get_size()
        if font_size > 0:
            index_value |= (index_value & 0xFF000000) | (font_size << 24)

        direct = text_info.get_direct()
        if direct == TextInfo.DIRECT_NONE:
            direct = default_text_info.get_direct()
        if direct != None:
            index_value |= (index_value & 0x00600000) | (direct << 21)

        font_name = text_info.get_font_name()
        if font_name != None:
            index_value |= (index_value | 0x00800000)
            str += bytes(font_name, 'utf-8')
            str += b'\x00'
            index += len(bytes(font_name, 'utf-8')) + 1

        offset += (index_value).to_bytes(4, byteorder="little")
        index += len(bytes(value, 'utf-8')) + 1

    langId = struct.pack('16s', bytes(langType, 'utf-8'))
    crcData += zlib.crc32(langId + num + offset +
                          str).to_bytes(4, byteorder="little")
    return crcData + langId + num + offset + str


def GetTextInfo(item):
    info = {}
    if item.get(TextInfo.KEY_VALUE) != None:
        info[TextInfo.KEY_VALUE] = item.get(TextInfo.KEY_VALUE)
    if item.get(TextInfo.KEY_SIZE) != None:
        info[TextInfo.KEY_SIZE] = item.get(TextInfo.KEY_SIZE)
    if item.get(TextInfo.KEY_fontName) != None:
        info[TextInfo.KEY_fontName] = item.get(TextInfo.KEY_fontName)
    if item.get(TextInfo.KEY_DIRECT) != None:
        info[TextInfo.KEY_DIRECT] = item.get(TextInfo.KEY_DIRECT)
    text_info = TextInfo(info)
    return text_info


def get_lang_map(tree):
    langid = tree.get('languageinfo')
    g_lang_id.append(langid)
   # print(g_lang_id)

    text_info = GetTextInfo(tree)
   # print(text_info)
    g_lang_default_text_info[langid] = text_info

    for item in tree.findall('lanstr'):
        text_info = GetTextInfo(item)
        id = item.get('id')
        value = item.get('value')
        if id in g_lang_info:
            g_lang_info[id][langid] = text_info
        else:
            g_lang_info[id] = {langid: text_info}
   # print(g_lang_info)


def get_language_id_enum():
    result = """
enum FontLanguageId : uint8_t {
"""
    for language in g_lang_id:
        result += "    LANGUAGE_ID_" + language.upper() + ",\r\n"
    result += '    LANGUAGE_ID_MAX\r\n'
    result += '}; // UITextLanguageTextId\r\n'
    return result


def get_lang_head_body_map(map):
    result = """/*
* Copyright (c) xxxxxxxx Technologies Co., Ltd. 2021-2021. All rights reserved.
* Description: language
* Author: Graphic develop team
* Create: 2021-07-06
*/

#ifndef UI_RESOURCE_STRING_H
#define UI_RESOURCE_STRING_H
#include <cstdint>
namespace OHOS {
enum UIResourceTextId : uint16_t {
"""
    index = 0
    keys = map.keys()
    for item in keys:
        id = item
        result += '    ' + id + ' = ' + str(index) + ',\r\n'
        index += 1
    result += '    ' + "STR_MAX_ID" + ' = ' + str(index) + ',\r\n'
    result += '}; // UIResourceTextId\r\n'
    result += get_language_id_enum()
    result += '}\r\n'
    result += '#endif  /* UI_RESOURCE_STRING_H */\r\n'
   # print(result)
    return result


if __name__ == "__main__":
    args = len(sys.argv)
    argv = sys.argv
    if (args < 3):
        print("param should be \'xmlpath langPath headPath\'")
        # sys.exit()
    dirlist = searchdir.BASE()
    dirlist.RecusWalkDir(dir=argv[1])
    for item in dirlist.fileList:
       # print(item)
        tree = ET.parse(item).getroot()
        get_lang_map(tree)
    for item in g_lang_id:
        bin = get_lang_binary_body_map(g_lang_info, item)
        make_sure_dir_exit(os.path.join(argv[2], item + ".lang"));
        with open(os.path.join(argv[2], item + ".lang"), 'wb+') as file:
            file.write(bin)
    head = get_lang_head_body_map(g_lang_info)
    make_sure_dir_exit(os.path.join(argv[3], "ui_resource_string.h"))
    with open(os.path.join(argv[3], "ui_resource_string.h"), 'wb+') as file:
        file.write(bytes(head, 'utf-8'))
