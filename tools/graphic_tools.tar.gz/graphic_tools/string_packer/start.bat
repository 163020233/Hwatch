python language_trans.py .\test .\output .\output
pause