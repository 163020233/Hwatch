import os

#全局变量设置歌曲预定格式
Const_Song_Format=["xml"]


class BASE:
    #类变量，设置文件列表
    fileList=[]
    #类变量，设置文件计算
    counter=0
    def __init__(self):
        pass
    def RecusWalkDir(self,dir,filtrate=0):
        """本方法递归遍历目的文件夹中所有文件，获取指定格式的文件绝对地址,利用类变量fileList存储地址"""
        global Const_Song_Format
        for s in os.listdir(dir):
            newDir=dir+"/"+s
            if os.path.isdir(newDir):
                self.RecusWalkDir(newDir)
            else:
                if os.path.isfile(newDir):

                    if newDir and (self.GetFileFormat(newDir) in Const_Song_Format):
                        self.__class__.fileList.append(newDir)
                        self.__class__.counter+=1
                   


    def CycWalkDir(self,dir,filtrate=0):
        """本方法循环遍历文件夹中所有文件，获取指定格式的文件绝对地址，返回歌曲列表fileList"""
        global Const_Song_Format
        fileList=[""]
        for s in os.listdir(dir):
            newDir=dir+"/"+s
            if os.path.isfile(newDir):
                if filtrate:
                    if newDir and (self.GetFileFormat(newDir) in Const_Song_Format):
                        fileList.append(newDir)
                else:
                    fileList.append(newDir)
            else:
                newDir=dir+"/"+s
            while os.path.isdir(newDir):
                for s in os.listdir(dir):
                    newDir=dir+"/"+s
                    if os.path.isfile(newDir):
                        if filtrate:
                            if newDir and (self.GetFileFormat(newDir) in Const_Song_Format):
                                fileList.append(newDir)
                        else:
                            fileList.append(newDir)
                    else:
                        newDir=dir+"/"+s
        return fileList


    def GetFileFormat(self,fileName):
        """返回文件格式"""
        if fileName:
            BaseName=os.path.basename(fileName)
            str=BaseName.split(".")
  
            return str[-1]
        else:
            return fileName

