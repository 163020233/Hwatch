#!/usr/bin/python
# coding: utf-8
import sys
import struct
from enum import Enum
from ctypes import *

class Point(Structure):
    _fields_ = [
        ('x', c_short),
        ('y', c_short),
    ]

class Rect(Structure):
    _fields_ = [
        ('x', c_short),
        ('y', c_short),
        ('w', c_ushort),
        ('h', c_ushort)
    ]

class ColorStop(Structure):
    _fields_ = [
        ('stop', c_float),
        ('color', c_uint),
    ]