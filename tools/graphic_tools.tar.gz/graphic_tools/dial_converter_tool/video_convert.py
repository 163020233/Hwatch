#!/usr/bin/python
# coding: utf-8
import sys
import struct
import ctypes
from ctypes import *

class VideoConvertTool:
    def __init__(self):
        self.videoNum = 0
        self.videoName = []
        self.videoIndex = []
        self.videoData = bytearray()

    def convert_video(self, path):
        if path in self.videoName:
            index = self.videoName.index(path)
            return self.videoIndex[index]
        fp = open(path, 'rb')
        data = fp.read()
        fp.close()
        self.videoName.append(path)
        self.videoNum += 1
        ret = len(self.videoData)
        self.videoIndex.append(ret)
        self.videoData += data
        return ret

    def write_data_to_bin(self, fb):
        fb.write(self.videoData)

instance = VideoConvertTool()
