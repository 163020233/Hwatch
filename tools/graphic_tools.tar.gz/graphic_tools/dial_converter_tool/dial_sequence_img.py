#!/usr/bin/python
# coding: utf-8
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point
import img_convert

class DialSequenceImg(Structure):
    _fields_ = [
        ('pos', Point),
        ('interval', c_ushort),
        ('repeat', c_bool),
        ('imgNum', c_ubyte),
        ('displayMode', c_ubyte)
    ]

    def __init__(self):
        self.imgId = []
        self.period = 0
        self.displayMode = 0

    def parse_attributes(self, attributes):
        x,y = attributes["position"].split(" ")
        self.pos.x = int(x)
        if self.pos.x < np.iinfo(np.int16).min or self.pos.x > np.iinfo(np.int16).max :
            print("[ERR]:sequence image pos x out of range")
            sys.exit(1)

        self.pos.y = int(y)
        if self.pos.y < np.iinfo(np.int16).min or self.pos.y > np.iinfo(np.int16).max :
            print("[ERR]:sequence image pos y out of range")
            sys.exit(1)

        if attributes["repeat"].lower() == "true" :
            self.repeat = True
        elif attributes["repeat"].lower() == "false" :
            self.repeat = False
        else:
            print("[ERR]:sequence image repeat only 'True' or 'False'")
            sys.exit(1)

        interval = int(attributes["interval"])
        if interval < 0 or interval > np.iinfo(np.int16).max :
            print("[ERR]: sequence image interval out of range")
            sys.exit(1)
        else:
            self.interval = interval

        imgNames = attributes["img_names"].split(",")
        self.imgNum = len(imgNames)
        for img in imgNames:
            imgId = img_convert.instance.convert_img(img)
            self.imgId.append(imgId)

        if "display_mode" in attributes.getNames():
            display_mode = attributes["display_mode"]
            if display_mode == "normal":
                self.displayMode = 0
            elif display_mode == "ambient":
                self.displayMode= 1
            elif display_mode == "always":
                self.displayMode= 2

    def get_bytes(self):
        ret = bytes(self)
        for index in range(self.imgNum):
            ret += struct.pack('@H', self.imgId[index])
        return ret

    def get_size(self):
        return sizeof(self) + sizeof(c_ushort) * self.imgNum