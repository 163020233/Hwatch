#!/usr/bin/python
# coding: utf-8
# 1\ 解析命令 python main.py -d [DIR] -o [OUT_DIR]
# 2\ 循环执行svg解析写入
import sys
import os
import argparse
from converter import DialConvertTool

def GetParameters():
    parser = argparse.ArgumentParser()

    parser.add_argument('-file', '-f', type=str, default='', required=False,
                        help='Specifies the path of the offline watch face XML file to be converted.')

    parser.add_argument('-dir', '-d', type=str, default='', required=False,
                        help='Specifies the path of the folder to be converted. Convert all .xml files in the folder according to the specified path.')

    parser.add_argument('-output', type=str, default=os.getcwd() + "/out", required=False,
                        help='output dir')

    config = parser.parse_args()
    return config

if __name__ == "__main__":
    userInput = GetParameters()
    outputPath = userInput.output
    inputFile = userInput.file
    inputDir = userInput.dir
    # Create an output folder.
    print("output dir : " + outputPath)
    if not os.path.exists(outputPath):
        os.mkdir(outputPath)

    if not os.path.isdir(inputFile) and inputFile[-3:].lower() == "xml":
        print("input file : " + inputFile)
        converter = DialConvertTool()
        converter.convert_xml_to_output(inputFile, outputPath)

    print("inputdir", inputDir)
    files = os.listdir(inputDir)
    print("input dir : " + inputDir)
    for file in files:
        if not os.path.isdir(file) and file[-3:].lower() == "xml":
            converter = DialConvertTool()
            converter.convert_xml_to_output(inputDir + "/" + file, outputPath)