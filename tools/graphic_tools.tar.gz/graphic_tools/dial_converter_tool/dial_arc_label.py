#!/usr/bin/python
# coding: utf-8
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point

class DialArcLabel(Structure):
    _fields_ = [
        ('align', c_ubyte),
        ('fontSize', c_ubyte),
        ('center', Point),
        ('radius', c_ushort),
        ('rotateStart', c_short),
        ('rotaeteEnd', c_short),
        ('color', c_uint),
        ('fontName', c_char * 64),
        ('text', c_char * 64),
        ('bindData', c_short),
        ('isPeriodic', c_bool),
        ('displayMode', c_ubyte),
        ('isAmbientPeriodic', c_bool)
    ]
    def __init__(self):
        self.period = 0
        self.isPeriodic = False
        self.displayMode = 0
        self.isAmbientPeriodic = False

    def parse_attributes(self, attributes):
        alignStr = attributes["align"]
        if alignStr == "bottom":
            self.align = 4
        elif alignStr == "top":
            self.align = 3
        elif alignStr == "center":
            self.align = 2
        elif alignStr == "right":
            self.align = 1
        elif alignStr == "left":
            self.align = 0
        else:
            self.align = 0
            print("[WARNING] arc label align value input error, using defalut value")

        self.fontSize = int(attributes["font_size"])
        if self.fontSize < np.iinfo(np.int16).min or self.fontSize > np.iinfo(np.int16).max:
            print("[ERR]:label font size out of range")
            sys.exit(1)

        x,y = attributes["center"].split(" ")
        self.center.x = int(x)
        if self.center.x < np.iinfo(np.int16).min or self.center.x > np.iinfo(np.int16).max:
            print("[ERR]:arc label center x out of range")
            sys.exit(1)
        self.center.y = int(y)
        if self.center.y < np.iinfo(np.int16).min or self.center.y > np.iinfo(np.int16).max:
            print("[ERR]:arc label center y out of range")
            sys.exit(1)

        self.radius = int(attributes["radius"])
        if self.radius < 0 or self.radius > np.iinfo(np.int16).max:
            print("[ERR]:arc label radius out of range")
            sys.exit(1)

        self.rotateStart = int(attributes["start_angle"])
        self.rotaeteEnd = int(attributes["end_angle"])

        self.color = int(attributes["color"], 16)
        self.fontName = bytes(attributes["font"], encoding = "utf8")
        self.text = bytes(attributes["text"], encoding = "utf8")
        for attr in attributes.getNames():
            if attr == "bind_data":
                self.bindData = int(attributes["bind_data"])
                if self.bindData < 0 or self.bindData > np.iinfo(np.int16).max:
                    print("[ERR]:arc label bind data out of range")
                    sys.exit(1)
            elif attr == "period":
                period_suppor_value = {1, 10, 30, 60}
                self.period = int(attributes["period"])
                if self.period == 0:
                    self.isPeriodic = False
                elif self.period not in period_suppor_value:
                    self.period = 0
                    print("[WARNING]:arc label period value not support, using defalut value 0")
                else:
                    self.isPeriodic = True

        if "display_mode" in attributes.getNames():
            display_mode = attributes["display_mode"]
            if display_mode == "normal":
                self.displayMode = 0
            elif display_mode == "ambient":
                self.displayMode= 1
            elif display_mode == "always":
                self.displayMode= 2
        if self.displayMode != 0 :
            if "ambient_periodic" in attributes.getNames():
                if attributes["ambient_periodic"] == "true":
                    self.isAmbientPeriodic = True

        if self.isPeriodic != 0 and self.bindData == 0:
            print("[ERR]:[bind_data] is not set, [period] cannot be set")
            sys.exit(1)

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)