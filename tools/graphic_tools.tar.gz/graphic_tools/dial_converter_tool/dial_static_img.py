#!/usr/bin/python
# coding: utf-8
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point
import img_convert

class DialStaticImg(Structure):
    _fields_ = [
        ('pos', Point),
        ('center', Point),
        ('rotate', c_float),
        ('imgId', c_ushort),
        ('displayMode', c_ubyte),
    ]

    def __init__(self):
        self.imgId = 0
        self.center.x = 0
        self.center.y = 0
        self.rotate = 0.0
        self.period = 0
        self.displayMode = 0

    def parse_attributes(self, attributes):
        input_pos_x, input_pos_y = attributes["position"].split(" ")
        self.pos.x = int(input_pos_x)
        if self.pos.x < np.iinfo(np.int16).min or self.pos.x > np.iinfo(np.int16).max:
            print("[ERR]:static image pos x out of range")
            sys.exit(1)

        self.pos.y = int(input_pos_y)
        if self.pos.y < np.iinfo(np.int16).min or self.pos.y > np.iinfo(np.int16).max:
            print("[ERR]:static image pos y out of range")
            sys.exit(1)

        self.imgId = img_convert.instance.convert_img(attributes["img_name"])

        for attr in attributes.getNames():
            if attr == "center":
                input_center_x,input_center_y = attributes["center"].split(" ")
                self.center.x = int(input_center_x)
                if self.center.x < np.iinfo(np.int16).min or self.center.x > np.iinfo(np.int16).max:
                    print("[ERR]:static image center x out of range")
                    sys.exit(1)

                self.center.y = int(input_center_y)
                if self.center.y < np.iinfo(np.int16).min or self.center.y > np.iinfo(np.int16).max:
                    print("[ERR]:static image center y out of range")
                    sys.exit(1)
            elif attr == "rotate":
                rotate = float(attributes["rotate"])
                if rotate < 0.0 or rotate > 360.0 :
                    print("[ERR]:static image rotate out of range, [0, 360]")
                    sys.exit(1)
                self.rotate = rotate

        if "display_mode" in attributes.getNames():
            display_mode = attributes["display_mode"]
            if display_mode == "normal":
                self.displayMode = 0
            elif display_mode == "ambient":
                self.displayMode = 1
            elif display_mode == "always":
                self.displayMode = 2

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)
