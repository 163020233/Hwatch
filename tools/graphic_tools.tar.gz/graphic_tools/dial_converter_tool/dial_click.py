#!/usr/bin/python
# coding: utf-8
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Rect

class ClickTypeUnion(Union):
    _fields_ = [
        ('sliceId', c_uint),
        ('bundleName', c_char * 64)
    ]

class DialClick(Structure):
    _fields_ = [
        ('type', c_ubyte),
        ('rect', Rect),
        ('unionType', ClickTypeUnion),
        ('displayMode', c_ubyte)
    ]

    def __init__(self):
        self.period = 0
        self.displayMode = 0

    def parse_attributes(self, attributes):
        x,y,w,h = attributes["rect"].split(" ")
        self.rect.x = int(x)
        if self.rect.x < np.iinfo(np.int16).min or self.rect.x > np.iinfo(np.int16).max:
            print("[ERR]:click rect x out of range")
            sys.exit(1)
        self.rect.y = int(y)
        if self.rect.y < np.iinfo(np.int16).min or self.rect.y > np.iinfo(np.int16).max:
            print("[ERR]:click rect y out of range")
            sys.exit(1)
        self.rect.w = int(w)
        if self.rect.w < np.iinfo(np.int16).min or self.rect.w > np.iinfo(np.int16).max:
            print("[ERR]:click rect w out of range")
            sys.exit(1)
        self.rect.h = int(h)
        if self.rect.h < np.iinfo(np.int16).min or self.rect.h > np.iinfo(np.int16).max:
            print("[ERR]:click rect h out of range")
            sys.exit(1)

        for attr in attributes.getNames():
            if attr == "action_slice":
                self.unionType.sliceId = int(attributes["action_slice"])
                self.type = 0
                break
            elif attr == "action_bundle":
                self.unionType.bundleName = bytes(attributes["action_bundle"], encoding = "utf8")
                self.type = 1
                break

        if "display_mode" in attributes.getNames():
            display_mode = attributes["display_mode"]
            if display_mode == "normal":
                self.displayMode = 0
            elif display_mode == "ambient":
                self.displayMode= 1
            elif display_mode == "always":
                self.displayMode= 2

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)