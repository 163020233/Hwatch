#!/usr/bin/python
# coding: utf-8
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point
import img_convert

class DialOptionImg(Structure):
    _fields_ = [
        ('pos', Point),
        ('bindData', c_short),
        ('isPeriodic', c_bool),
        ('count', c_ubyte),
        ('displayMode', c_ubyte),
        ('isAmbientPeriodic', c_bool)
    ]

    def __init__(self):
        self.imgId = []
        self.period = 0
        self.isPeriodic = False
        self.displayMode = 0
        self.isAmbientPeriodic = False

    def parse_attributes(self, attributes):
        input_pos_x,input_pos_y = attributes["position"].split(" ")
        self.pos.x = int(input_pos_x)
        if self.pos.x < np.iinfo(np.int16).min or self.pos.x > np.iinfo(np.int16).max:
            print("[ERR]:option image pos x out of range")
            sys.exit(1)

        self.pos.y = int(input_pos_y)
        if self.pos.y < np.iinfo(np.int16).min or self.pos.y > np.iinfo(np.int16).max:
            print("[ERR]:option image pos y out of range")
            sys.exit(1)

        self.bindData = int(attributes["bind_data"])
        if self.bindData < 0 or self.bindData > np.iinfo(np.int16).max:
            print("[ERR]:option image bind data out of range")
            sys.exit(1)

        imgNames = attributes["img_names"].split(",")

        if "display_mode" in attributes.getNames():
            display_mode = attributes["display_mode"]
            if display_mode == "normal":
                self.displayMode = 0
            elif display_mode == "ambient":
                self.displayMode= 1
            elif display_mode == "always":
                self.displayMode= 2
        if self.displayMode != 0:
            if "ambient_periodic" in attributes.getNames():
                if attributes["ambient_periodic"] == "true":
                    self.isAmbientPeriodic = True

        self.count = len(imgNames)
        for img in imgNames:
            imgId = img_convert.instance.convert_img(img)
            self.imgId.append(imgId)

        if "period" in attributes.getNames():
            period_suppor_value = {1, 10, 30, 60}
            self.period = int(attributes["period"])
            if self.period == 0:
                self.isPeriodic = False
            elif self.period not in period_suppor_value:
                self.period = 0
                print("[WARNING]:option image period value not support, using defalut value 0")
            else:
                self.isPeriodic = True

    def get_bytes(self):
        ret = bytes(self)
        for index in range(self.count):
            ret += struct.pack('@H', self.imgId[index])
        return ret

    def get_size(self):
        return sizeof(self) + sizeof(c_ushort) * self.count