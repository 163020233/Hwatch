#!/usr/bin/python
# coding: utf-8
import sys
import struct
from xml.dom.minidom import parse
from ctypes import *
import img_convert

class DialKaleidoscope(Structure):
    _fields_ = [
        ('imgId', c_ushort),
        ('rotateEventFactor', c_float),
        ('rotateAnimatorValue', c_float),
        ('displayMode', c_ubyte)
    ]

    def __init__(self):
        self.imgId = 0
        self.rotateEventFactor = 1.0
        self.rotateAnimatorValue = 0.0
        self.period = 0
        self.displayMode = 0

    def parse_attributes(self, attributes):
        self.imgId = img_convert.instance.convert_img(attributes["img_name"])
        for attr in attributes.getNames():
            if attr == "crown_rotate_step":
                self.rotateEventFactor = float(attributes["crown_rotate_step"])
            elif attr == "animator_rotate_step":
                self.rotateAnimatorValue = float(attributes["animator_rotate_step"])

        if "display_mode" in attributes.getNames():
            display_mode = attributes["display_mode"]
            if display_mode == "normal":
                self.displayMode = 0
            elif display_mode == "ambient":
                self.displayMode= 1
            elif display_mode == "always":
                self.displayMode= 2

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)
