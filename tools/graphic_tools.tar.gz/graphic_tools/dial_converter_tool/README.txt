usage: main.py [-h] [-file FILE] [-dir DIR] [-output OUTPUT]

options:
  -h, --help           显示帮助信息。
  -file FILE, -f FILE  指定待转化的离线表盘xml文件路径。
  -dir DIR, -d DIR     指定待转化的文件夹路径。根据指定路径，转化文件夹下所有xml文件。
  -output OUTPUT       指定转化后离线表盘打包资源所在路径

example:
windows: python .\main.py -dir .\instance\analogue_dial
windows: python .\main.py -dir .\instance\kaleidoscope_dial