#!/usr/bin/python
# coding: utf-8
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point
import img_convert

class DialDigitalImg(Structure):
    _fields_ = [
        ('alignType', c_ubyte, 4),
        ('integerLength', c_ubyte, 4),
        ('decimalPrecision', c_ubyte),
        ('imgIds', c_ushort * 10),
        ('signImgId', c_ushort),
        ('decimalPointImgId', c_ushort),
        ('space', c_ushort),
        ('alignPosition', Point),
        ('bindData', c_short),
        ('isPeriodic', c_bool),
        ('displayMode', c_ubyte),
        ('isAmbientPeriodic', c_bool)
    ]

    def __init__(self):
        self.period = 0
        self.isPeriodic = False
        self.displayMode = 0
        self.isAmbientPeriodic = False

    def parse_attributes(self, attributes):
        imgNames = attributes["img_names"].split(",")
        length = len(imgNames)
        if length < 10:
            print("[ERR]:tag:[digital_img] attr[img_names] less than 10!")
            sys.exit(1)
        else:
            for index in range(10):
                self.imgIds[index] = img_convert.instance.convert_img(imgNames[index])

        self.space = int(attributes["space"])
        if self.space < 0 or self.space > np.iinfo(np.int16).max:
            print("[ERR]:digital image space out of range")
            sys.exit(1)

        alignStr = attributes["align"]
        if alignStr == "right":
            self.alignType = 2
        elif alignStr == "center":
            self.alignType = 1
        elif alignStr == "left":
            self.alignType = 0
        else:
            print("[ERR]:digital image align not support")

        align_pos_x,align_pos_y = attributes["align_pos"].split(" ")
        align_x = int(align_pos_x)
        if align_x < np.iinfo(np.int16).min or align_x > np.iinfo(np.int16).max:
            print("[ERR]:digital image align x out of range")
            sys.exit(1)
        self.alignPosition.x = align_x

        align_y = int(align_pos_y)
        if align_y < np.iinfo(np.int16).min or align_y > np.iinfo(np.int16).max:
            print("[ERR]:digital image align y out of range")
            sys.exit(1)
        self.alignPosition.y = align_y

        self.bindData = int(attributes["bind_data"])
        if self.bindData < 0 or self.bindData > np.iinfo(np.int16).max:
            print("[ERR]:digital image bind data out of range")
            sys.exit(1)

        for attr in attributes.getNames():
            if attr == "sign_img_name":
                signImgName = attributes["sign_img_name"]
                self.signImgId = img_convert.instance.convert_img(signImgName)
            elif attr == "integer_length":
                self.integerLength = int(attributes["integer_length"])
                if self.integerLength < 0 or self.integerLength > np.iinfo(np.uint8).max:
                    print("[ERR]:digital image integer length out of range")
                    sys.exit(1)
            elif attr == "img_decimal_point":
                decimalPointImgName = attributes["img_decimal_point"]
                self.decimalPointImgId = img_convert.instance.convert_img(decimalPointImgName)
            elif attr == "decimal_precision":
                self.decimalPrecision = int(attributes["decimal_precision"])
                if self.decimalPrecision < 0 or self.decimalPrecision > np.iinfo(np.uint8).max:
                    print("[ERR]:digital image decimal precision out of range")
                    sys.exit(1)
            elif attr == "period":
                period_suppor_value = {1, 10, 30, 60}
                self.period = int(attributes["period"])
                if self.period == 0:
                    self.isPeriodic = False
                elif self.period not in period_suppor_value:
                    self.period = 0
                    print("[WARNING]:digital image period value not support, using defalut value 0")
                else:
                    self.isPeriodic = True

        if "display_mode" in attributes.getNames():
            display_mode = attributes["display_mode"]
            if display_mode == "normal":
                self.displayMode = 0
            elif display_mode == "ambient":
                self.displayMode= 1
            elif display_mode == "always":
                self.displayMode= 2
        if self.displayMode != 0 :
            if "ambient_periodic" in attributes.getNames():
                if attributes["ambient_periodic"] == "true":
                    self.isAmbientPeriodic = True

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)