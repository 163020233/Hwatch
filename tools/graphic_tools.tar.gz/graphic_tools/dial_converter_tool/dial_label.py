#!/usr/bin/python
# coding: utf-8
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Rect

class DialLabel(Structure):
    _fields_ = [
        ('breakMode', c_ubyte),
        ('align', c_ubyte),
        ('fontSize', c_ubyte),
        ('isPeriodic', c_bool),
        ('rect', Rect),
        ('color', c_uint),
        ('fontName', c_char * 64),
        ('text', c_char * 64),
        ('bindData', c_short),
        ('displayMode', c_ubyte),
        ('isAmbientPeriodic', c_bool)
    ]

    def __init__(self):
        self.period = 0
        self.isPeriodic = False
        self.displayMode = 0
        self.isAmbientPeriodic = False

    def parse_attributes(self, attributes):
        x,y,w,h = attributes["rect"].split(" ")
        self.rect.x = int(x)
        if self.rect.x < np.iinfo(np.int16).min or self.rect.x > np.iinfo(np.int16).max:
            print("[ERR]:label rect x out of range")
            sys.exit(1)
        self.rect.y = int(y)
        if self.rect.y < np.iinfo(np.int16).min or self.rect.y > np.iinfo(np.int16).max:
            print("[ERR]:label rect y out of range")
            sys.exit(1)
        self.rect.w = int(w)
        if self.rect.w < np.iinfo(np.int16).min or self.rect.w > np.iinfo(np.int16).max:
            print("[ERR]:label rect w out of range")
            sys.exit(1)
        self.rect.h = int(h)
        if self.rect.h < np.iinfo(np.int16).min or self.rect.h > np.iinfo(np.int16).max:
            print("[ERR]:label rect h out of range")
            sys.exit(1)

        mode = attributes["break_mode"]
        if mode == "adapt":
            self.breakMode = 0
        elif mode == "stretch":
            self.breakMode = 1
        elif mode == "wrap":
            self.breakMode = 2
        elif mode == "ellipsis":
            self.breakMode = 3
        elif mode == "marquee":
            self.breakMode = 4
        elif mode == "clip":
            self.breakMode = 5
        else:
            self.breakMode = 3
            print("[WARNING][label:break_mode]Incorrect input:", mode)

        alignStr = attributes["align"]
        if alignStr == "bottom":
            self.align = 4
        elif alignStr == "top":
            self.align = 3
        elif alignStr == "center":
            self.align = 2
        elif alignStr == "right":
            self.align = 1
        elif alignStr == "left":
            self.align = 0
        else:
            self.align = 0
            print("[WARNING][label:align]Incorrect input:", alignStr)

        self.fontSize = int(attributes["font_size"])
        if self.fontSize < 0 or self.fontSize > np.iinfo(np.uint8).max:
            print("[ERR]:label font size out of range")
            sys.exit(1)

        self.color = int(attributes["color"], 16)
        self.fontName = bytes(attributes["font"], encoding = "utf8")
        self.text = bytes(attributes["text"], encoding = "utf8")

        for attr in attributes.getNames():
            if attr == "bind_data":
                self.bindData = int(attributes["bind_data"])
                if self.bindData < 0 or self.bindData > np.iinfo(np.int16).max:
                    print("[ERR]:label bind data out of range")
                    sys.exit(1)
            elif attr == "period":
                period_suppor_value = {1, 10, 30, 60}
                self.period = int(attributes["period"])
                if self.period == 0:
                    self.isPeriodic = False
                elif self.period not in period_suppor_value:
                    self.period = 0
                    print("[WARNING]:label image period value not support, using defalut value 0")
                else:
                    self.isPeriodic = True

        if "display_mode" in attributes.getNames():
            display_mode = attributes["display_mode"]
            if display_mode == "normal":
                self.displayMode = 0
            elif display_mode == "ambient":
                self.displayMode= 1
            elif display_mode == "always":
                self.displayMode= 2
        if self.displayMode != 0 :
            if "ambient_periodic" in attributes.getNames():
                if attributes["ambient_periodic"] == "true":
                    self.isAmbientPeriodic = True

        if self.isPeriodic != 0 and self.bindData == 0:
            print("[ERR]:[bind_data] is not set, [period] cannot be set")
            sys.exit(1)

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)