#!/usr/bin/python
# coding: utf-8
import os
import re
import struct
import ctypes
import sys
from ctypes import *
import xml.sax
from enum import Enum
import img_convert
import video_convert
from dial_static_img import DialStaticImg
from dial_sequence_img import DialSequenceImg
from dial_rotate_img import DialRotateImg
from dial_option_img import DialOptionImg
from dial_digital_img import DialDigitalImg
from dial_label import DialLabel
from dial_arc_label import DialArcLabel
from dial_box_progress import DialBoxProgress
from dial_arc_progress import DialArcProgress
from dial_video import DialVideo
from dial_click import DialClick
from dial_kaleidoscope import DialKaleidoscope

class DialHeader(Structure):
    _fields_ = [
        ('dialName', c_char * 16),
        ('width', c_short),
        ('height', c_short),
        ('version', c_char * 16),
        ('previewImgId', c_ushort),
        ('description', c_char * 128),
        ('imgoffset', c_uint),
        ('period', c_ubyte),
        ('dialViewCount', c_ubyte),
        ('displayCapabiliy', c_ubyte),
        ('ambientPeriod', c_ubyte),
    ]
    _DIAL_DEFAULT_MAX_WIDTH = 960
    _DIAL_DEFAULT_MAX_HEIGHT = 960

    def __init__(self):
        self.imgoffset = 0
        self.dialViewCount = 0
        self.period = 0
        self.displayCapabiliy = 0
        self.ambientPeriod = 0
        self.viewType = []
        self.viewPt = []

    def parse_attributes(self, attributes):
        title = attributes["title"]
        self.dialName = bytes(title, encoding = "utf8")

        description = attributes["description"]
        self.description = bytes(description, encoding = "utf8")

        version = attributes["version"]
        self.version = bytes(version, encoding = "utf8")

        self._parse_size_attr(attributes["size"])

        previewStr = attributes["preview_img"]
        self.previewImgId = img_convert.instance.convert_img(previewStr)

        for attr in attributes.getNames():
            if attr == "tile_width":
                tile_width = int(attributes["tile_width"])
                img_convert.instance.set_tile_width(tile_width)
            elif attr == "ambient_period":
                period_suppor_value = {1, 10, 30, 60}
                self.ambientPeriod = int(attributes["ambient_period"])
                if self.ambientPeriod not in period_suppor_value:
                    self.ambientPeriod = 0
                    print("[WARNING]:label image period value not support, using defalut value 0")


    def add_view(self, viewObj, viewType):
        self.viewPt.append(viewObj)
        self.viewType.append(viewType)
        self.dialViewCount += 1

    def get_bytes(self):
        ret = bytes(self)
        for index in range(self.dialViewCount):
            ret += struct.pack('@b', self.viewType[index])
        return ret

    def get_size(self):
        return sizeof(self) + sizeof(c_ubyte) * self.dialViewCount

    def _parse_size_attr(self, input_size):
        input_width,input_height = input_size.split(' ')
        width = int(input_width)
        if width <= 0 or width > DialHeader._DIAL_DEFAULT_MAX_WIDTH :
            print(f"[ERR]:dial size width out of range, (0, {DialHeader._DIAL_DEFAULT_MAX_WIDTH}], value:{width}")
            sys.exit(1)
        self.width = width

        height = int(input_height)
        if height <= 0 or height > DialHeader._DIAL_DEFAULT_MAX_HEIGHT :
            print(f"[ERR]:dial size height out of range, (0, {DialHeader._DIAL_DEFAULT_MAX_HEIGHT}], value:{height}")
            sys.exit(1)
        self.height = height

class DialConvertTool(xml.sax.ContentHandler):
    parser = xml.sax.make_parser()
    DIAL_STATIC_IMG_TYPE = 0
    DIAL_SEQUENCE_IMG_TYPE = 1
    DIAL_ROTATE_IMG_TYPE = 2
    DIAL_OPTION_IMG_TYPE = 3
    DIAL_DIGITAL_IMG_TYPE = 4
    DIAL_LABEL_TYPE = 5
    DIAL_ARC_LABEL_TYPE = 6
    DIAL_BOX_PROGRESS_TYPE = 7
    DIAL_ARC_PROGRESS_TYPE = 8
    DIAL_VIDEO_TYPE = 9
    DIAL_CLICK_TYPE = 10
    DIAL_KALEIDOSCCOPE_TYPE = 11

    def __init__(self):
        self.inFile = ""
        self.outPath = ""
        self.header = DialHeader()
        self.parser.setFeature(xml.sax.handler.feature_namespaces, 0)
        self.parser.setContentHandler(self)

    def startElement(self, tag, attributes):
        viewTypeArray = []
        if tag == "dial":
            self.header.parse_attributes(attributes)
        elif tag == "static_img":
            view = DialStaticImg()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_STATIC_IMG_TYPE)
        elif tag == "sequence_img":
            view = DialSequenceImg()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_SEQUENCE_IMG_TYPE)
        elif tag == "rotate_img":
            view = DialRotateImg()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_ROTATE_IMG_TYPE)
        elif tag == "option_img":
            view = DialOptionImg()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_OPTION_IMG_TYPE)
        elif tag == "digital_img":
            view = DialDigitalImg()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_DIGITAL_IMG_TYPE)
        elif tag == "label":
            view = DialLabel()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_LABEL_TYPE)
        elif tag == "arc_label":
            view = DialArcLabel()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_ARC_LABEL_TYPE)
        elif tag == "box_progress":
            view = DialBoxProgress()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_BOX_PROGRESS_TYPE)
        elif tag == "arc_progress":
            view = DialArcProgress()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_ARC_PROGRESS_TYPE)
        elif tag == "video":
            view = DialVideo()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_VIDEO_TYPE)
        elif tag == "click":
            view = DialClick()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_CLICK_TYPE)
        elif tag == "kaleidoscope":
            view = DialKaleidoscope()
            view.parse_attributes(attributes)
            self.header.add_view(view, self.DIAL_KALEIDOSCCOPE_TYPE)

    def endElement(self, tag):
        if tag == "dial":
            # create & open dstfile
            outputfile = self.outPath + "/" + os.path.basename(self.inFile)[:-3] + "bin"
            fb = open(outputfile, 'wb')
            os.chmod(outputfile, 0o0755)
            self._write_data_to_bin(fb)
            fb.close()

    def convert_xml_to_output(self, inFile, outPath):
        self.inFile = inFile
        self.outPath = outPath
        self.parser.parse(inFile)

    def _write_data_to_bin(self, fb):
        self.header.imgoffset += self.header.get_size()
        aod_only, normal_only = 0, 0
        for view in self.header.viewPt:
            if self.header.period < view.period:
                self.header.period = view.period
            if view.displayMode == 1:
                aod_only = aod_only + 1
            elif view.displayMode == 2:
                aod_only = aod_only + 1
                normal_only = normal_only + 1
            else:
                normal_only = normal_only + 1
            self.header.imgoffset += view.get_size()
        if normal_only > 0 and aod_only > 0:
            self.header.displayCapabiliy = 2
        elif normal_only > 0 and aod_only == 0:
            self.header.displayCapabiliy = 0
        else:
            self.header.displayCapabiliy = 1

        fb.write(self.header.get_bytes())
        for view in self.header.viewPt:
            if isinstance(view, DialVideo):
                view.offset += self.header.imgoffset + img_convert.instance.get_size()
            fb.write(view.get_bytes())
        img_convert.instance.write_data_to_bin(fb)
        video_convert.instance.write_data_to_bin(fb)
