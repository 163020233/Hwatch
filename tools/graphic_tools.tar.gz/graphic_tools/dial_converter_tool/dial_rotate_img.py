#!/usr/bin/python
# coding: utf-8
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Point
import img_convert

class DialRotateImg(Structure):
    _fields_ = [
        ('pos', Point),
        ('center', Point),
        ('rotateStart', c_short),
        ('rotaeteEnd', c_short),
        ('imgId', c_ushort),
        ('bindData', c_short),
        ('isPeriodic', c_bool),
        ('displayMode', c_ubyte),
        ('isAmbientPeriodic', c_bool)
    ]

    def __init__(self):
        self.period = 0
        self.isPeriodic = False
        self.displayMode = 0
        self.isAmbientPeriodic = False

    def parse_attributes(self, attributes):
        input_pos_x,input_pos_y = attributes["position"].split(" ")
        self.pos.x = int(input_pos_x)
        if self.pos.x < np.iinfo(np.int16).min or self.pos.x > np.iinfo(np.int16).max:
            print("[ERR]:rotate image pos x out of range")
            sys.exit(1)

        self.pos.y = int(input_pos_y)
        if self.pos.y < np.iinfo(np.int16).min or self.pos.y > np.iinfo(np.int16).max:
            print("[ERR]:rotate image pos y out of range")
            sys.exit(1)

        x,y = attributes["rotate_center"].split(" ")
        self.center.x = round(float(x))
        self.center.y = round(float(y))

        self.rotateStart = int(attributes["rotate_start"])
        if self.rotateStart < 0.0 or self.rotateStart > 360.0 :
            print("[ERR]:rotate image start angle out of range, [0, 360]")
            sys.exit(1)

        self.rotaeteEnd = int(attributes["rotate_end"])
        if self.rotaeteEnd < 0.0 or self.rotaeteEnd > 360.0 :
            print("[ERR]:rotate image end angle out of range, [0, 360]")
            sys.exit(1)

        self.bindData = int(attributes["bind_data"])
        if self.bindData < 0 or self.bindData > np.iinfo(np.int16).max:
            print("[ERR]:rotate image bind data out of range")
            sys.exit(1)

        self.imgId = img_convert.instance.convert_img(attributes["img_name"])
        if "period" in attributes.getNames():
            period_suppor_value = {1, 10, 30, 60}
            self.period = int(attributes["period"])
            if self.period == 0:
                self.isPeriodic = False
            elif self.period not in period_suppor_value:
                self.period = 0
                print("[WARNING]:rotate image period value not support, using defalut value 0")
            else:
                self.isPeriodic = True

        if "display_mode" in attributes.getNames():
            display_mode = attributes["display_mode"]
            if display_mode == "normal":
                self.displayMode = 0
            elif display_mode == "ambient":
                self.displayMode = 1
            elif display_mode == "always":
                self.displayMode = 2
        if self.displayMode != 0:
            if "ambient_periodic" in attributes.getNames():
                if attributes["ambient_periodic"] == "true":
                    self.isAmbientPeriodic = True

    def get_bytes(self):
        return bytes(self)

    def get_size(self):
        return sizeof(self)