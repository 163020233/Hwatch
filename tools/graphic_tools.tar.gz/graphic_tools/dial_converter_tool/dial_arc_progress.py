#!/usr/bin/python
# coding: utf-8
import sys
import struct
import numpy as np
from xml.dom.minidom import parse
from ctypes import *
from common_types import Rect
from common_types import ColorStop
import img_convert

class ProgressUnion(Union):
    _fields_ = [
        ('stopCount', c_ubyte),
        ('imgId', c_ushort),
        ('color', c_uint),
    ]

class DialArcProgress(Structure):
    _fields_ = [
        ('cap', c_ubyte),
        ('isPeriodic', c_bool),
        ('radius', c_ushort),
        ('startAngle', c_ushort),
        ('endAngle', c_ushort),
        ('lineWidth', c_ushort),
        ('bindData', c_short),
        ('bgColor', c_uint),
        ('type', c_ubyte),
        ('rect', Rect),
        ('unionValue', ProgressUnion),
        ('displayMode', c_ubyte),
        ('isAmbientPeriodic', c_bool)
    ]

    def __init__(self):
        self.stop = []
        self.period = 0
        self.isPeriodic = False
        self.displayMode = 0
        self.isAmbientPeriodic = False

    def parse_attributes(self, attributes):
        x,y,w,h = attributes["rect"].split(" ")
        self.rect.x = int(x)
        if self.rect.x < np.iinfo(np.int16).min or self.rect.x > np.iinfo(np.int16).max:
            print("[ERR]:arc progress rect x out of range")
            sys.exit(1)
        self.rect.y = int(y)
        if self.rect.y < np.iinfo(np.int16).min or self.rect.y > np.iinfo(np.int16).max:
            print("[ERR]:arc progress rect y out of range")
            sys.exit(1)
        self.rect.w = int(w)
        if self.rect.w < np.iinfo(np.int16).min or self.rect.w > np.iinfo(np.int16).max:
            print("[ERR]:arc progress rect w out of range")
            sys.exit(1)
        self.rect.h = int(h)
        if self.rect.h < np.iinfo(np.int16).min or self.rect.h > np.iinfo(np.int16).max:
            print("[ERR]:arc progress rect h out of range")
            sys.exit(1)

        cap = attributes["cap_type"]
        if cap == "round":
            self.cap = 1
        else:
            self.cap = 0

        self.radius = int(attributes["radius"])
        if self.radius < 0 or self.radius > np.iinfo(np.int16).max:
            print("[ERR]:arc progress radius out of range")
            sys.exit(1)

        self.startAngle = int(attributes["start_angle"])
        self.endAngle = int(attributes["end_angle"])

        self.lineWidth = int(attributes["line_width"])
        if self.lineWidth < 0 or self.lineWidth > np.iinfo(np.int16).max:
            print("[ERR]:arc progress lineWidth out of range")
            sys.exit(1)

        self.bindData = int(attributes["bind_data"])
        if self.bindData < 0 or self.bindData > np.iinfo(np.int16).max:
            print("[ERR]:arc progress bind data out of range")
            sys.exit(1)

        attrList = attributes.getNames()
        for attr in attrList:
            if attr == "img_name":
                self.unionValue.imgId = img_convert.instance.convert_img(attributes["img_name"])
                self.type = 0
                break
            elif attr == "color":
                self.unionValue.color = int(attributes["color"], 16)
                self.type = 1
                break
            elif attr == "gradient_colors":
                self.type = 2
                stopList = attributes["gradient_stops"].split(" ")
                colorList = attributes["gradient_colors"].split(" ")
                if len(stopList) != len(colorList):
                    print("[ERROR]:[gradient_stops] attr not equal [colorList] attr")
                self.unionValue.stopCount = min(len(colorList), len(stopList))
                for index in range(self.unionValue.stopCount):
                    colorStop = ColorStop()
                    colorStop.stop = float(stopList[index])
                    colorStop.color = int(colorList[index], 16)
                    self.stop.append(colorStop)
                break

        if "display_mode" in attributes.getNames():
            display_mode = attributes["display_mode"]
            if display_mode == "normal":
                self.displayMode = 0
            elif display_mode == "ambient":
                self.displayMode= 1
            elif display_mode == "always":
                self.displayMode= 2
        if self.displayMode != 0 :
            if "ambient_periodic" in attributes.getNames():
                if attributes["ambient_periodic"] == "true":
                    self.isAmbientPeriodic = True

        if "period" in attrList:
            period_suppor_value = {1, 10, 30, 60}
            self.period = int(attributes["period"])
            if self.period == 0:
                self.isPeriodic = False
            elif self.period not in period_suppor_value:
                self.period = 0
                print("[WARNING]:label image period value not support, using defalut value 0")
            else:
                self.isPeriodic = True

        if "background_color" in attrList:
            self.bgColor = int(attributes["background_color"], 16)

    def get_bytes(self):
        ret = bytes(self)
        if self.type == 2:
            for stop in self.stop:
                ret += bytes(stop)
        return ret

    def get_size(self):
        ret = sizeof(self)
        if self.type == 2:
            for stop in self.stop:
                ret += sizeof(stop)
        return ret